# 斗地主AI游戏项目架构文档

## 项目目录结构

```
ai-game/
├── backend/                          # 后端服务
│   ├── cmd/                         # 应用程序入口
│   │   ├── server/                  # 游戏服务器
│   │   │   └── main.go
│   │   └── admin/                   # 管理后台服务器
│   │       └── main.go
│   ├── internal/                    # 内部包（不对外暴露）
│   │   ├── config/                  # 配置管理
│   │   │   ├── config.go
│   │   │   └── config.yaml
│   │   ├── models/                  # 数据模型
│   │   │   ├── user.go              # 用户模型
│   │   │   ├── game.go              # 游戏模型
│   │   │   ├── room.go              # 房间模型
│   │   │   ├── card.go              # 牌面模型
│   │   │   └── ai_player.go         # AI玩家模型
│   │   ├── handlers/                # HTTP处理器
│   │   │   ├── auth.go              # 认证相关
│   │   │   ├── user.go              # 用户管理
│   │   │   ├── game.go              # 游戏API
│   │   │   ├── room.go              # 房间管理
│   │   │   ├── ai.go                # AI管理
│   │   │   └── websocket.go         # WebSocket处理
│   │   ├── services/                # 业务逻辑层
│   │   │   ├── auth_service.go      # 认证服务
│   │   │   ├── user_service.go      # 用户服务
│   │   │   ├── game_service.go      # 游戏服务
│   │   │   ├── room_service.go      # 房间服务
│   │   │   ├── ai_service.go        # AI服务
│   │   │   └── chat_service.go      # 聊天服务
│   │   ├── repositories/            # 数据访问层
│   │   │   ├── user_repo.go         # 用户数据访问
│   │   │   ├── game_repo.go         # 游戏数据访问
│   │   │   ├── room_repo.go         # 房间数据访问
│   │   │   └── ai_repo.go           # AI数据访问
│   │   ├── game/                    # 游戏核心逻辑
│   │   │   ├── engine/              # 游戏引擎
│   │   │   │   ├── game_engine.go   # 游戏引擎主类
│   │   │   │   ├── room_manager.go  # 房间管理器
│   │   │   │   └── player_manager.go # 玩家管理器
│   │   │   ├── landlord/            # 斗地主核心逻辑
│   │   │   │   ├── game.go          # 游戏主逻辑
│   │   │   │   ├── cards.go         # 牌面逻辑
│   │   │   │   ├── rules.go         # 游戏规则
│   │   │   │   ├── dealer.go        # 发牌器
│   │   │   │   └── scorer.go        # 计分器
│   │   │   └── ai/                  # AI逻辑
│   │   │       ├── ai_engine.go     # AI引擎
│   │   │       ├── strategy.go      # AI策略
│   │   │       ├── prompt_manager.go # 提示词管理
│   │   │       └── personality.go   # AI性格系统
│   │   ├── middleware/              # 中间件
│   │   │   ├── auth.go              # 认证中间件
│   │   │   ├── cors.go              # 跨域中间件
│   │   │   ├── logger.go            # 日志中间件
│   │   │   └── rate_limit.go        # 限流中间件
│   │   ├── utils/                   # 工具函数
│   │   │   ├── crypto.go            # 加密工具
│   │   │   ├── validator.go         # 验证工具
│   │   │   ├── response.go          # 响应工具
│   │   │   └── websocket.go         # WebSocket工具
│   │   └── database/                # 数据库相关
│   │       ├── bolt.go              # BoltDB连接
│   │       ├── migrations.go        # 数据迁移
│   │       └── seed.go              # 初始数据
│   ├── pkg/                         # 可对外使用的包
│   │   ├── logger/                  # 日志包
│   │   │   └── logger.go
│   │   ├── errors/                  # 错误处理包
│   │   │   └── errors.go
│   │   └── constants/               # 常量定义
│   │       └── constants.go
│   ├── tests/                       # 测试文件
│   │   ├── integration/             # 集成测试
│   │   └── unit/                    # 单元测试
│   ├── go.mod
│   └── go.sum
├── frontend/                        # 前端应用
│   ├── src/
│   │   ├── assets/                  # 静态资源
│   │   │   ├── images/              # 图片资源
│   │   │   │   ├── cards/           # 扑克牌图片
│   │   │   │   └── avatars/         # 头像图片
│   │   │   └── styles/              # 样式文件
│   │   │       ├── global.css
│   │   │       └── variables.css
│   │   ├── components/              # 公共组件
│   │   │   ├── common/              # 通用组件
│   │   │   │   ├── Button.vue
│   │   │   │   ├── Modal.vue
│   │   │   │   ├── Loading.vue
│   │   │   │   └── Avatar.vue
│   │   │   ├── game/                # 游戏组件
│   │   │   │   ├── GameBoard.vue    # 游戏桌面
│   │   │   │   ├── PlayerCard.vue   # 玩家卡片
│   │   │   │   ├── CardDeck.vue     # 牌组显示
│   │   │   │   ├── ScoreBoard.vue   # 计分板
│   │   │   │   └── ChatPanel.vue    # 聊天面板
│   │   │   └── room/                # 房间组件
│   │   │       ├── RoomList.vue     # 房间列表
│   │   │       ├── RoomCard.vue     # 房间卡片
│   │   │       └── PlayerList.vue   # 玩家列表
│   │   ├── views/                   # 页面视图
│   │   │   ├── auth/                # 认证页面
│   │   │   │   ├── Login.vue        # 登录页
│   │   │   │   └── Register.vue     # 注册页
│   │   │   ├── lobby/               # 大厅页面
│   │   │   │   ├── Lobby.vue        # 游戏大厅
│   │   │   │   └── RoomDetail.vue   # 房间详情
│   │   │   ├── game/                # 游戏页面
│   │   │   │   └── GameRoom.vue     # 游戏房间
│   │   │   └── admin/               # 管理页面
│   │   │       ├── Dashboard.vue    # 管理面板
│   │   │       ├── AIManager.vue    # AI管理
│   │   │       └── UserManager.vue  # 用户管理
│   │   ├── stores/                  # 状态管理(Pinia)
│   │   │   ├── auth.ts              # 认证状态
│   │   │   ├── game.ts              # 游戏状态
│   │   │   ├── room.ts              # 房间状态
│   │   │   └── user.ts              # 用户状态
│   │   ├── services/                # API服务
│   │   │   ├── api.ts               # API基础配置
│   │   │   ├── auth.ts              # 认证API
│   │   │   ├── game.ts              # 游戏API
│   │   │   ├── room.ts              # 房间API
│   │   │   ├── ai.ts                # AI管理API
│   │   │   └── websocket.ts         # WebSocket服务
│   │   ├── router/                  # 路由配置
│   │   │   └── index.ts
│   │   ├── utils/                   # 工具函数
│   │   │   ├── request.ts           # 请求工具
│   │   │   ├── storage.ts           # 存储工具
│   │   │   ├── validator.ts         # 验证工具
│   │   │   └── constants.ts         # 常量定义
│   │   ├── types/                   # TypeScript类型定义
│   │   │   ├── auth.ts              # 认证类型
│   │   │   ├── game.ts              # 游戏类型
│   │   │   ├── room.ts              # 房间类型
│   │   │   └── user.ts              # 用户类型
│   │   ├── App.vue                  # 根组件
│   │   └── main.ts                  # 应用入口
│   ├── public/                      # 公共资源
│   │   └── index.html
│   ├── package.json
│   ├── vite.config.ts
│   └── tsconfig.json
├── admin/                           # 管理后台前端
│   ├── src/
│   │   ├── components/              # 管理组件
│   │   ├── views/                   # 管理页面
│   │   ├── router/                  # 路由配置
│   │   └── main.ts
│   ├── package.json
│   └── vite.config.ts
├── docs/                           # 项目文档
│   ├── api/                        # API文档
│   │   ├── auth.md                 # 认证API文档
│   │   ├── game.md                 # 游戏API文档
│   │   └── websocket.md            # WebSocket文档
│   ├── game-rules/                 # 游戏规则文档
│   │   └── landlord.md             # 斗地主规则
│   ├── ai/                         # AI相关文档
│   │   ├── prompts.md              # 提示词设计
│   │   └── strategy.md             # AI策略文档
│   └── deployment/                 # 部署文档
│       └── docker.md               # Docker部署
├── scripts/                        # 脚本文件
│   ├── build.sh                    # 构建脚本
│   ├── deploy.sh                   # 部署脚本
│   └── db-seed.sh                  # 数据库初始化脚本
├── configs/                        # 配置文件
│   ├── development.yaml            # 开发环境配置
│   ├── production.yaml             # 生产环境配置
│   └── docker-compose.yml          # Docker编排文件
├── README.md                       # 项目说明
├── init.md                         # 项目初始化说明
└── project-structure.md            # 本文档
```

## 核心技术架构说明

### 1. 后端架构(Golang)
- **分层架构**: Handler -> Service -> Repository -> Database
- **依赖注入**: 使用Wire进行依赖注入管理
- **配置管理**: 使用Viper进行配置文件管理
- **数据库**: BoltDB作为嵌入式数据库，支持事务和并发
- **通信协议**: HTTP REST API + WebSocket实时通信

### 2. 前端架构(Vue3)
- **组件化设计**: 功能模块化，组件复用
- **状态管理**: Pinia进行全局状态管理
- **路由管理**: Vue Router进行页面路由
- **实时通信**: WebSocket客户端与后端实时交互
- **构建工具**: Vite进行快速开发和构建

### 3. 游戏引擎设计
- **房间管理**: 支持多房间并发游戏
- **玩家管理**: 用户连接管理和状态同步
- **游戏逻辑**: 斗地主核心规则引擎
- **AI集成**: 可配置的AI玩家系统

### 4. AI Agent系统
- **策略引擎**: 基于规则和AI API的决策系统
- **提示词管理**: 动态配置AI行为和性格
- **性格系统**: 不同AI玩家具有不同游戏风格
- **聊天AI**: 支持自然语言交互的聊天机器人

### 5. 数据模型设计
- **用户系统**: 用户注册、登录、资料管理
- **游戏数据**: 房间状态、游戏记录、积分系统
- **AI配置**: AI玩家配置、策略参数、性格设定
- **聊天记录**: 游戏内聊天消息存储

## 开发阶段规划

### 阶段一: 基础框架搭建
1. 创建项目目录结构
2. 配置开发环境和构建工具
3. 实现基础的HTTP服务器和WebSocket连接
4. 设计数据库结构和模型

### 阶段二: 核心功能开发
1. 用户认证系统
2. 房间和桌子管理
3. 斗地主游戏核心逻辑
4. 基础前端界面

### 阶段三: AI系统集成
1. AI Agent框架
2. 提示词系统
3. AI玩家配置管理
4. AI决策引擎

### 阶段四: 高级功能
1. 聊天系统和AI交互
2. 管理后台
3. 数据统计和分析
4. 性能优化

### 阶段五: 部署和测试
1. 单元测试和集成测试
2. Docker化部署
3. 压力测试和性能调优
4. 文档完善