import type { Card } from '@/types'

// 卡牌工具函数
export const cardUtils = {
  // 获取卡牌显示名称
  getCardDisplay(card: Card): string {
    if (card.suit === 5) return '小王'
    if (card.suit === 6) return '大王'
    
    const suits = ['', '♠', '♥', '♣', '♦']
    const ranks = ['', '', '', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A', '2']
    
    return `${suits[card.suit]}${ranks[card.rank]}`
  },

  // 获取卡牌CSS类名
  getCardClass(card: Card): string[] {
    const classes = ['card-item']
    
    if (card.suit === 5 || card.suit === 6) {
      classes.push('joker-card')
    } else if (card.suit === 1 || card.suit === 3) {
      classes.push('black-card')
    } else {
      classes.push('red-card')
    }
    
    return classes
  },

  // 卡牌排序比较函数
  compareCards(a: Card, b: Card): number {
    // 按点数排序，越大越前
    return b.rank - a.rank
  },

  // 对手牌进行排序
  sortCards(cards: Card[]): Card[] {
    return [...cards].sort(this.compareCards)
  }
}

// 格式化工具函数
export const formatUtils = {
  // 格式化时间
  formatTime(timestamp: string | number): string {
    const date = new Date(timestamp)
    const now = new Date()
    const diff = now.getTime() - date.getTime()
    
    if (diff < 60000) { // 1分钟内
      return '刚刚'
    } else if (diff < 3600000) { // 1小时内
      return `${Math.floor(diff / 60000)}分钟前`
    } else if (diff < 86400000) { // 1天内
      return `${Math.floor(diff / 3600000)}小时前`
    } else {
      return date.toLocaleDateString()
    }
  },

  // 格式化数字
  formatNumber(num: number): string {
    if (num >= 10000) {
      return `${(num / 10000).toFixed(1)}万`
    } else if (num >= 1000) {
      return `${(num / 1000).toFixed(1)}k`
    }
    return num.toString()
  },

  // 格式化胜率
  formatWinRate(wins: number, total: number): string {
    if (total === 0) return '0%'
    return `${Math.round((wins / total) * 100)}%`
  }
}

// 游戏工具函数
export const gameUtils = {
  // 获取房间状态文本
  getRoomStatusText(status: number): string {
    switch (status) {
      case 1: return '等待中'
      case 2: return '游戏中'
      case 3: return '已结束'
      default: return '未知'
    }
  },

  // 获取房间状态类型
  getRoomStatusType(status: number): string {
    switch (status) {
      case 1: return 'success'
      case 2: return 'warning'
      case 3: return 'info'
      default: return 'info'
    }
  },

  // 获取玩家位置描述
  getPositionText(position: number): string {
    switch (position) {
      case 1: return '下家'
      case 2: return '对家'
      case 3: return '上家'
      default: return `位置${position}`
    }
  },

  // 检查是否可以出牌
  canPlayCards(selectedCards: Card[], lastPlay: any): boolean {
    if (!selectedCards.length) return false
    if (!lastPlay) return true // 首次出牌
    
    // 简单的卡牌类型检查(实际应用中需要更复杂的逻辑)
    return selectedCards.length === lastPlay.cards.length
  }
}

// 存储工具函数
export const storageUtils = {
  // 设置本地存储
  setItem(key: string, value: any): void {
    try {
      localStorage.setItem(key, JSON.stringify(value))
    } catch (error) {
      console.error('存储数据失败:', error)
    }
  },

  // 获取本地存储
  getItem<T>(key: string, defaultValue: T): T {
    try {
      const item = localStorage.getItem(key)
      return item ? JSON.parse(item) : defaultValue
    } catch (error) {
      console.error('读取数据失败:', error)
      return defaultValue
    }
  },

  // 移除本地存储
  removeItem(key: string): void {
    try {
      localStorage.removeItem(key)
    } catch (error) {
      console.error('删除数据失败:', error)
    }
  },

  // 清空本地存储
  clear(): void {
    try {
      localStorage.clear()
    } catch (error) {
      console.error('清空数据失败:', error)
    }
  }
}

// 防抖函数
export function debounce<T extends (...args: any[]) => any>(
  func: T,
  wait: number,
  immediate = false
): (...args: Parameters<T>) => void {
  let timeout: NodeJS.Timeout | null = null
  
  return function executedFunction(...args: Parameters<T>) {
    const later = () => {
      timeout = null
      if (!immediate) func(...args)
    }
    
    const callNow = immediate && !timeout
    
    if (timeout) clearTimeout(timeout)
    timeout = setTimeout(later, wait)
    
    if (callNow) func(...args)
  }
}

// 节流函数
export function throttle<T extends (...args: any[]) => any>(
  func: T,
  limit: number
): (...args: Parameters<T>) => void {
  let inThrottle: boolean
  
  return function executedFunction(...args: Parameters<T>) {
    if (!inThrottle) {
      func.apply(this, args)
      inThrottle = true
      setTimeout(() => inThrottle = false, limit)
    }
  }
}