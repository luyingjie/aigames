import { apiService } from './api'
import type { Room, GameState, PlayCards, CreateRoomRequest, RoomListResponse } from '@/types'

export const gameService = {
  // 获取房间列表
  async getRooms(page = 1, limit = 20): Promise<{ rooms: RoomListResponse[]; total: number }> {
    return await apiService.get('/game/rooms', { page, limit })
  },

  // 创建房间
  async createRoom(data: CreateRoomRequest): Promise<Room> {
    return await apiService.post('/game/rooms', data)
  },

  // 加入房间
  async joinRoom(roomId: string): Promise<Room> {
    return await apiService.post(`/game/rooms/${roomId}/join`)
  },

  // 离开房间
  async leaveRoom(roomId: string): Promise<void> {
    return await apiService.post(`/game/rooms/${roomId}/leave`)
  },

  // 获取游戏状态
  async getGameState(roomId: string): Promise<GameState> {
    return await apiService.get(`/game/rooms/${roomId}/state`)
  },

  // 开始游戏
  async startGame(roomId: string): Promise<GameState> {
    return await apiService.post(`/game/rooms/${roomId}/start`)
  },

  // 叫地主
  async bid(roomId: string, bid: boolean): Promise<GameState> {
    return await apiService.post(`/game/rooms/${roomId}/bid`, { bid })
  },

  // 出牌
  async playCards(roomId: string, cards: number[]): Promise<GameState> {
    return await apiService.post(`/game/rooms/${roomId}/play`, { cards })
  },

  // 不出牌(过)
  async pass(roomId: string): Promise<GameState> {
    return await apiService.post(`/game/rooms/${roomId}/pass`)
  },

  // 发送聊天消息
  async sendChatMessage(roomId: string, message: string): Promise<void> {
    return await apiService.post(`/game/rooms/${roomId}/chat`, { message })
  },

  // 获取聊天记录
  async getChatMessages(roomId: string): Promise<any[]> {
    return await apiService.get(`/game/rooms/${roomId}/chat`)
  }
}