import { apiService } from './api'
import type { User, LoginForm, RegisterForm } from '@/types'

export const authService = {
  // 用户登录
  async login(credentials: LoginForm): Promise<{ user: User; token: string }> {
    return await apiService.post('/auth/login', credentials)
  },

  // 用户注册
  async register(data: RegisterForm): Promise<{ user: User; token: string }> {
    return await apiService.post('/auth/register', data)
  },

  // 获取用户信息
  async getProfile(): Promise<User> {
    return await apiService.get('/users/profile')
  },

  // 更新用户信息
  async updateProfile(data: Partial<User>): Promise<User> {
    return await apiService.put('/users/profile', data)
  },

  // 用户登出
  async logout(): Promise<void> {
    return await apiService.post('/users/logout')
  }
}