import { ref, reactive } from 'vue'
import { io, type Socket } from 'socket.io-client'
import { ElMessage } from 'element-plus'
import type { WSMessage, GameState, ChatMessage } from '@/types'

class WebSocketService {
  private socket: Socket | null = null
  private reconnectAttempts = 0
  private maxReconnectAttempts = 5
  private reconnectInterval = 3000

  // 响应式状态
  public isConnected = ref(false)
  public isConnecting = ref(false)
  
  // 事件监听器
  private listeners = reactive<{
    [event: string]: Array<(data: any) => void>
  }>({})

  constructor() {
    this.connect()
  }

  // 连接WebSocket
  private connect() {
    if (this.socket?.connected) return

    this.isConnecting.value = true
    
    this.socket = io('ws://localhost:8081', {
      transports: ['websocket'],
      autoConnect: true,
      reconnection: true,
      reconnectionAttempts: this.maxReconnectAttempts,
      reconnectionDelay: this.reconnectInterval
    })

    this.setupEventListeners()
  }

  // 设置事件监听器
  private setupEventListeners() {
    if (!this.socket) return

    this.socket.on('connect', () => {
      console.log('WebSocket连接成功')
      this.isConnected.value = true
      this.isConnecting.value = false
      this.reconnectAttempts = 0
    })

    this.socket.on('disconnect', (reason) => {
      console.log('WebSocket连接断开:', reason)
      this.isConnected.value = false
      this.isConnecting.value = false
      
      if (reason === 'io server disconnect') {
        // 服务器主动断开，需要手动重连
        this.reconnect()
      }
    })

    this.socket.on('connect_error', (error) => {
      console.error('WebSocket连接错误:', error)
      this.isConnected.value = false
      this.isConnecting.value = false
      this.handleReconnect()
    })

    // 游戏状态更新
    this.socket.on('game:state_update', (data: GameState) => {
      this.emit('gameStateUpdate', data)
    })

    // 聊天消息
    this.socket.on('chat:message', (data: ChatMessage) => {
      this.emit('chatMessage', data)
    })

    // 玩家加入
    this.socket.on('player:joined', (data: any) => {
      this.emit('playerJoined', data)
    })

    // 玩家离开
    this.socket.on('player:left', (data: any) => {
      this.emit('playerLeft', data)
    })

    // 游戏开始
    this.socket.on('game:started', (data: GameState) => {
      this.emit('gameStarted', data)
    })

    // 游戏结束
    this.socket.on('game:ended', (data: any) => {
      this.emit('gameEnded', data)
    })

    // 错误消息
    this.socket.on('error', (error: any) => {
      console.error('WebSocket错误:', error)
      ElMessage.error(error.message || '连接错误')
    })
  }

  // 处理重连
  private handleReconnect() {
    if (this.reconnectAttempts < this.maxReconnectAttempts) {
      this.reconnectAttempts++
      console.log(`尝试重连... (${this.reconnectAttempts}/${this.maxReconnectAttempts})`)
      setTimeout(() => this.reconnect(), this.reconnectInterval)
    } else {
      ElMessage.error('连接失败，请检查网络连接')
    }
  }

  // 重连
  private reconnect() {
    if (this.socket) {
      this.socket.disconnect()
    }
    this.connect()
  }

  // 发送消息
  public send<T>(event: string, data: T): void {
    if (!this.socket?.connected) {
      console.warn('WebSocket未连接，无法发送消息')
      return
    }

    const message: WSMessage = {
      type: event,
      data,
      timestamp: new Date().toISOString()
    }

    this.socket.emit(event, message)
  }

  // 加入房间
  public joinRoom(roomId: string): void {
    this.send('room:join', { roomId })
  }

  // 离开房间
  public leaveRoom(roomId: string): void {
    this.send('room:leave', { roomId })
  }

  // 发送聊天消息
  public sendChatMessage(roomId: string, content: string): void {
    this.send('chat:send', { roomId, content })
  }

  // 游戏操作
  public makeGameAction(roomId: string, action: string, data: any): void {
    this.send('game:action', { roomId, action, data })
  }

  // 注册事件监听器
  public on<T>(event: string, callback: (data: T) => void): void {
    if (!this.listeners[event]) {
      this.listeners[event] = []
    }
    this.listeners[event].push(callback)
  }

  // 移除事件监听器
  public off(event: string, callback?: (data: any) => void): void {
    if (!this.listeners[event]) return

    if (callback) {
      const index = this.listeners[event].indexOf(callback)
      if (index > -1) {
        this.listeners[event].splice(index, 1)
      }
    } else {
      this.listeners[event] = []
    }
  }

  // 触发事件
  private emit<T>(event: string, data: T): void {
    if (this.listeners[event]) {
      this.listeners[event].forEach(callback => {
        try {
          callback(data)
        } catch (error) {
          console.error(`事件回调执行错误 [${event}]:`, error)
        }
      })
    }
  }

  // 断开连接
  public disconnect(): void {
    if (this.socket) {
      this.socket.disconnect()
      this.socket = null
    }
    this.isConnected.value = false
    this.isConnecting.value = false
  }

  // 获取连接状态
  public get connected(): boolean {
    return this.socket?.connected || false
  }
}

// 创建全局WebSocket服务实例
export const webSocketService = new WebSocketService()

// 导出用于组件的composable
export function useWebSocket() {
  return {
    isConnected: webSocketService.isConnected,
    isConnecting: webSocketService.isConnecting,
    send: webSocketService.send.bind(webSocketService),
    on: webSocketService.on.bind(webSocketService),
    off: webSocketService.off.bind(webSocketService),
    joinRoom: webSocketService.joinRoom.bind(webSocketService),
    leaveRoom: webSocketService.leaveRoom.bind(webSocketService),
    sendChatMessage: webSocketService.sendChatMessage.bind(webSocketService),
    makeGameAction: webSocketService.makeGameAction.bind(webSocketService),
    disconnect: webSocketService.disconnect.bind(webSocketService)
  }
}