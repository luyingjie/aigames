// 用户相关类型
export interface User {
  id: string
  username: string
  nickname: string
  email: string
  phone: string
  avatar: string
  level: number
  experience: number
  coins: number
  wins: number
  losses: number
  total_games: number
  role: string
  status: number
  create_at: string
  update_at: string
}

// 房间相关类型
export interface Room {
  id: string
  name: string
  description: string
  capacity: number
  is_private: boolean
  owner_id: string
  players: Player[]
  current_game?: GameState
  status: number
  create_at: string
  update_at: string
  config: RoomConfig
}

export interface RoomConfig {
  game_timeout: number
  bidding_timeout: number
  play_timeout: number
  allow_ai: boolean
  auto_start: boolean
  score_multiple: number
}

// 创建房间请求类型
export interface CreateRoomRequest {
  name: string
  description?: string
  max_players: number
  settings: {
    base_score: number
    max_score?: number
    time_limit?: number
    ai_players: boolean
  }
}

// 房间列表响应类型
export interface RoomListResponse {
  id: string
  name: string
  description: string
  player_count: number
  capacity: number
  is_private: boolean
  status: number
  owner_name: string
  create_at: string
}

// 玩家相关类型
export interface Player {
  user_id: string
  nickname: string
  avatar: string
  score: number
  is_ai: boolean
  ai_player_id?: string
  role: number     // 0-未分配 1-地主 2-农民
  hand_cards: Card[]
  position: number
  is_ready: boolean
  is_current: boolean
  last_play: PlayCards
  join_at: string
}

// 兼容性别名
export interface GamePlayer extends Player {
  id: string
  user_id: string
  username?: string
  cards: Card[]
  is_landlord: boolean
  status: number
}

// 卡牌相关类型
export interface Card {
  suit: number    // 花色: 1-黑桃, 2-红桃, 3-梅花, 4-方块, 5-小王, 6-大王
  rank: number    // 点数: 3-10, 11-J, 12-Q, 13-K, 14-A, 15-2, 16-小王, 17-大王
  display: string // 显示名称
}

// 游戏状态类型
export interface GameState {
  id: string
  room_id: string
  players: Player[]
  phase: number              // 游戏阶段
  current_turn: number       // 当前回合玩家位置
  landlord_pos: number       // 地主位置
  hole_cards: Card[]         // 底牌
  last_play: PlayCards       // 最后出牌
  last_player: number        // 最后出牌玩家位置
  play_history: GamePlay[]   // 出牌历史
  winner: number             // 获胜方
  start_at: string
  end_at: string
  status: number             // 游戏状态
}

// 游戏出牌记录
export interface GamePlay {
  player_pos: number
  cards: Card[]
  type: number
  is_pass: boolean
  timestamp: string
}

// 兼容性类型别名
export interface LegacyGameState {
  id: string
  room_id: string
  status: number
  current_player: number
  landlord: number
  landlord_cards: Card[]
  deck: Card[]
  players: GamePlayer[]
  last_play: PlayCards | null
  play_history: PlayCards[]
  scores: { [key: string]: number }
  create_at: string
  update_at: string
}

export interface PlayCards {
  player_id: string
  cards: Card[]
  type: number
  main_rank: number
  length: number
}

// 兼容性类型别名
export interface LegacyPlayCards {
  player_id: string
  cards: Card[]
  card_type: number
  timestamp: string
}

// AI玩家类型
export interface AIPlayer {
  id: string
  name: string
  personality: string
  avatar: string
  description: string
  difficulty_level: number
  enabled: boolean
  config: AIConfig
  prompts: AIPrompts
  create_at: string
  update_at: string
}

export interface AIConfig {
  chat_enabled: boolean
  chat_frequency: number
  decision_delay: number
  api_provider: string
  api_model: string
  max_tokens: number
  temperature: number
}

export interface AIPrompts {
  system_prompt: string
  bid_prompt: string
  play_prompt: string
  chat_prompt: string
}

// 聊天消息类型
export interface ChatMessage {
  id: string
  room_id: string
  user_id: string
  content: string
  type: number
  is_ai: boolean
  ai_player: string
  status: number
  create_at: string
  update_at: string
}

// WebSocket消息类型
export interface WSMessage {
  type: string
  data: any
  timestamp: string
}

// API响应类型
export interface ApiResponse<T = any> {
  code: number
  message: string
  data?: T
  time: number
}

// 分页类型
export interface Pagination {
  page: number
  limit: number
  total: number
  total_pages: number
}

// 登录表单类型
export interface LoginForm {
  username: string
  password: string
}

// 注册表单类型
export interface RegisterForm {
  username: string
  password: string
  email: string
  nickname: string
}

// 游戏统计类型
export interface GameStats {
  total_games: number
  wins: number
  losses: number
  win_rate: number
  total_score: number
  average_score: number
}