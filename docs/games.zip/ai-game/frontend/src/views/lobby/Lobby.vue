<template>
  <div class="lobby-container">
    <!-- 顶部导航栏 -->
    <div class="lobby-header">
      <div class="header-left">
        <h1>AI斗地主游戏大厅</h1>
      </div>
      <div class="header-right">
        <div class="user-info">
          <el-avatar :src="userStore.user?.avatar" :size="40">
            {{ userStore.user?.nickname?.charAt(0) }}
          </el-avatar>
          <div class="user-details">
            <div class="username">{{ userStore.user?.nickname }}</div>
            <div class="user-stats">
              金币: {{ userStore.user?.coins || 0 }} | 
              胜率: {{ winRate }}%
            </div>
          </div>
        </div>
        <el-button @click="handleLogout" :icon="SwitchButton">退出</el-button>
      </div>
    </div>

    <!-- 主要内容区域 -->
    <div class="lobby-content">
      <!-- 左侧房间列表 -->
      <div class="room-section">
        <div class="section-header">
          <h2>游戏房间</h2>
          <el-button type="primary" @click="showCreateRoomDialog = true" :icon="Plus">
            创建房间
          </el-button>
        </div>
        
        <div class="room-list" v-loading="gameStore.loading">
          <div
            v-for="room in gameStore.rooms"
            :key="room.id"
            class="room-card"
            @click="handleJoinRoom(room.id)"
          >
            <div class="room-header">
              <h3>{{ room.name }}</h3>
              <el-tag :type="getRoomStatusType(room.status)">
                {{ getRoomStatusText(room.status) }}
              </el-tag>
            </div>
            <div class="room-info">
              <div class="room-players">
                <el-icon><User /></el-icon>
                {{ room.current_players }}/{{ room.max_players }}
              </div>
              <div class="room-score">
                底分: {{ room.settings?.base_score || 1 }}
              </div>
            </div>
            <div class="room-players-list">
              <el-avatar
                v-for="player in room.players"
                :key="player.id"
                :src="player.avatar"
                :size="30"
                :title="player.nickname"
              >
                {{ player.nickname?.charAt(0) }}
              </el-avatar>
            </div>
          </div>
          
          <div v-if="!gameStore.rooms?.length && !gameStore.loading" class="empty-rooms">
            <el-empty description="暂无游戏房间" />
          </div>
        </div>
        
        <div class="room-pagination">
          <el-pagination
            v-model:current-page="currentPage"
            :page-size="pageSize"
            :total="totalRooms"
            @current-change="handlePageChange"
            layout="prev, pager, next"
          />
        </div>
      </div>

      <!-- 右侧信息面板 -->
      <div class="info-section">
        <!-- 在线玩家 -->
        <div class="info-card">
          <h3>在线玩家</h3>
          <div class="online-count">
            <el-icon><UserFilled /></el-icon>
            <span>{{ onlineCount }} 人在线</span>
          </div>
        </div>

        <!-- 游戏规则 -->
        <div class="info-card">
          <h3>游戏规则</h3>
          <div class="rules-text">
            <p>• 三人斗地主，一副牌54张</p>
            <p>• 地主对战农民，率先出完牌者获胜</p>
            <p>• 支持AI玩家陪练</p>
            <p>• 智能聊天互动</p>
          </div>
        </div>

        <!-- 排行榜 -->
        <div class="info-card">
          <h3>今日排行</h3>
          <div class="ranking-list">
            <div v-for="(player, index) in topPlayers" :key="player.id" class="ranking-item">
              <div class="rank-number">{{ index + 1 }}</div>
              <el-avatar :src="player.avatar" :size="32">
                {{ player.nickname?.charAt(0) }}
              </el-avatar>
              <div class="player-name">{{ player.nickname }}</div>
              <div class="player-score">{{ player.wins }}胜</div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 创建房间对话框 -->
    <el-dialog
      v-model="showCreateRoomDialog"
      title="创建房间"
      width="500px"
      :close-on-click-modal="false"
    >
      <el-form
        ref="roomFormRef"
        :model="roomForm"
        :rules="roomRules"
        label-width="100px"
      >
        <el-form-item label="房间名称" prop="name">
          <el-input v-model="roomForm.name" placeholder="请输入房间名称" />
        </el-form-item>
        
        <el-form-item label="最大人数" prop="max_players">
          <el-select v-model="roomForm.max_players" placeholder="选择最大人数">
            <el-option label="3人" :value="3" />
          </el-select>
        </el-form-item>
        
        <el-form-item label="底分" prop="base_score">
          <el-select v-model="roomForm.settings.base_score" placeholder="选择底分">
            <el-option label="1分" :value="1" />
            <el-option label="2分" :value="2" />
            <el-option label="5分" :value="5" />
          </el-select>
        </el-form-item>
        
        <el-form-item label="AI玩家">
          <el-switch v-model="roomForm.settings.ai_players" />
        </el-form-item>
      </el-form>
      
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="showCreateRoomDialog = false">取消</el-button>
          <el-button type="primary" @click="handleCreateRoom" :loading="gameStore.loading">
            创建
          </el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { ElForm, ElMessage } from 'element-plus'
import { 
  Plus, 
  User, 
  UserFilled, 
  SwitchButton 
} from '@element-plus/icons-vue'
import { useUserStore } from '@/stores/user'
import { useGameStore } from '@/stores/game'
import type { Room } from '@/types'

const router = useRouter()
const userStore = useUserStore()
const gameStore = useGameStore()

// 响应式数据
const showCreateRoomDialog = ref(false)
const currentPage = ref(1)
const pageSize = ref(10)
const totalRooms = ref(0)
const onlineCount = ref(126) // 模拟在线人数
const topPlayers = ref([]) // 排行榜数据

// 表单引用
const roomFormRef = ref<InstanceType<typeof ElForm>>()

// 创建房间表单
const roomForm = reactive({
  name: '',
  max_players: 3,
  settings: {
    base_score: 1,
    max_score: 100,
    time_limit: 30,
    ai_players: true
  }
})

// 表单验证规则
const roomRules = {
  name: [
    { required: true, message: '请输入房间名称', trigger: 'blur' },
    { min: 2, max: 20, message: '房间名称长度在 2 到 20 个字符', trigger: 'blur' }
  ],
  max_players: [
    { required: true, message: '请选择最大人数', trigger: 'change' }
  ]
}

// 计算属性
const winRate = computed(() => {
  const user = userStore.user
  if (!user || user.total_games === 0) return 0
  return Math.round((user.wins / user.total_games) * 100)
})

// 获取房间状态类型
const getRoomStatusType = (status: number) => {
  switch (status) {
    case 1: return 'success' // 等待中
    case 2: return 'warning' // 游戏中
    case 3: return 'info'    // 已结束
    default: return 'info'
  }
}

// 获取房间状态文本
const getRoomStatusText = (status: number) => {
  switch (status) {
    case 1: return '等待中'
    case 2: return '游戏中'
    case 3: return '已结束'
    default: return '未知'
  }
}

// 加载房间列表
const loadRooms = async () => {
  try {
    const response = await gameStore.fetchRooms(currentPage.value, pageSize.value)
    totalRooms.value = response.total
  } catch (error) {
    console.error('加载房间列表失败:', error)
  }
}

// 处理页码变化
const handlePageChange = (page: number) => {
  currentPage.value = page
  loadRooms()
}

// 创建房间
const handleCreateRoom = async () => {
  if (!roomFormRef.value) return
  
  try {
    await roomFormRef.value.validate()
    const room = await gameStore.createRoom(roomForm)
    showCreateRoomDialog.value = false
    router.push(`/room/${room.id}`)
  } catch (error) {
    console.error('创建房间失败:', error)
  }
}

// 加入房间
const handleJoinRoom = async (roomId: string) => {
  try {
    await gameStore.joinRoom(roomId)
    router.push(`/room/${roomId}`)
  } catch (error) {
    console.error('加入房间失败:', error)
  }
}

// 退出登录
const handleLogout = async () => {
  try {
    await userStore.logout()
    router.push('/login')
  } catch (error) {
    console.error('退出登录失败:', error)
  }
}

// 组件挂载时加载数据
onMounted(() => {
  loadRooms()
  // TODO: 加载排行榜数据
})
</script>

<style scoped>
.lobby-container {
  display: flex;
  flex-direction: column;
  height: 100vh;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}

.lobby-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 16px 24px;
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(10px);
  border-bottom: 1px solid rgba(255, 255, 255, 0.2);
}

.header-left h1 {
  color: white;
  font-size: 24px;
  font-weight: 600;
  margin: 0;
}

.header-right {
  display: flex;
  align-items: center;
  gap: 16px;
}

.user-info {
  display: flex;
  align-items: center;
  gap: 12px;
  color: white;
}

.user-details .username {
  font-weight: 500;
  font-size: 16px;
}

.user-details .user-stats {
  font-size: 12px;
  opacity: 0.8;
}

.lobby-content {
  display: flex;
  flex: 1;
  gap: 24px;
  padding: 24px;
  overflow: hidden;
}

.room-section {
  flex: 1;
  display: flex;
  flex-direction: column;
  background: rgba(255, 255, 255, 0.95);
  border-radius: 16px;
  padding: 24px;
  backdrop-filter: blur(10px);
}

.section-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.section-header h2 {
  margin: 0;
  color: #333;
  font-size: 20px;
}

.room-list {
  flex: 1;
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 16px;
  overflow-y: auto;
}

.room-card {
  background: white;
  border-radius: 12px;
  padding: 20px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  cursor: pointer;
  transition: all 0.3s ease;
  border: 2px solid transparent;
}

.room-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.15);
  border-color: #409eff;
}

.room-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
}

.room-header h3 {
  margin: 0;
  color: #333;
  font-size: 16px;
}

.room-info {
  display: flex;
  justify-content: space-between;
  margin-bottom: 12px;
  font-size: 14px;
  color: #666;
}

.room-players {
  display: flex;
  align-items: center;
  gap: 4px;
}

.room-players-list {
  display: flex;
  gap: 8px;
}

.room-pagination {
  margin-top: 20px;
  display: flex;
  justify-content: center;
}

.info-section {
  width: 300px;
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.info-card {
  background: rgba(255, 255, 255, 0.95);
  border-radius: 12px;
  padding: 20px;
  backdrop-filter: blur(10px);
}

.info-card h3 {
  margin: 0 0 16px 0;
  color: #333;
  font-size: 16px;
}

.online-count {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 18px;
  color: #409eff;
  font-weight: 500;
}

.rules-text p {
  margin: 8px 0;
  color: #666;
  font-size: 14px;
}

.ranking-list {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.ranking-item {
  display: flex;
  align-items: center;
  gap: 12px;
}

.rank-number {
  width: 24px;
  height: 24px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #409eff;
  color: white;
  border-radius: 50%;
  font-size: 12px;
  font-weight: 500;
}

.player-name {
  flex: 1;
  font-size: 14px;
  color: #333;
}

.player-score {
  font-size: 12px;
  color: #666;
}

.empty-rooms {
  grid-column: 1 / -1;
  display: flex;
  justify-content: center;
  align-items: center;
  height: 200px;
}
</style>