<template>
  <div class="game-room">
    <div class="room-header">
      <div class="room-info">
        <h2>{{ currentRoom?.name || '游戏房间' }}</h2>
        <el-tag :type="getRoomStatusType()">{{ getRoomStatusText() }}</el-tag>
      </div>
      <div class="room-actions">
        <el-button @click="handleLeaveRoom" :icon="Back">离开房间</el-button>
      </div>
    </div>

    <div class="game-content">
      <!-- 游戏区域 -->
      <div class="game-area">
        <!-- 其他玩家区域 -->
        <div class="other-players">
          <div
            v-for="player in otherPlayers"
            :key="player.user_id"
            class="player-area"
            :class="`player-${player.position}`"
          >
            <div class="player-info">
              <el-avatar :src="player.avatar" :size="40">
                {{ player.nickname?.charAt(0) }}
              </el-avatar>
              <div class="player-details">
                <div class="player-name">{{ player.nickname }}</div>
                <div class="player-cards">牌数: {{ player.hand_cards?.length || 0 }}</div>
              </div>
              <div v-if="player.role === 1" class="landlord-badge">地主</div>
            </div>
          </div>
        </div>

        <!-- 中央游戏区域 -->
        <div class="center-area">
          <!-- 最后出牌显示 -->
          <div v-if="lastPlay" class="last-play">
            <div class="last-play-player">{{ getPlayerName(lastPlay.player_id) }}</div>
            <div class="last-play-cards">
              <div
                v-for="(card, index) in lastPlay.cards"
                :key="index"
                class="card"
                :class="getCardClass(card)"
              >
                {{ getCardDisplay(card) }}
              </div>
            </div>
          </div>

          <!-- 地主牌显示 -->
          <div v-if="landlordCards.length > 0" class="landlord-cards">
            <div class="landlord-title">地主牌</div>
            <div class="cards">
              <div
                v-for="(card, index) in landlordCards"
                :key="index"
                class="card"
                :class="getCardClass(card)"
              >
                {{ getCardDisplay(card) }}
              </div>
            </div>
          </div>

          <!-- 游戏状态信息 -->
          <div class="game-status">
            <div v-if="!isGameStarted && canStartGame" class="waiting-status">
              <el-button type="primary" size="large" @click="handleStartGame">
                开始游戏
              </el-button>
            </div>
            <div v-else-if="!isGameStarted" class="waiting-status">
              等待玩家加入...
            </div>
            <div v-else class="turn-status">
              当前轮到: {{ currentPlayerName }}
            </div>
          </div>
        </div>
      </div>

      <!-- 我的手牌区域 -->
      <div class="my-area">
        <div class="my-info">
          <el-avatar :src="userStore.user?.avatar" :size="40">
            {{ userStore.user?.nickname?.charAt(0) }}
          </el-avatar>
          <div class="my-details">
            <div class="my-name">{{ userStore.user?.nickname }}</div>
            <div class="my-score">得分: {{ myScore }}</div>
          </div>
          <div v-if="isMyLandlord" class="landlord-badge">地主</div>
        </div>

        <!-- 手牌 -->
        <div class="my-cards">
          <div
            v-for="(card, index) in myCards"
            :key="index"
            class="card"
            :class="[
              getCardClass(card),
              { selected: selectedCards.includes(index) }
            ]"
            @click="toggleCardSelection(index)"
          >
            {{ getCardDisplay(card) }}
          </div>
        </div>

        <!-- 操作按钮 -->
        <div class="action-buttons">
          <div v-if="isBiddingPhase" class="bid-buttons">
            <el-button type="primary" @click="makeBid(true)">叫地主</el-button>
            <el-button @click="makeBid(false)">不叫</el-button>
          </div>
          <div v-else-if="isMyTurn" class="play-buttons">
            <el-button 
              type="primary" 
              :disabled="selectedCards.length === 0"
              @click="playSelectedCards"
            >
              出牌
            </el-button>
            <el-button @click="passRound">不出</el-button>
            <el-button @click="clearSelection">重选</el-button>
          </div>
        </div>
      </div>
    </div>

    <!-- 聊天区域 -->
    <div class="chat-area">
      <div class="chat-messages" ref="chatMessagesRef">
        <div
          v-for="message in chatMessages"
          :key="message.id || message.timestamp"
          class="chat-message"
          :class="{ 'my-message': message.user_id === userStore.user?.id }"
        >
          <div class="message-sender">{{ getUserName(message.user_id) }}</div>
          <div class="message-content">{{ message.content }}</div>
        </div>
      </div>
      <div class="chat-input">
        <el-input
          v-model="chatInput"
          placeholder="输入聊天消息..."
          @keyup.enter="sendChatMessage"
        />
        <el-button type="primary" @click="sendChatMessage">发送</el-button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, onUnmounted, nextTick } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { Back } from '@element-plus/icons-vue'
import { useUserStore } from '@/stores/user'
import { useGameStore } from '@/stores/game'
import type { Card, ChatMessage, PlayCards } from '@/types'

const route = useRoute()
const router = useRouter()
const userStore = useUserStore()
const gameStore = useGameStore()

// 响应式数据
const selectedCards = ref<number[]>([])
const chatInput = ref('')
const chatMessages = ref<ChatMessage[]>([])
const chatMessagesRef = ref<HTMLElement>()

// 计算属性
const currentRoom = computed(() => gameStore.currentRoom)
const gameState = computed(() => gameStore.gameState)
const isGameStarted = computed(() => gameState.value?.status === 1) // 1表示游戏中
const isBiddingPhase = computed(() => gameState.value?.phase === 1) // 1表示叫地主阶段
const isMyTurn = computed(() => {
  if (!gameState.value || !userStore.user) return false
  const myPlayer = gameState.value.players.find(p => p.user_id === userStore.user!.id)
  return myPlayer?.position === gameState.value.current_turn
})

const myCards = computed(() => {
  if (!gameState.value || !userStore.user) return []
  const myPlayer = gameState.value.players.find(p => p.user_id === userStore.user!.id)
  return myPlayer?.hand_cards || []
})

const otherPlayers = computed(() => {
  if (!gameState.value || !userStore.user) return []
  return gameState.value.players.filter(p => p.user_id !== userStore.user!.id)
})

const isMyLandlord = computed(() => {
  if (!gameState.value || !userStore.user) return false
  const myPlayer = gameState.value.players.find(p => p.user_id === userStore.user!.id)
  return myPlayer?.role === 1 // 1表示地主
})

const myScore = computed(() => {
  if (!gameState.value || !userStore.user) return 0
  const myPlayer = gameState.value.players.find(p => p.user_id === userStore.user!.id)
  return myPlayer?.score || 0
})

const currentPlayerName = computed(() => {
  if (!gameState.value) return ''
  const currentPlayer = gameState.value.players.find(p => p.position === gameState.value!.current_turn)
  return currentPlayer?.nickname || ''
})

const lastPlay = computed(() => gameState.value?.last_play)
const landlordCards = computed(() => gameState.value?.hole_cards || [])

// 检查是否可以开始游戏
const canStartGame = computed(() => {
  if (!currentRoom.value) return false
  return currentRoom.value.players.length === 3 && 
         currentRoom.value.players.every(p => p.is_ready) &&
         !isGameStarted.value
})

// 检查是否为房主
const isRoomOwner = computed(() => {
  if (!currentRoom.value || !userStore.user) return false
  return currentRoom.value.owner_id === userStore.user.id
})

// 获取房间状态类型
const getRoomStatusType = () => {
  if (!gameState.value) return 'info'
  switch (gameState.value.phase) {
    case 1: return 'warning' // 叫地主阶段
    case 2: return 'success' // 游戏中
    case 3: return 'info'    // 已结束
    default: return 'info'
  }
}

// 获取房间状态文本
const getRoomStatusText = () => {
  if (!gameState.value) return '等待中'
  switch (gameState.value.phase) {
    case 1: return '叫地主中'
    case 2: return '游戏中'
    case 3: return '游戏结束'
    default: return '等待中'
  }
}

// 获取玩家名称
const getPlayerName = (playerId: string) => {
  if (!gameState.value) return ''
  const player = gameState.value.players.find(p => p.user_id === playerId)
  return player?.nickname || ''
}

// 获取用户名称
const getUserName = (userId: string) => {
  if (userId === userStore.user?.id) {
    return userStore.user.nickname
  }
  // TODO: 从其他玩家或聊天缓存中获取用户名
  return '玩家'
}

// 获取卡牌显示文本
const getCardDisplay = (card: Card) => {
  return card.display || `${card.suit}-${card.rank}`
}

// 获取卡牌CSS类
const getCardClass = (card: Card) => {
  const classes = ['card-item']
  if (card.suit === 1 || card.suit === 3) {
    classes.push('black-card')
  } else {
    classes.push('red-card')
  }
  return classes
}

// 切换卡牌选择
const toggleCardSelection = (index: number) => {
  if (!isMyTurn.value) return
  
  const selectedIndex = selectedCards.value.indexOf(index)
  if (selectedIndex > -1) {
    selectedCards.value.splice(selectedIndex, 1)
  } else {
    selectedCards.value.push(index)
  }
}

// 清除选择
const clearSelection = () => {
  selectedCards.value = []
}

// 叫地主
const makeBid = async (bid: boolean) => {
  try {
    await gameStore.makeBid(bid)
    ElMessage.success(bid ? '叫地主成功' : '不叫')
  } catch (error) {
    console.error('叫地主失败:', error)
  }
}

// 出牌
const playSelectedCards = async () => {
  if (selectedCards.value.length === 0) {
    ElMessage.warning('请选择要出的牌')
    return
  }
  
  try {
    await gameStore.playCards(selectedCards.value)
    selectedCards.value = []
    ElMessage.success('出牌成功')
  } catch (error) {
    console.error('出牌失败:', error)
  }
}

// 不出牌
const passRound = async () => {
  try {
    await gameStore.passRound()
    ElMessage.success('不出')
  } catch (error) {
    console.error('过牌失败:', error)
  }
}

// 发送聊天消息
const sendChatMessage = async () => {
  if (!chatInput.value.trim()) return
  
  try {
    await gameStore.sendChatMessage(chatInput.value.trim())
    chatInput.value = ''
    // 刷新聊天记录
    await loadChatMessages()
  } catch (error) {
    console.error('发送消息失败:', error)
    ElMessage.error('发送消息失败')
  }
}

// 加载聊天记录
const loadChatMessages = async () => {
  try {
    const messages = await gameStore.fetchChatMessages()
    chatMessages.value = messages || []
    // 滚动到底部
    await nextTick(() => {
      if (chatMessagesRef.value) {
        chatMessagesRef.value.scrollTop = chatMessagesRef.value.scrollHeight
      }
    })
  } catch (error) {
    console.error('加载聊天记录失败:', error)
  }
}

// 开始游戏
const handleStartGame = async () => {
  if (!canStartGame.value) {
    ElMessage.warning('房间人数不足或有玩家未准备')
    return
  }
  
  if (!isRoomOwner.value) {
    ElMessage.warning('只有房主可以开始游戏')
    return
  }
  
  try {
    await gameStore.startGame()
  } catch (error) {
    console.error('开始游戏失败:', error)
    ElMessage.error('开始游戏失败')
  }
}

// 离开房间
const handleLeaveRoom = async () => {
  try {
    await gameStore.leaveRoom()
    router.push('/lobby')
  } catch (error) {
    console.error('离开房间失败:', error)
  }
}

// 组件挂载时获取游戏状态
onMounted(async () => {
  const roomId = route.params.id as string
  if (roomId) {
    try {
      await gameStore.fetchGameState(roomId)
      // 加载聊天记录
      await loadChatMessages()
      // TODO: 建立 WebSocket 连接
    } catch (error) {
      console.error('获取游戏状态失败:', error)
      router.push('/lobby')
    }
  }
})

// 组件卸载时清理
onUnmounted(() => {
  // TODO: 断开WebSocket连接
})
</script>

<style scoped>
.game-room {
  display: flex;
  flex-direction: column;
  height: 100vh;
  background: linear-gradient(135deg, #2d5a27 0%, #4a7c59 100%);
  color: white;
}

.room-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 16px 24px;
  background: rgba(0, 0, 0, 0.3);
  border-bottom: 1px solid rgba(255, 255, 255, 0.2);
}

.room-info {
  display: flex;
  align-items: center;
  gap: 12px;
}

.room-info h2 {
  margin: 0;
  font-size: 20px;
}

.game-content {
  display: flex;
  flex: 1;
  gap: 20px;
  padding: 20px;
  overflow: hidden;
}

.game-area {
  flex: 1;
  display: flex;
  flex-direction: column;
  position: relative;
}

.other-players {
  display: flex;
  justify-content: space-between;
  margin-bottom: 20px;
}

.player-area {
  background: rgba(255, 255, 255, 0.1);
  border-radius: 12px;
  padding: 16px;
  min-width: 200px;
}

.player-info {
  display: flex;
  align-items: center;
  gap: 12px;
  position: relative;
}

.player-details .player-name {
  font-weight: 500;
  margin-bottom: 4px;
}

.player-details .player-cards {
  font-size: 12px;
  opacity: 0.8;
}

.landlord-badge {
  position: absolute;
  top: -8px;
  right: -8px;
  background: #f56c6c;
  color: white;
  padding: 2px 8px;
  border-radius: 12px;
  font-size: 12px;
}

.center-area {
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  gap: 20px;
}

.last-play {
  text-align: center;
}

.last-play-player {
  margin-bottom: 8px;
  font-size: 14px;
  opacity: 0.8;
}

.last-play-cards {
  display: flex;
  gap: 4px;
  justify-content: center;
}

.landlord-cards {
  text-align: center;
}

.landlord-title {
  margin-bottom: 8px;
  font-size: 14px;
  opacity: 0.8;
}

.cards {
  display: flex;
  gap: 4px;
  justify-content: center;
}

.game-status {
  padding: 12px 24px;
  background: rgba(255, 255, 255, 0.1);
  border-radius: 8px;
  text-align: center;
}

.my-area {
  display: flex;
  flex-direction: column;
  gap: 16px;
  margin-top: 20px;
}

.my-info {
  display: flex;
  align-items: center;
  gap: 12px;
  position: relative;
}

.my-details .my-name {
  font-weight: 500;
  margin-bottom: 4px;
}

.my-details .my-score {
  font-size: 12px;
  opacity: 0.8;
}

.my-cards {
  display: flex;
  gap: 4px;
  justify-content: center;
  flex-wrap: wrap;
  max-height: 120px;
  overflow-y: auto;
}

.card {
  width: 50px;
  height: 70px;
  background: white;
  border: 2px solid #ddd;
  border-radius: 6px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 12px;
  font-weight: bold;
  cursor: pointer;
  transition: all 0.3s ease;
  color: #333;
}

.card:hover {
  transform: translateY(-5px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
}

.card.selected {
  transform: translateY(-10px);
  border-color: #409eff;
  box-shadow: 0 6px 16px rgba(64, 158, 255, 0.4);
}

.red-card {
  color: #f56c6c;
}

.black-card {
  color: #333;
}

.action-buttons {
  display: flex;
  justify-content: center;
  gap: 12px;
}

.chat-area {
  width: 300px;
  display: flex;
  flex-direction: column;
  background: rgba(255, 255, 255, 0.1);
  border-radius: 12px;
  overflow: hidden;
}

.chat-messages {
  flex: 1;
  padding: 16px;
  overflow-y: auto;
  max-height: 400px;
}

.chat-message {
  margin-bottom: 12px;
}

.message-sender {
  font-size: 12px;
  opacity: 0.8;
  margin-bottom: 4px;
}

.message-content {
  background: rgba(255, 255, 255, 0.2);
  padding: 8px 12px;
  border-radius: 8px;
  font-size: 14px;
}

.my-message .message-content {
  background: rgba(64, 158, 255, 0.3);
}

.chat-input {
  display: flex;
  padding: 16px;
  gap: 8px;
  border-top: 1px solid rgba(255, 255, 255, 0.2);
}
</style>