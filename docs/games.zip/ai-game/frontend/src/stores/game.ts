import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import type { Room, GameState, Player, Card, PlayCards, CreateRoomRequest, RoomListResponse } from '@/types'
import { gameService } from '@/services/game'
import { ElMessage } from 'element-plus'
import { useUserStore } from './user'

export const useGameStore = defineStore('game', () => {
  // 状态
  const currentRoom = ref<Room | null>(null)
  const gameState = ref<GameState | null>(null)
  const rooms = ref<RoomListResponse[]>([])
  const loading = ref(false)
  
  // 计算属性
  const isInRoom = computed(() => !!currentRoom.value)
  const isGameStarted = computed(() => gameState.value?.status === 1) // 1表示游戏中
  const currentPlayer = computed(() => {
    if (!gameState.value) return null
    return gameState.value.players.find(p => p.position === gameState.value!.current_turn)
  })
  const myCards = computed(() => {
    if (!gameState.value) return []
    const userStore = useUserStore()
    const myPlayer = gameState.value.players.find(p => p.user_id === userStore.user?.id)
    return myPlayer?.hand_cards || []
  })

  // 获取房间列表
  const fetchRooms = async (page = 1, limit = 20) => {
    loading.value = true
    try {
      const response = await gameService.getRooms(page, limit)
      rooms.value = response.rooms
      return response
    } catch (error) {
      console.error('获取房间列表失败:', error)
      throw error
    } finally {
      loading.value = false
    }
  }

  // 创建房间
  const createRoom = async (roomData: CreateRoomRequest) => {
    loading.value = true
    try {
      const room = await gameService.createRoom(roomData)
      currentRoom.value = room
      ElMessage.success('房间创建成功')
      return room
    } catch (error) {
      console.error('创建房间失败:', error)
      throw error
    } finally {
      loading.value = false
    }
  }

  // 加入房间
  const joinRoom = async (roomId: string) => {
    loading.value = true
    try {
      const room = await gameService.joinRoom(roomId)
      currentRoom.value = room
      ElMessage.success('加入房间成功')
      return room
    } catch (error) {
      console.error('加入房间失败:', error)
      throw error
    } finally {
      loading.value = false
    }
  }

  // 离开房间
  const leaveRoom = async () => {
    if (!currentRoom.value) return
    
    loading.value = true
    try {
      await gameService.leaveRoom(currentRoom.value.id)
      currentRoom.value = null
      gameState.value = null
      ElMessage.success('已离开房间')
    } catch (error) {
      console.error('离开房间失败:', error)
      throw error
    } finally {
      loading.value = false
    }
  }

  // 获取游戏状态
  const fetchGameState = async (roomId: string) => {
    try {
      const state = await gameService.getGameState(roomId)
      gameState.value = state
      return state
    } catch (error) {
      console.error('获取游戏状态失败:', error)
      throw error
    }
  }

  // 叫地主
  const makeBid = async (bid: boolean) => {
    if (!currentRoom.value) return
    
    try {
      const state = await gameService.bid(currentRoom.value.id, bid)
      gameState.value = state
      return state
    } catch (error) {
      console.error('叫地主失败:', error)
      throw error
    }
  }

  // 出牌
  const playCards = async (cardIndexes: number[]) => {
    if (!currentRoom.value) return
    
    try {
      const state = await gameService.playCards(currentRoom.value.id, cardIndexes)
      gameState.value = state
      return state
    } catch (error) {
      console.error('出牌失败:', error)
      throw error
    }
  }

  // 不出牌(过)
  const passRound = async () => {
    if (!currentRoom.value) return
    
    try {
      const state = await gameService.pass(currentRoom.value.id)
      gameState.value = state
      return state
    } catch (error) {
      console.error('过牌失败:', error)
      throw error
    }
  }

  // 开始游戏
  const startGame = async () => {
    if (!currentRoom.value) return
    
    try {
      const state = await gameService.startGame(currentRoom.value.id)
      gameState.value = state
      ElMessage.success('游戏开始！')
      return state
    } catch (error) {
      console.error('开始游戏失败:', error)
      throw error
    }
  }

  // 发送聊天消息
  const sendChatMessage = async (message: string) => {
    if (!currentRoom.value) return
    
    try {
      await gameService.sendChatMessage(currentRoom.value.id, message)
      // 发送成功后立即刷新聊天记录
      await fetchChatMessages()
    } catch (error) {
      console.error('发送消息失败:', error)
      throw error
    }
  }

  // 获取聊天记录
  const fetchChatMessages = async () => {
    if (!currentRoom.value) return []
    
    try {
      const messages = await gameService.getChatMessages(currentRoom.value.id)
      return messages
    } catch (error) {
      console.error('获取聊天记录失败:', error)
      return []
    }
  }

  // 重置状态
  const resetGame = () => {
    currentRoom.value = null
    gameState.value = null
  }

  return {
    // 状态
    currentRoom,
    gameState,
    rooms,
    loading,
    
    // 计算属性
    isInRoom,
    isGameStarted,
    currentPlayer,
    myCards,
    
    // 方法
    fetchRooms,
    createRoom,
    joinRoom,
    leaveRoom,
    fetchGameState,
    makeBid,
    playCards,
    passRound,
    startGame,
    sendChatMessage,
    fetchChatMessages,
    resetGame
  }
})