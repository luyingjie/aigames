<template>
  <div class="player-avatar" :class="avatarClass">
    <div class="avatar-container">
      <el-avatar :src="player.avatar" :size="size">
        {{ player.nickname?.charAt(0) || '?' }}
      </el-avatar>
      
      <!-- 地主标识 -->
      <div v-if="player.is_landlord" class="landlord-badge">
        <el-icon><Crown /></el-icon>
      </div>
      
      <!-- AI标识 -->
      <div v-if="player.is_ai" class="ai-badge">
        AI
      </div>
      
      <!-- 在线状态 -->
      <div v-if="showOnlineStatus" class="online-status" :class="{ online: isOnline }"></div>
    </div>
    
    <div class="player-info" v-if="showInfo">
      <div class="player-name">{{ player.nickname }}</div>
      <div class="player-details">
        <span v-if="showCards" class="card-count">{{ player.cards?.length || 0 }}张</span>
        <span v-if="showScore" class="score">{{ player.score || 0 }}分</span>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { Crown } from '@element-plus/icons-vue'
import type { Player } from '@/types'

interface Props {
  player: Player
  size?: number
  showInfo?: boolean
  showCards?: boolean
  showScore?: boolean
  showOnlineStatus?: boolean
  isOnline?: boolean
  position?: 'left' | 'right' | 'top' | 'bottom'
}

const props = withDefaults(defineProps<Props>(), {
  size: 60,
  showInfo: true,
  showCards: true,
  showScore: false,
  showOnlineStatus: false,
  isOnline: true,
  position: 'bottom'
})

// 计算头像容器样式类
const avatarClass = computed(() => {
  const classes = ['avatar-wrapper']
  
  if (props.position) {
    classes.push(`position-${props.position}`)
  }
  
  if (props.player.is_landlord) {
    classes.push('is-landlord')
  }
  
  if (props.player.is_ai) {
    classes.push('is-ai')
  }
  
  return classes
})
</script>

<style scoped>
.player-avatar {
  display: flex;
  align-items: center;
  gap: 12px;
}

.avatar-container {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
}

/* 地主标识 */
.landlord-badge {
  position: absolute;
  top: -4px;
  right: -4px;
  width: 20px;
  height: 20px;
  background: linear-gradient(135deg, #ffd700 0%, #ffb347 100%);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 12px;
  color: #8b4513;
  box-shadow: 0 2px 6px rgba(255, 215, 0, 0.4);
  border: 2px solid white;
}

/* AI标识 */
.ai-badge {
  position: absolute;
  bottom: -4px;
  right: -4px;
  padding: 2px 6px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  font-size: 10px;
  font-weight: bold;
  border-radius: 8px;
  border: 1px solid white;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
}

/* 在线状态 */
.online-status {
  position: absolute;
  bottom: 2px;
  right: 2px;
  width: 12px;
  height: 12px;
  border-radius: 50%;
  background: #909399;
  border: 2px solid white;
}

.online-status.online {
  background: #67c23a;
}

/* 玩家信息 */
.player-info {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.player-name {
  font-size: 14px;
  font-weight: 500;
  color: #333;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  max-width: 100px;
}

.player-details {
  display: flex;
  gap: 8px;
  font-size: 12px;
  color: #666;
}

.card-count {
  color: #409eff;
}

.score {
  color: #f56c6c;
}

/* 位置变体 */
.position-top {
  flex-direction: column-reverse;
  text-align: center;
}

.position-top .player-info {
  align-items: center;
}

.position-bottom {
  flex-direction: column;
  text-align: center;
}

.position-bottom .player-info {
  align-items: center;
}

.position-left {
  flex-direction: row;
}

.position-right {
  flex-direction: row-reverse;
}

.position-right .player-info {
  align-items: flex-end;
  text-align: right;
}

/* 特殊状态样式 */
.is-landlord .avatar-container {
  filter: drop-shadow(0 0 8px rgba(255, 215, 0, 0.6));
}

.is-ai .avatar-container {
  filter: drop-shadow(0 0 6px rgba(102, 126, 234, 0.4));
}

/* 响应式调整 */
@media (max-width: 768px) {
  .player-avatar {
    gap: 8px;
  }
  
  .player-name {
    font-size: 12px;
    max-width: 80px;
  }
  
  .player-details {
    font-size: 11px;
  }
  
  .landlord-badge {
    width: 18px;
    height: 18px;
    font-size: 11px;
  }
  
  .ai-badge {
    font-size: 9px;
    padding: 1px 4px;
  }
}
</style>