<template>
  <div
    class="game-card"
    :class="[
      cardClass,
      {
        selected: isSelected,
        disabled: isDisabled,
        clickable: isClickable
      }
    ]"
    @click="handleClick"
  >
    <div class="card-content">
      <div class="card-rank">{{ cardDisplay.rank }}</div>
      <div class="card-suit" v-html="cardDisplay.suit"></div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import type { Card } from '@/types'

interface Props {
  card: Card
  isSelected?: boolean
  isDisabled?: boolean
  isClickable?: boolean
  size?: 'small' | 'medium' | 'large'
}

interface Emits {
  (e: 'click', card: Card): void
}

const props = withDefaults(defineProps<Props>(), {
  isSelected: false,
  isDisabled: false,
  isClickable: true,
  size: 'medium'
})

const emit = defineEmits<Emits>()

// 计算卡牌显示信息
const cardDisplay = computed(() => {
  const { suit, rank } = props.card
  
  // 大小王处理
  if (suit === 5) return { rank: '小', suit: '王' }
  if (suit === 6) return { rank: '大', suit: '王' }
  
  // 花色符号
  const suitSymbols = {
    1: '♠', // 黑桃
    2: '♥', // 红桃
    3: '♣', // 梅花
    4: '♦'  // 方块
  }
  
  // 点数文字
  const rankTexts = {
    3: '3', 4: '4', 5: '5', 6: '6', 7: '7',
    8: '8', 9: '9', 10: '10', 11: 'J', 12: 'Q',
    13: 'K', 14: 'A', 15: '2'
  }
  
  return {
    rank: rankTexts[rank as keyof typeof rankTexts] || rank.toString(),
    suit: suitSymbols[suit as keyof typeof suitSymbols] || ''
  }
})

// 计算卡牌样式类
const cardClass = computed(() => {
  const classes = ['card-base', `card-${props.size}`]
  
  const { suit } = props.card
  
  // 大小王
  if (suit === 5 || suit === 6) {
    classes.push('joker-card')
  }
  // 红色花色
  else if (suit === 2 || suit === 4) {
    classes.push('red-card')
  }
  // 黑色花色
  else {
    classes.push('black-card')
  }
  
  return classes
})

// 处理点击事件
const handleClick = () => {
  if (props.isClickable && !props.isDisabled) {
    emit('click', props.card)
  }
}
</script>

<style scoped>
.game-card {
  position: relative;
  background: white;
  border: 2px solid #ddd;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  transition: all 0.3s ease;
  user-select: none;
  display: flex;
  align-items: center;
  justify-content: center;
}

/* 尺寸变体 */
.card-small {
  width: 40px;
  height: 56px;
  font-size: 10px;
}

.card-medium {
  width: 50px;
  height: 70px;
  font-size: 12px;
}

.card-large {
  width: 60px;
  height: 84px;
  font-size: 14px;
}

/* 可点击状态 */
.clickable {
  cursor: pointer;
}

.clickable:hover {
  transform: translateY(-4px);
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.2);
}

/* 选中状态 */
.selected {
  transform: translateY(-8px);
  border-color: #409eff;
  box-shadow: 0 6px 20px rgba(64, 158, 255, 0.4);
}

/* 禁用状态 */
.disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.disabled:hover {
  transform: none;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

/* 卡牌内容 */
.card-content {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100%;
  font-weight: bold;
}

.card-rank {
  font-size: 1em;
  line-height: 1;
  margin-bottom: 2px;
}

.card-suit {
  font-size: 0.8em;
  line-height: 1;
}

/* 花色颜色 */
.red-card .card-content {
  color: #f56c6c;
}

.black-card .card-content {
  color: #333;
}

.joker-card {
  background: linear-gradient(135deg, #ff6b6b 0%, #feca57 100%);
  border-color: #ff6b6b;
}

.joker-card .card-content {
  color: white;
  text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.3);
}

/* 响应式调整 */
@media (max-width: 768px) {
  .card-small {
    width: 35px;
    height: 49px;
    font-size: 9px;
  }

  .card-medium {
    width: 45px;
    height: 63px;
    font-size: 11px;
  }

  .card-large {
    width: 55px;
    height: 77px;
    font-size: 13px;
  }
}
</style>