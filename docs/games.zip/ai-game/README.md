# AI斗地主游戏项目

## 项目简介

AI斗地主游戏是一个基于Golang后端和Vue3前端的完整Web应用，支持真人与AI玩家对战，具有智能聊天和游戏辅助功能。

## 技术栈

### 后端
- **语言**: Go 1.21+
- **框架**: Gin Web Framework
- **数据库**: BoltDB (嵌入式键值数据库)
- **认证**: JWT Token
- **WebSocket**: Gorilla WebSocket
- **AI集成**: OpenAI/Claude API

### 前端
- **框架**: Vue 3 + TypeScript
- **构建工具**: Vite
- **UI组件**: Element Plus
- **状态管理**: Pinia
- **网络请求**: Axios
- **实时通信**: Socket.io

## 功能特性

### 用户系统
- [x] 用户注册/登录
- [x] JWT认证
- [x] 用户信息管理
- [x] 游戏统计

### 游戏核心
- [x] 斗地主规则引擎
- [x] 房间管理系统
- [x] 实时游戏状态同步
- [x] 游戏历史记录

### AI系统
- [x] 6个预设AI玩家角色
- [x] 智能出牌决策
- [x] 性格化聊天交互
- [x] AI难度调节

### 聊天系统
- [x] 实时聊天
- [x] AI智能回复
- [x] 聊天记录
- [x] 消息过滤

### 前端界面
- [x] 响应式设计
- [x] 游戏大厅
- [x] 游戏房间界面
- [x] 卡牌动画效果
- [x] 实时状态显示

## 项目结构

```
ai-game/
├── backend/                 # 后端代码
│   ├── cmd/server/         # 主程序入口
│   ├── internal/           # 内部代码
│   │   ├── config/         # 配置管理
│   │   ├── database/       # 数据库连接
│   │   ├── handlers/       # HTTP处理器
│   │   ├── middleware/     # 中间件
│   │   ├── models/         # 数据模型
│   │   ├── repositories/   # 数据访问层
│   │   ├── services/       # 业务逻辑层
│   │   ├── game/          # 游戏核心逻辑
│   │   │   ├── ai/        # AI系统
│   │   │   └── landlord/  # 斗地主规则
│   │   └── utils/         # 工具函数
│   └── pkg/               # 公共包
├── frontend/              # 前端代码
│   ├── src/
│   │   ├── components/    # Vue组件
│   │   ├── views/         # 页面视图
│   │   ├── stores/        # 状态管理
│   │   ├── services/      # API服务
│   │   ├── types/         # 类型定义
│   │   └── utils/         # 工具函数
│   └── public/            # 静态资源
├── configs/               # 配置文件
├── docs/                  # 文档
└── scripts/               # 脚本文件
```

## 快速开始

### 环境要求
- Go 1.21+
- Node.js 16+
- npm 或 yarn

### 安装与运行

1. **克隆项目**
```bash
git clone <repository-url>
cd ai-game
```

2. **启动后端服务**
```bash
cd backend
go mod download
go run cmd/server/main.go
```
后端服务将在 `http://localhost:8081` 启动

3. **启动前端服务**
```bash
cd frontend
npm install
npm run dev
```
前端服务将在 `http://localhost:3000` 启动

### 配置文件

主要配置文件位于 `configs/config.yaml`:

```yaml
server:
  port: 8081
  mode: debug

database:
  path: ./data/game.db

jwt:
  secret: your-secret-key
  expire_time: 24

ai:
  openai:
    api_key: your-openai-api-key
    base_url: https://api.openai.com/v1
  claude:
    api_key: your-claude-api-key
```

## API文档

### 认证接口
- `POST /api/v1/auth/register` - 用户注册
- `POST /api/v1/auth/login` - 用户登录

### 用户接口
- `GET /api/v1/users/profile` - 获取用户信息
- `PUT /api/v1/users/profile` - 更新用户信息

### AI玩家接口
- `GET /api/v1/ai/players` - 获取AI玩家列表
- `POST /api/v1/ai/players` - 创建AI玩家
- `GET /api/v1/ai/players/:id` - 获取AI玩家详情

### 聊天接口
- `POST /api/v1/chat/send` - 发送聊天消息
- `GET /api/v1/chat/rooms/:room_id/messages` - 获取房间消息

### WebSocket事件
- `room:join` - 加入房间
- `room:leave` - 离开房间
- `game:action` - 游戏操作
- `chat:send` - 发送聊天

## AI玩家角色

项目内置6个AI玩家角色：

1. **智能助手** - 理性分析型，擅长逻辑推理
2. **游戏高手** - 技术流玩家，出牌精准
3. **幽默玩家** - 轻松愉快，善于调节气氛
4. **新手玩家** - 谨慎保守，适合练习
5. **冒险家** - 大胆激进，喜欢冒险
6. **沉默寡言** - 少言寡语，专注游戏

每个AI都有独特的:
- 出牌策略
- 聊天风格
- 难度等级
- 性格特征

## 开发指南

### 添加新的AI玩家

1. 在 `backend/internal/game/ai/presets.go` 中定义新角色
2. 配置AI的prompt和参数
3. 实现特定的策略逻辑

### 扩展游戏规则

1. 修改 `backend/internal/game/landlord/` 中的规则引擎
2. 更新前端游戏逻辑
3. 调整AI决策策略

### 自定义UI组件

前端使用Element Plus作为基础UI库，可以:
1. 在 `frontend/src/components/` 中创建自定义组件
2. 使用Vue 3 Composition API
3. 集成TypeScript类型支持

## 部署

### Docker部署
```bash
# 构建镜像
docker build -t ai-game .

# 运行容器
docker run -p 8081:8081 -p 3000:3000 ai-game
```

### 生产环境配置
- 修改配置文件中的数据库路径
- 设置生产环境的JWT密钥
- 配置AI API密钥
- 启用HTTPS

## 贡献

1. Fork项目
2. 创建特性分支
3. 提交更改
4. 推送到分支
5. 创建Pull Request

## 许可证

本项目采用MIT许可证。

## 联系方式

如有问题或建议，请提交Issue或联系开发团队。

---

**注意**: 本项目仅供学习和娱乐使用，请遵守相关法律法规。