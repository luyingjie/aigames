Set-Location C:\Code\ai-game\frontend
npm run dev