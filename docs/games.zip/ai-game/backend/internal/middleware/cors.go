package middleware

import (
	"github.com/gin-contrib/cors"
	"github.com/gin-gonic/gin"
)

// CORSMiddleware 跨域中间件
func CORSMiddleware() gin.HandlerFunc {
	config := cors.DefaultConfig()

	// 允许的来源
	config.AllowOrigins = []string{
		"http://localhost:3000", // Vue开发服务器
		"http://localhost:8080", // 可能的前端端口
		"http://127.0.0.1:3000",
		"http://127.0.0.1:8080",
	}

	// 允许的HTTP方法
	config.AllowMethods = []string{
		"GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS",
	}

	// 允许的请求头
	config.AllowHeaders = []string{
		"Origin", "Content-Length", "Content-Type", "Authorization",
		"X-Requested-With", "Accept", "Accept-Encoding", "Accept-Language",
		"Connection", "Host", "Referer", "User-Agent",
	}

	// 允许凭证
	config.AllowCredentials = true

	// 预检请求的有效期
	config.MaxAge = 12 * 3600 // 12小时

	return cors.New(config)
}

// CustomCORSMiddleware 自定义跨域中间件
func CustomCORSMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		origin := c.GetHeader("Origin")

		// 设置允许的来源
		if origin != "" {
			c.Header("Access-Control-Allow-Origin", origin)
		} else {
			c.Header("Access-Control-Allow-Origin", "*")
		}

		// 设置允许的方法
		c.Header("Access-Control-Allow-Methods", "GET, POST, PUT, PATCH, DELETE, HEAD, OPTIONS")

		// 设置允许的请求头
		c.Header("Access-Control-Allow-Headers", "Origin, Content-Length, Content-Type, Authorization, X-Requested-With, Accept, Accept-Encoding, Accept-Language, Connection, Host, Referer, User-Agent")

		// 允许凭证
		c.Header("Access-Control-Allow-Credentials", "true")

		// 预检请求的有效期
		c.Header("Access-Control-Max-Age", "43200") // 12小时

		// 处理预检请求
		if c.Request.Method == "OPTIONS" {
			c.AbortWithStatus(204)
			return
		}

		c.Next()
	}
}
