package middleware

import (
	"strings"

	"ai-game/internal/models"
	"ai-game/internal/services"
	"ai-game/internal/utils"
	"ai-game/pkg/constants"
	appErrors "ai-game/pkg/errors"
	"ai-game/pkg/logger"

	"github.com/gin-gonic/gin"
)

// AuthMiddleware 认证中间件
func AuthMiddleware(userService services.UserService) gin.HandlerFunc {
	return func(c *gin.Context) {
		// 获取Authorization头
		authHeader := c.GetHeader("Authorization")
		if authHeader == "" {
			utils.ErrorWithCode(c, constants.StatusUnauthorized, "缺少认证令牌")
			c.Abort()
			return
		}

		// 检查Bearer前缀
		const bearerPrefix = "Bearer "
		if !strings.HasPrefix(authHeader, bearerPrefix) {
			utils.ErrorWithCode(c, constants.StatusUnauthorized, "认证令牌格式错误")
			c.Abort()
			return
		}

		// 提取令牌
		token := authHeader[len(bearerPrefix):]
		if token == "" {
			utils.ErrorWithCode(c, constants.StatusUnauthorized, "认证令牌不能为空")
			c.Abort()
			return
		}

		// 验证令牌
		user, err := userService.ValidateToken(token)
		if err != nil {
			logger.Warn("无效的认证令牌: %v", err)
			utils.Error(c, appErrors.ErrInvalidToken)
			c.Abort()
			return
		}

		// 将用户信息存储到上下文
		c.Set("user_id", user.ID)
		c.Set("username", user.Username)
		c.Set("user", user)

		c.Next()
	}
}

// OptionalAuthMiddleware 可选认证中间件(不强制要求认证)
func OptionalAuthMiddleware(userService services.UserService) gin.HandlerFunc {
	return func(c *gin.Context) {
		// 获取Authorization头
		authHeader := c.GetHeader("Authorization")
		if authHeader == "" {
			c.Next()
			return
		}

		// 检查Bearer前缀
		const bearerPrefix = "Bearer "
		if !strings.HasPrefix(authHeader, bearerPrefix) {
			c.Next()
			return
		}

		// 提取令牌
		token := authHeader[len(bearerPrefix):]
		if token == "" {
			c.Next()
			return
		}

		// 验证令牌
		user, err := userService.ValidateToken(token)
		if err != nil {
			// 认证失败但不阻止请求
			logger.Debug("可选认证失败: %v", err)
			c.Next()
			return
		}

		// 将用户信息存储到上下文
		c.Set("user_id", user.ID)
		c.Set("username", user.Username)
		c.Set("user", user)

		c.Next()
	}
}

// AdminMiddleware 管理员权限中间件
func AdminMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		// 检查是否已认证
		userInterface, exists := c.Get("user")
		if !exists {
			utils.ErrorWithCode(c, constants.StatusUnauthorized, "未认证")
			c.Abort()
			return
		}

		user, ok := userInterface.(*models.User)
		if !ok {
			utils.ErrorWithCode(c, constants.StatusUnauthorized, "用户信息错误")
			c.Abort()
			return
		}

		// 简单的管理员检查(实际项目中应该有更完善的权限系统)
		if !isAdminUser(user) {
			utils.ErrorWithCode(c, constants.StatusUnauthorized, "需要管理员权限")
			c.Abort()
			return
		}

		c.Next()
	}
}

// RoleMiddleware 角色权限中间件
func RoleMiddleware(requiredRoles ...string) gin.HandlerFunc {
	return func(c *gin.Context) {
		// 检查是否已认证
		userInterface, exists := c.Get("user")
		if !exists {
			utils.ErrorWithCode(c, constants.StatusUnauthorized, "未认证")
			c.Abort()
			return
		}

		user, ok := userInterface.(*models.User)
		if !ok {
			utils.ErrorWithCode(c, constants.StatusUnauthorized, "用户信息错误")
			c.Abort()
			return
		}

		// 检查用户角色
		if !hasAnyRole(user, requiredRoles) {
			utils.ErrorWithCode(c, constants.StatusUnauthorized, "权限不足")
			c.Abort()
			return
		}

		c.Next()
	}
}

// StatusMiddleware 用户状态检查中间件
func StatusMiddleware(allowedStatuses ...int) gin.HandlerFunc {
	return func(c *gin.Context) {
		// 检查是否已认证
		userInterface, exists := c.Get("user")
		if !exists {
			utils.ErrorWithCode(c, constants.StatusUnauthorized, "未认证")
			c.Abort()
			return
		}

		user, ok := userInterface.(*models.User)
		if !ok {
			utils.ErrorWithCode(c, constants.StatusUnauthorized, "用户信息错误")
			c.Abort()
			return
		}

		// 检查用户状态
		if !contains(allowedStatuses, user.Status) {
			statusName := getUserStatusName(user.Status)
			utils.ErrorWithCode(c, constants.StatusBadRequest, "当前用户状态不允许此操作: "+statusName)
			c.Abort()
			return
		}

		c.Next()
	}
}

// 辅助函数

// isAdminUser 检查是否为管理员用户
func isAdminUser(user *models.User) bool {
	// 简单实现：用户名为admin或者有管理员标识
	return user.Username == "admin" || user.Level >= 100
}

// hasAnyRole 检查用户是否具有任一指定角色
func hasAnyRole(user *models.User, roles []string) bool {
	// 简单实现，实际项目中应该有角色表
	userRoles := getUserRoles(user)

	for _, requiredRole := range roles {
		for _, userRole := range userRoles {
			if userRole == requiredRole {
				return true
			}
		}
	}
	return false
}

// getUserRoles 获取用户角色列表
func getUserRoles(user *models.User) []string {
	// 简单实现，实际项目中应该查询角色表
	roles := []string{"user"} // 所有用户都有user角色

	if isAdminUser(user) {
		roles = append(roles, "admin")
	}

	// 可以根据用户等级或其他条件添加更多角色
	if user.Level >= 50 {
		roles = append(roles, "vip")
	}

	return roles
}

// contains 检查切片是否包含指定元素
func contains(slice []int, item int) bool {
	for _, s := range slice {
		if s == item {
			return true
		}
	}
	return false
}

// getUserStatusName 获取用户状态名称
func getUserStatusName(status int) string {
	switch status {
	case constants.UserStatusOffline:
		return "离线"
	case constants.UserStatusOnline:
		return "在线"
	case constants.UserStatusInGame:
		return "游戏中"
	default:
		return "未知"
	}
}
