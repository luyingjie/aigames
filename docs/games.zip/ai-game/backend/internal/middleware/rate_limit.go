package middleware

import (
	"net/http"
	"sync"
	"time"

	"ai-game/internal/utils"

	"github.com/gin-gonic/gin"
)

// RateLimiter 限流器接口
type RateLimiter interface {
	Allow(key string) bool
	Reset(key string)
}

// TokenBucket 令牌桶限流器
type TokenBucket struct {
	capacity int           // 桶容量
	tokens   int           // 当前令牌数
	rate     time.Duration // 令牌添加间隔
	lastTime time.Time     // 上次添加令牌时间
	mutex    sync.Mutex    // 互斥锁
}

// NewTokenBucket 创建令牌桶
func NewTokenBucket(capacity int, rate time.Duration) *TokenBucket {
	return &TokenBucket{
		capacity: capacity,
		tokens:   capacity,
		rate:     rate,
		lastTime: time.Now(),
	}
}

// Allow 检查是否允许请求
func (tb *TokenBucket) Allow(key string) bool {
	tb.mutex.Lock()
	defer tb.mutex.Unlock()

	now := time.Now()
	// 添加令牌
	elapsed := now.Sub(tb.lastTime)
	tokensToAdd := int(elapsed / tb.rate)

	if tokensToAdd > 0 {
		tb.tokens += tokensToAdd
		if tb.tokens > tb.capacity {
			tb.tokens = tb.capacity
		}
		tb.lastTime = now
	}

	// 检查是否有可用令牌
	if tb.tokens > 0 {
		tb.tokens--
		return true
	}

	return false
}

// Reset 重置令牌桶
func (tb *TokenBucket) Reset(key string) {
	tb.mutex.Lock()
	defer tb.mutex.Unlock()

	tb.tokens = tb.capacity
	tb.lastTime = time.Now()
}

// MemoryLimiter 基于内存的限流器
type MemoryLimiter struct {
	buckets  map[string]*TokenBucket
	mutex    sync.RWMutex
	capacity int
	rate     time.Duration
}

// NewMemoryLimiter 创建内存限流器
func NewMemoryLimiter(capacity int, rate time.Duration) *MemoryLimiter {
	return &MemoryLimiter{
		buckets:  make(map[string]*TokenBucket),
		capacity: capacity,
		rate:     rate,
	}
}

// Allow 检查是否允许请求
func (ml *MemoryLimiter) Allow(key string) bool {
	ml.mutex.RLock()
	bucket, exists := ml.buckets[key]
	ml.mutex.RUnlock()

	if !exists {
		ml.mutex.Lock()
		// 双重检查
		if bucket, exists = ml.buckets[key]; !exists {
			bucket = NewTokenBucket(ml.capacity, ml.rate)
			ml.buckets[key] = bucket
		}
		ml.mutex.Unlock()
	}

	return bucket.Allow(key)
}

// Reset 重置指定键的限流器
func (ml *MemoryLimiter) Reset(key string) {
	ml.mutex.RLock()
	bucket, exists := ml.buckets[key]
	ml.mutex.RUnlock()

	if exists {
		bucket.Reset(key)
	}
}

// CleanUp 清理过期的限流器
func (ml *MemoryLimiter) CleanUp() {
	ml.mutex.Lock()
	defer ml.mutex.Unlock()

	now := time.Now()
	for key, bucket := range ml.buckets {
		// 如果超过10分钟没有使用，则删除
		if now.Sub(bucket.lastTime) > 10*time.Minute {
			delete(ml.buckets, key)
		}
	}
}

// RateLimitMiddleware 限流中间件
func RateLimitMiddleware(limiter RateLimiter) gin.HandlerFunc {
	return func(c *gin.Context) {
		// 使用客户端IP作为限流键
		key := c.ClientIP()

		if !limiter.Allow(key) {
			utils.ErrorWithCode(c, http.StatusTooManyRequests, "请求过于频繁，请稍后再试")
			c.Abort()
			return
		}

		c.Next()
	}
}

// UserRateLimitMiddleware 基于用户的限流中间件
func UserRateLimitMiddleware(limiter RateLimiter) gin.HandlerFunc {
	return func(c *gin.Context) {
		// 优先使用用户ID，如果未认证则使用IP
		key := c.ClientIP()
		if userID, exists := c.Get("user_id"); exists {
			if id, ok := userID.(string); ok {
				key = "user:" + id
			}
		}

		if !limiter.Allow(key) {
			utils.ErrorWithCode(c, http.StatusTooManyRequests, "请求过于频繁，请稍后再试")
			c.Abort()
			return
		}

		c.Next()
	}
}

// APIRateLimitMiddleware API限流中间件
func APIRateLimitMiddleware(limiter RateLimiter, keyFunc func(*gin.Context) string) gin.HandlerFunc {
	return func(c *gin.Context) {
		key := keyFunc(c)

		if !limiter.Allow(key) {
			utils.ErrorWithCode(c, http.StatusTooManyRequests, "API调用过于频繁，请稍后再试")
			c.Abort()
			return
		}

		c.Next()
	}
}

// 预定义的限流器

// DefaultLimiter 默认限流器：每秒10个请求
var DefaultLimiter = NewMemoryLimiter(10, 100*time.Millisecond)

// AuthLimiter 认证接口限流器：每分钟5个请求
var AuthLimiter = NewMemoryLimiter(5, 12*time.Second)

// GameLimiter 游戏接口限流器：每秒20个请求
var GameLimiter = NewMemoryLimiter(20, 50*time.Millisecond)

// ChatLimiter 聊天限流器：每分钟30条消息
var ChatLimiter = NewMemoryLimiter(30, 2*time.Second)

// 预定义的中间件

// DefaultRateLimit 默认限流中间件
func DefaultRateLimit() gin.HandlerFunc {
	return RateLimitMiddleware(DefaultLimiter)
}

// AuthRateLimit 认证接口限流中间件
func AuthRateLimit() gin.HandlerFunc {
	return RateLimitMiddleware(AuthLimiter)
}

// GameRateLimit 游戏接口限流中间件
func GameRateLimit() gin.HandlerFunc {
	return UserRateLimitMiddleware(GameLimiter)
}

// ChatRateLimit 聊天限流中间件
func ChatRateLimit() gin.HandlerFunc {
	return UserRateLimitMiddleware(ChatLimiter)
}
