package middleware

import (
	"time"

	"ai-game/pkg/logger"

	"github.com/gin-gonic/gin"
)

// LoggerMiddleware 日志中间件
func LoggerMiddleware() gin.HandlerFunc {
	return gin.LoggerWithFormatter(func(param gin.LogFormatterParams) string {
		// 记录请求日志
		logger.Info("[%s] %s %s %d %s %s %s",
			param.TimeStamp.Format("2006-01-02 15:04:05"),
			param.Method,
			param.Path,
			param.StatusCode,
			param.Latency,
			param.ClientIP,
			param.ErrorMessage,
		)
		return ""
	})
}

// CustomLoggerMiddleware 自定义日志中间件
func CustomLoggerMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		start := time.Now()
		path := c.Request.URL.Path
		method := c.Request.Method
		clientIP := c.ClientIP()
		userAgent := c.Request.UserAgent()

		// 处理请求
		c.Next()

		// 计算处理时间
		latency := time.Since(start)
		statusCode := c.Writer.Status()

		// 获取错误信息
		errorMessage := c.Errors.ByType(gin.ErrorTypePrivate).String()

		// 记录日志
		logLevel := getLogLevel(statusCode)
		logMessage := formatLogMessage(method, path, statusCode, latency, clientIP, userAgent, errorMessage)

		switch logLevel {
		case "error":
			logger.Error(logMessage)
		case "warn":
			logger.Warn(logMessage)
		case "info":
			logger.Info(logMessage)
		default:
			logger.Debug(logMessage)
		}
	}
}

// getLogLevel 根据状态码确定日志级别
func getLogLevel(statusCode int) string {
	switch {
	case statusCode >= 500:
		return "error"
	case statusCode >= 400:
		return "warn"
	case statusCode >= 300:
		return "info"
	default:
		return "debug"
	}
}

// formatLogMessage 格式化日志消息
func formatLogMessage(method, path string, statusCode int, latency time.Duration, clientIP, userAgent, errorMessage string) string {
	message := ""
	message += "[" + method + "] "
	message += path + " "
	message += "| " + string(rune(statusCode/100)) + string(rune((statusCode/10)%10)) + string(rune(statusCode%10)) + " "
	message += "| " + latency.String() + " "
	message += "| " + clientIP + " "

	if errorMessage != "" {
		message += "| ERROR: " + errorMessage
	}

	return message
}
