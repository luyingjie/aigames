package models

import (
	"time"
)

// WSMessage WebSocket消息结构
type WSMessage struct {
	Type      string      `json:"type"`       // 消息类型
	Action    string      `json:"action"`     // 操作动作
	Data      interface{} `json:"data"`       // 消息数据
	Timestamp int64       `json:"timestamp"`  // 时间戳
	RequestID string      `json:"request_id"` // 请求ID，用于响应匹配
}

// NewWSMessage 创建新的WebSocket消息
func NewWSMessage(msgType, action string, data interface{}) *WSMessage {
	return &WSMessage{
		Type:      msgType,
		Action:    action,
		Data:      data,
		Timestamp: time.Now().Unix(),
	}
}

// ConnectData 连接数据
type ConnectData struct {
	UserID   string `json:"user_id"`   // 用户ID
	Token    string `json:"token"`     // 认证令牌
	ClientID string `json:"client_id"` // 客户端ID
}

// HeartbeatData 心跳数据
type HeartbeatData struct {
	Timestamp int64 `json:"timestamp"` // 时间戳
}

// RoomUpdateData 房间更新数据
type RoomUpdateData struct {
	Room   *Room  `json:"room"`   // 房间信息
	Action string `json:"action"` // 更新动作：join, leave, ready, start
}

// GameStartData 游戏开始数据
type GameStartData struct {
	Game      *Game  `json:"game"`       // 游戏信息
	HandCards []Card `json:"hand_cards"` // 当前玩家手牌
	Position  int    `json:"position"`   // 玩家位置
}

// GameStateData 游戏状态数据
type GameStateData struct {
	Game        *Game  `json:"game"`         // 游戏信息
	HandCards   []Card `json:"hand_cards"`   // 当前玩家手牌
	CurrentTurn int    `json:"current_turn"` // 当前回合
	Phase       int    `json:"phase"`        // 游戏阶段
	TimeLeft    int    `json:"time_left"`    // 剩余时间(秒)
}

// BidLandlordData 叫地主数据
type BidLandlordData struct {
	PlayerPos int  `json:"player_pos"` // 玩家位置
	Bid       bool `json:"bid"`        // 是否叫地主
}

// PlayCardsData 出牌数据
type PlayCardsData struct {
	PlayerPos int    `json:"player_pos"` // 玩家位置
	Cards     []Card `json:"cards"`      // 出的牌
	Type      int    `json:"type"`       // 出牌类型
	IsPass    bool   `json:"is_pass"`    // 是否过牌
}

// GameEndData 游戏结束数据
type GameEndData struct {
	Winner     int            `json:"winner"`      // 获胜方
	WinnerPos  int            `json:"winner_pos"`  // 获胜玩家位置
	Scores     map[string]int `json:"scores"`      // 玩家得分变化
	GameResult *GameResult    `json:"game_result"` // 游戏结果详情
}

// GameResult 游戏结果
type GameResult struct {
	GameID      string                `json:"game_id"`      // 游戏ID
	Duration    int                   `json:"duration"`     // 游戏时长(秒)
	Winner      int                   `json:"winner"`       // 获胜方
	PlayerStats map[string]PlayerStat `json:"player_stats"` // 玩家统计
	Multiplier  int                   `json:"multiplier"`   // 倍数
}

// PlayerStat 玩家游戏统计
type PlayerStat struct {
	UserID      string `json:"user_id"`      // 用户ID
	Role        int    `json:"role"`         // 角色
	Won         bool   `json:"won"`          // 是否获胜
	ScoreChange int    `json:"score_change"` // 积分变化
	CardsLeft   int    `json:"cards_left"`   // 剩余手牌数
	PlayCount   int    `json:"play_count"`   // 出牌次数
	PassCount   int    `json:"pass_count"`   // 过牌次数
}

// ChatMessageData 聊天消息数据
type ChatMessageData struct {
	ID        string    `json:"id"`        // 消息ID
	RoomID    string    `json:"room_id"`   // 房间ID
	UserID    string    `json:"user_id"`   // 发送者ID
	Username  string    `json:"username"`  // 发送者用户名
	Nickname  string    `json:"nickname"`  // 发送者昵称
	Avatar    string    `json:"avatar"`    // 发送者头像
	Message   string    `json:"message"`   // 消息内容
	IsAI      bool      `json:"is_ai"`     // 是否为AI消息
	Timestamp time.Time `json:"timestamp"` // 发送时间
}

// ErrorData 错误数据
type ErrorData struct {
	Code    int    `json:"code"`    // 错误码
	Message string `json:"message"` // 错误消息
	Details string `json:"details"` // 详细信息
}

// NotificationData 通知数据
type NotificationData struct {
	Type    string `json:"type"`    // 通知类型
	Title   string `json:"title"`   // 通知标题
	Message string `json:"message"` // 通知内容
	Level   string `json:"level"`   // 通知级别：info, warning, error
}

// PlayerActionData 玩家操作数据
type PlayerActionData struct {
	PlayerPos int         `json:"player_pos"` // 玩家位置
	Action    string      `json:"action"`     // 操作类型
	Data      interface{} `json:"data"`       // 操作数据
}

// Client WebSocket客户端
type Client struct {
	ID       string      // 客户端ID
	UserID   string      // 用户ID
	RoomID   string      // 所在房间ID
	Send     chan []byte // 发送通道
	Hub      *Hub        // 所属Hub
	Conn     interface{} // WebSocket连接(具体实现时使用*websocket.Conn)
	LastPing time.Time   // 最后心跳时间
}

// Hub WebSocket连接中心
type Hub struct {
	Clients    map[*Client]bool     // 已连接的客户端
	Broadcast  chan []byte          // 广播通道
	Register   chan *Client         // 注册通道
	Unregister chan *Client         // 注销通道
	Rooms      map[string][]*Client // 房间内的客户端
}

// NewHub 创建新的Hub
func NewHub() *Hub {
	return &Hub{
		Clients:    make(map[*Client]bool),
		Broadcast:  make(chan []byte),
		Register:   make(chan *Client),
		Unregister: make(chan *Client),
		Rooms:      make(map[string][]*Client),
	}
}

// AddClientToRoom 添加客户端到房间
func (h *Hub) AddClientToRoom(roomID string, client *Client) {
	if h.Rooms[roomID] == nil {
		h.Rooms[roomID] = make([]*Client, 0)
	}
	h.Rooms[roomID] = append(h.Rooms[roomID], client)
	client.RoomID = roomID
}

// RemoveClientFromRoom 从房间移除客户端
func (h *Hub) RemoveClientFromRoom(roomID string, client *Client) {
	if clients, exists := h.Rooms[roomID]; exists {
		for i, c := range clients {
			if c == client {
				h.Rooms[roomID] = append(clients[:i], clients[i+1:]...)
				break
			}
		}
		// 如果房间为空，删除房间
		if len(h.Rooms[roomID]) == 0 {
			delete(h.Rooms, roomID)
		}
	}
	client.RoomID = ""
}

// BroadcastToRoom 向指定房间广播消息
func (h *Hub) BroadcastToRoom(roomID string, message []byte) {
	if clients, exists := h.Rooms[roomID]; exists {
		for _, client := range clients {
			select {
			case client.Send <- message:
			default:
				// 客户端发送缓冲区满，关闭连接
				close(client.Send)
				delete(h.Clients, client)
				h.RemoveClientFromRoom(roomID, client)
			}
		}
	}
}

// GetRoomClients 获取房间内的所有客户端
func (h *Hub) GetRoomClients(roomID string) []*Client {
	if clients, exists := h.Rooms[roomID]; exists {
		return clients
	}
	return nil
}

// GetClientByUserID 根据用户ID获取客户端
func (h *Hub) GetClientByUserID(userID string) *Client {
	for client := range h.Clients {
		if client.UserID == userID {
			return client
		}
	}
	return nil
}

// Run 运行Hub
func (h *Hub) Run() {
	for {
		select {
		case client := <-h.Register:
			h.Clients[client] = true

		case client := <-h.Unregister:
			if _, ok := h.Clients[client]; ok {
				delete(h.Clients, client)
				close(client.Send)
				// 从所有房间移除
				for roomID := range h.Rooms {
					h.RemoveClientFromRoom(roomID, client)
				}
			}

		case message := <-h.Broadcast:
			for client := range h.Clients {
				select {
				case client.Send <- message:
				default:
					close(client.Send)
					delete(h.Clients, client)
				}
			}
		}
	}
}
