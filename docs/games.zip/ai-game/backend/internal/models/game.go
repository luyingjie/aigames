package models

import (
	"time"
)

// Card 扑克牌结构
type Card struct {
	Suit int `json:"suit"` // 花色：1-黑桃 2-红桃 3-方片 4-梅花
	Rank int `json:"rank"` // 点数：3-17(3-10,J,Q,K,A,2,小王,大王)
}

// String 返回牌面的字符串表示
func (c Card) String() string {
	suitNames := map[int]string{1: "♠", 2: "♥", 3: "♦", 4: "♣"}
	rankNames := map[int]string{
		3: "3", 4: "4", 5: "5", 6: "6", 7: "7", 8: "8", 9: "9", 10: "10",
		11: "J", 12: "Q", 13: "K", 14: "A", 15: "2", 16: "小王", 17: "大王",
	}

	if c.Rank >= 16 { // 大小王没有花色
		return rankNames[c.Rank]
	}
	return suitNames[c.Suit] + rankNames[c.Rank]
}

// IsJoker 判断是否为王牌
func (c Card) IsJoker() bool {
	return c.Rank >= 16
}

// Value 获取牌的大小值(用于比较)
func (c Card) Value() int {
	return c.Rank
}

// PlayCards 出牌结构
type PlayCards struct {
	PlayerID string `json:"player_id"` // 出牌玩家ID
	Cards    []Card `json:"cards"`     // 出的牌
	Type     int    `json:"type"`      // 出牌类型
	MainRank int    `json:"main_rank"` // 主要点数(用于比较大小)
	Length   int    `json:"length"`    // 牌型长度(顺子、连对等)
}

// IsEmpty 判断是否为空(过牌)
func (p PlayCards) IsEmpty() bool {
	return len(p.Cards) == 0
}

// CanBeat 判断是否能压过另一手牌
func (p PlayCards) CanBeat(other PlayCards) bool {
	// 如果对方过牌，任何牌都能出
	if other.IsEmpty() {
		return true
	}

	// 王炸可以压过任何牌
	if p.Type == 14 { // TypeJokerBomb
		return true
	}

	// 炸弹可以压过非炸弹
	if p.Type == 13 && other.Type != 13 && other.Type != 14 { // TypeBomb
		return true
	}

	// 同类型牌型才能比较
	if p.Type != other.Type {
		return false
	}

	// 比较主要点数
	return p.MainRank > other.MainRank
}

// Player 游戏中的玩家
type Player struct {
	UserID     string    `json:"user_id"`                // 用户ID
	Nickname   string    `json:"nickname"`               // 昵称
	Avatar     string    `json:"avatar"`                 // 头像
	Score      int       `json:"score"`                  // 当前积分
	IsAI       bool      `json:"is_ai"`                  // 是否为AI玩家
	AIPlayerID string    `json:"ai_player_id,omitempty"` // AI玩家ID(如果是AI)
	Role       int       `json:"role"`                   // 角色：0-未分配 1-地主 2-农民
	HandCards  []Card    `json:"hand_cards"`             // 手牌
	Position   int       `json:"position"`               // 座位位置：0,1,2
	IsReady    bool      `json:"is_ready"`               // 是否准备
	IsCurrent  bool      `json:"is_current"`             // 是否当前回合
	LastPlay   PlayCards `json:"last_play"`              // 上次出牌
	JoinAt     time.Time `json:"join_at"`                // 加入时间
}

// CardCount 获取手牌数量
func (p *Player) CardCount() int {
	return len(p.HandCards)
}

// HasCard 检查是否有指定牌
func (p *Player) HasCard(card Card) bool {
	for _, c := range p.HandCards {
		if c.Suit == card.Suit && c.Rank == card.Rank {
			return true
		}
	}
	return false
}

// RemoveCards 移除指定的牌
func (p *Player) RemoveCards(cards []Card) bool {
	for _, card := range cards {
		found := false
		for i, c := range p.HandCards {
			if c.Suit == card.Suit && c.Rank == card.Rank {
				p.HandCards = append(p.HandCards[:i], p.HandCards[i+1:]...)
				found = true
				break
			}
		}
		if !found {
			return false // 没有找到要移除的牌
		}
	}
	return true
}

// IsWinner 检查是否获胜(手牌为空)
func (p *Player) IsWinner() bool {
	return len(p.HandCards) == 0
}

// Game 游戏模型
type Game struct {
	ID          string     `json:"id" bolt:"id"`                     // 游戏ID
	RoomID      string     `json:"room_id" bolt:"room_id"`           // 房间ID
	Players     []Player   `json:"players" bolt:"players"`           // 玩家列表
	Phase       int        `json:"phase" bolt:"phase"`               // 游戏阶段
	CurrentTurn int        `json:"current_turn" bolt:"current_turn"` // 当前回合玩家位置
	LandlordPos int        `json:"landlord_pos" bolt:"landlord_pos"` // 地主位置
	HoleCards   []Card     `json:"hole_cards" bolt:"hole_cards"`     // 底牌
	LastPlay    PlayCards  `json:"last_play" bolt:"last_play"`       // 最后出牌
	LastPlayer  int        `json:"last_player" bolt:"last_player"`   // 最后出牌玩家位置
	PlayHistory []GamePlay `json:"play_history" bolt:"play_history"` // 出牌历史
	Winner      int        `json:"winner" bolt:"winner"`             // 获胜方：0-未结束 1-地主胜 2-农民胜
	StartAt     time.Time  `json:"start_at" bolt:"start_at"`         // 开始时间
	EndAt       time.Time  `json:"end_at" bolt:"end_at"`             // 结束时间
	Status      int        `json:"status" bolt:"status"`             // 游戏状态：0-等待 1-进行中 2-已结束
}

// GamePlay 游戏出牌记录
type GamePlay struct {
	PlayerPos int       `json:"player_pos"` // 出牌玩家位置
	Cards     []Card    `json:"cards"`      // 出的牌
	Type      int       `json:"type"`       // 出牌类型
	IsPass    bool      `json:"is_pass"`    // 是否过牌
	Timestamp time.Time `json:"timestamp"`  // 出牌时间
}

// GetPlayer 根据位置获取玩家
func (g *Game) GetPlayer(position int) *Player {
	if position >= 0 && position < len(g.Players) {
		return &g.Players[position]
	}
	return nil
}

// GetCurrentPlayer 获取当前回合玩家
func (g *Game) GetCurrentPlayer() *Player {
	return g.GetPlayer(g.CurrentTurn)
}

// GetLandlord 获取地主玩家
func (g *Game) GetLandlord() *Player {
	return g.GetPlayer(g.LandlordPos)
}

// NextTurn 切换到下一个玩家回合
func (g *Game) NextTurn() {
	g.CurrentTurn = (g.CurrentTurn + 1) % len(g.Players)
	// 更新玩家的isCurrent状态
	for i := range g.Players {
		g.Players[i].IsCurrent = (i == g.CurrentTurn)
	}
}

// IsFinished 检查游戏是否结束
func (g *Game) IsFinished() bool {
	return g.Status == 2 || g.Winner > 0
}

// GetWinnerSide 获取获胜方
func (g *Game) GetWinnerSide() int {
	if g.Winner > 0 {
		return g.Winner
	}

	// 检查是否有玩家手牌为空
	for _, player := range g.Players {
		if player.IsWinner() {
			if player.Role == 1 { // 地主获胜
				g.Winner = 1
			} else { // 农民获胜
				g.Winner = 2
			}
			return g.Winner
		}
	}

	return 0 // 游戏未结束
}

// AddPlayHistory 添加出牌历史
func (g *Game) AddPlayHistory(playerPos int, cards []Card, playType int, isPass bool) {
	play := GamePlay{
		PlayerPos: playerPos,
		Cards:     cards,
		Type:      playType,
		IsPass:    isPass,
		Timestamp: time.Now(),
	}
	g.PlayHistory = append(g.PlayHistory, play)
}
