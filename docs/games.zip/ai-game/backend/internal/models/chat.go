package models

import (
	"time"
)

// ChatMessage 聊天消息模型
type ChatMessage struct {
	ID       string                 `json:"id" bolt:"id"`               // 消息ID
	RoomID   string                 `json:"room_id" bolt:"room_id"`     // 房间ID
	UserID   string                 `json:"user_id" bolt:"user_id"`     // 发送者ID
	Username string                 `json:"username" bolt:"username"`   // 发送者用户名
	Nickname string                 `json:"nickname" bolt:"nickname"`   // 发送者昵称
	Avatar   string                 `json:"avatar" bolt:"avatar"`       // 发送者头像
	Content  string                 `json:"content" bolt:"content"`     // 消息内容
	Type     int                    `json:"type" bolt:"type"`           // 消息类型：1-文本 2-表情 3-系统消息
	IsAI     bool                   `json:"is_ai" bolt:"is_ai"`         // 是否为AI消息
	AIPlayer string                 `json:"ai_player" bolt:"ai_player"` // AI玩家ID(如果是AI消息)
	Metadata map[string]interface{} `json:"metadata" bolt:"metadata"`   // 扩展数据
	Status   int                    `json:"status" bolt:"status"`       // 消息状态：1-正常 2-已删除 3-已屏蔽
	CreateAt time.Time              `json:"create_at" bolt:"create_at"` // 创建时间
	UpdateAt time.Time              `json:"update_at" bolt:"update_at"` // 更新时间
}

// ToWebSocketData 转换为WebSocket数据格式
func (cm *ChatMessage) ToWebSocketData() *ChatMessageData {
	return &ChatMessageData{
		ID:        cm.ID,
		RoomID:    cm.RoomID,
		UserID:    cm.UserID,
		Username:  cm.Username,
		Nickname:  cm.Nickname,
		Avatar:    cm.Avatar,
		Message:   cm.Content,
		IsAI:      cm.IsAI,
		Timestamp: cm.CreateAt,
	}
}

// FromWebSocketData 从WebSocket数据创建ChatMessage
func (cm *ChatMessage) FromWebSocketData(data *ChatMessageData) {
	cm.ID = data.ID
	cm.RoomID = data.RoomID
	cm.UserID = data.UserID
	cm.Username = data.Username
	cm.Nickname = data.Nickname
	cm.Avatar = data.Avatar
	cm.Content = data.Message
	cm.Type = 1 // 默认为文本消息
	cm.IsAI = data.IsAI
	cm.Status = 1 // 默认为正常状态
	cm.CreateAt = data.Timestamp
	cm.UpdateAt = data.Timestamp
}

// IsNormal 检查消息是否为正常状态
func (cm *ChatMessage) IsNormal() bool {
	return cm.Status == 1
}

// IsDeleted 检查消息是否已删除
func (cm *ChatMessage) IsDeleted() bool {
	return cm.Status == 2
}

// IsBlocked 检查消息是否已屏蔽
func (cm *ChatMessage) IsBlocked() bool {
	return cm.Status == 3
}

// IsTextMessage 检查是否为文本消息
func (cm *ChatMessage) IsTextMessage() bool {
	return cm.Type == 1
}

// IsEmojiMessage 检查是否为表情消息
func (cm *ChatMessage) IsEmojiMessage() bool {
	return cm.Type == 2
}

// IsSystemMessage 检查是否为系统消息
func (cm *ChatMessage) IsSystemMessage() bool {
	return cm.Type == 3
}

// MarkAsDeleted 标记为已删除
func (cm *ChatMessage) MarkAsDeleted() {
	cm.Status = 2
	cm.UpdateAt = time.Now()
}

// MarkAsBlocked 标记为已屏蔽
func (cm *ChatMessage) MarkAsBlocked() {
	cm.Status = 3
	cm.UpdateAt = time.Now()
}

// CreateChatMessageRequest 创建聊天消息请求
type CreateChatMessageRequest struct {
	RoomID   string                 `json:"room_id" binding:"required"` // 房间ID
	Content  string                 `json:"content" binding:"required"` // 消息内容
	Type     int                    `json:"type" binding:"min=1,max=3"` // 消息类型
	Metadata map[string]interface{} `json:"metadata"`                   // 扩展数据
}

// UpdateChatMessageRequest 更新聊天消息请求
type UpdateChatMessageRequest struct {
	Content  string                 `json:"content"`  // 消息内容
	Status   int                    `json:"status"`   // 消息状态
	Metadata map[string]interface{} `json:"metadata"` // 扩展数据
}

// ChatMessageListResponse 聊天消息列表响应
type ChatMessageListResponse struct {
	ID       string                 `json:"id"`        // 消息ID
	RoomID   string                 `json:"room_id"`   // 房间ID
	UserID   string                 `json:"user_id"`   // 发送者ID
	Username string                 `json:"username"`  // 发送者用户名
	Nickname string                 `json:"nickname"`  // 发送者昵称
	Avatar   string                 `json:"avatar"`    // 发送者头像
	Content  string                 `json:"content"`   // 消息内容
	Type     int                    `json:"type"`      // 消息类型
	IsAI     bool                   `json:"is_ai"`     // 是否为AI消息
	AIPlayer string                 `json:"ai_player"` // AI玩家ID
	Metadata map[string]interface{} `json:"metadata"`  // 扩展数据
	CreateAt time.Time              `json:"create_at"` // 创建时间
}

// ToListResponse 转换为列表响应格式
func (cm *ChatMessage) ToListResponse() *ChatMessageListResponse {
	return &ChatMessageListResponse{
		ID:       cm.ID,
		RoomID:   cm.RoomID,
		UserID:   cm.UserID,
		Username: cm.Username,
		Nickname: cm.Nickname,
		Avatar:   cm.Avatar,
		Content:  cm.Content,
		Type:     cm.Type,
		IsAI:     cm.IsAI,
		AIPlayer: cm.AIPlayer,
		Metadata: cm.Metadata,
		CreateAt: cm.CreateAt,
	}
}

// ChatRoomInfo 聊天房间信息
type ChatRoomInfo struct {
	RoomID            string    `json:"room_id"`             // 房间ID
	MessageCount      int       `json:"message_count"`       // 消息总数
	LastMessageTime   time.Time `json:"last_message_time"`   // 最后消息时间
	LastMessage       string    `json:"last_message"`        // 最后消息内容
	LastMessageSender string    `json:"last_message_sender"` // 最后消息发送者
	ActiveUsers       int       `json:"active_users"`        // 活跃用户数
}

// MessageType 消息类型常量
const (
	MessageTypeText   = 1 // 文本消息
	MessageTypeEmoji  = 2 // 表情消息
	MessageTypeSystem = 3 // 系统消息
)

// MessageStatus 消息状态常量
const (
	MessageStatusNormal  = 1 // 正常
	MessageStatusDeleted = 2 // 已删除
	MessageStatusBlocked = 3 // 已屏蔽
)
