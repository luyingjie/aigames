package models

import (
	"time"
)

// Room 游戏房间模型
type Room struct {
	ID          string     `json:"id" bolt:"id"`                               // 房间ID
	Name        string     `json:"name" bolt:"name"`                           // 房间名称
	Description string     `json:"description" bolt:"description"`             // 房间描述
	Capacity    int        `json:"capacity" bolt:"capacity"`                   // 房间容量(通常为3)
	Password    string     `json:"-" bolt:"password"`                          // 房间密码(私有房间)
	IsPrivate   bool       `json:"is_private" bolt:"is_private"`               // 是否为私有房间
	OwnerID     string     `json:"owner_id" bolt:"owner_id"`                   // 房主ID
	Players     []Player   `json:"players" bolt:"players"`                     // 房间内玩家
	CurrentGame *Game      `json:"current_game,omitempty" bolt:"current_game"` // 当前游戏
	Status      int        `json:"status" bolt:"status"`                       // 房间状态：0-等待 1-游戏中 2-已关闭
	CreateAt    time.Time  `json:"create_at" bolt:"create_at"`                 // 创建时间
	UpdateAt    time.Time  `json:"update_at" bolt:"update_at"`                 // 更新时间
	Config      RoomConfig `json:"config" bolt:"config"`                       // 房间配置
}

// RoomConfig 房间配置
type RoomConfig struct {
	GameTimeout    int  `json:"game_timeout"`    // 游戏超时时间(秒)
	BiddingTimeout int  `json:"bidding_timeout"` // 叫地主超时时间(秒)
	PlayTimeout    int  `json:"play_timeout"`    // 出牌超时时间(秒)
	AllowAI        bool `json:"allow_ai"`        // 是否允许AI玩家
	AutoStart      bool `json:"auto_start"`      // 是否自动开始
	ScoreMultiple  int  `json:"score_multiple"`  // 积分倍数
}

// CreateRoomRequest 创建房间请求
type CreateRoomRequest struct {
	Name        string     `json:"name" binding:"required,min=1,max=50"` // 房间名称
	Description string     `json:"description" binding:"max=200"`        // 房间描述
	Password    string     `json:"password" binding:"max=20"`            // 房间密码
	Config      RoomConfig `json:"config"`                               // 房间配置
}

// JoinRoomRequest 加入房间请求
type JoinRoomRequest struct {
	RoomID   string `json:"room_id" binding:"required"`     // 房间ID
	Password string `json:"password"`                       // 房间密码(私有房间需要)
	Position int    `json:"position" binding:"min=0,max=2"` // 指定座位位置(可选)
}

// RoomListResponse 房间列表响应
type RoomListResponse struct {
	ID          string    `json:"id"`           // 房间ID
	Name        string    `json:"name"`         // 房间名称
	Description string    `json:"description"`  // 房间描述
	PlayerCount int       `json:"player_count"` // 当前玩家数
	Capacity    int       `json:"capacity"`     // 房间容量
	IsPrivate   bool      `json:"is_private"`   // 是否私有房间
	Status      int       `json:"status"`       // 房间状态
	OwnerName   string    `json:"owner_name"`   // 房主昵称
	CreateAt    time.Time `json:"create_at"`    // 创建时间
}

// PlayerCount 获取房间内玩家数量
func (r *Room) PlayerCount() int {
	return len(r.Players)
}

// IsFull 检查房间是否已满
func (r *Room) IsFull() bool {
	return len(r.Players) >= r.Capacity
}

// IsEmpty 检查房间是否为空
func (r *Room) IsEmpty() bool {
	return len(r.Players) == 0
}

// HasPlayer 检查指定用户是否在房间中
func (r *Room) HasPlayer(userID string) bool {
	for _, player := range r.Players {
		if player.UserID == userID {
			return true
		}
	}
	return false
}

// GetPlayerByUserID 根据用户ID获取玩家
func (r *Room) GetPlayerByUserID(userID string) *Player {
	for i, player := range r.Players {
		if player.UserID == userID {
			return &r.Players[i]
		}
	}
	return nil
}

// GetPlayerByPosition 根据位置获取玩家
func (r *Room) GetPlayerByPosition(position int) *Player {
	for i, player := range r.Players {
		if player.Position == position {
			return &r.Players[i]
		}
	}
	return nil
}

// FindEmptyPosition 找到空闲的座位位置
func (r *Room) FindEmptyPosition() int {
	occupied := make(map[int]bool)
	for _, player := range r.Players {
		occupied[player.Position] = true
	}

	for i := 0; i < r.Capacity; i++ {
		if !occupied[i] {
			return i
		}
	}
	return -1 // 没有空位
}

// AddPlayer 添加玩家到房间
func (r *Room) AddPlayer(player Player) bool {
	if r.IsFull() || r.HasPlayer(player.UserID) {
		return false
	}

	// 如果没有指定位置，自动分配
	if player.Position < 0 {
		position := r.FindEmptyPosition()
		if position < 0 {
			return false
		}
		player.Position = position
	} else {
		// 检查指定位置是否已被占用
		if r.GetPlayerByPosition(player.Position) != nil {
			return false
		}
	}

	player.JoinAt = time.Now()
	r.Players = append(r.Players, player)
	r.UpdateAt = time.Now()
	return true
}

// RemovePlayer 从房间移除玩家
func (r *Room) RemovePlayer(userID string) bool {
	for i, player := range r.Players {
		if player.UserID == userID {
			r.Players = append(r.Players[:i], r.Players[i+1:]...)
			r.UpdateAt = time.Now()
			return true
		}
	}
	return false
}

// AllPlayersReady 检查所有玩家是否都已准备
func (r *Room) AllPlayersReady() bool {
	if len(r.Players) < r.Capacity {
		return false
	}

	for _, player := range r.Players {
		if !player.IsReady {
			return false
		}
	}
	return true
}

// CanStartGame 检查是否可以开始游戏
func (r *Room) CanStartGame() bool {
	return len(r.Players) == r.Capacity && r.AllPlayersReady() && r.Status == 0
}

// IsInGame 检查房间是否在游戏中
func (r *Room) IsInGame() bool {
	return r.Status == 1 && r.CurrentGame != nil
}

// IsOwner 检查指定用户是否为房主
func (r *Room) IsOwner(userID string) bool {
	return r.OwnerID == userID
}

// TransferOwnership 转移房主权限给房间内的其他玩家
func (r *Room) TransferOwnership() {
	if len(r.Players) > 0 {
		// 将房主权限转给第一个玩家
		r.OwnerID = r.Players[0].UserID
		r.UpdateAt = time.Now()
	}
}

// ToListResponse 转换为房间列表响应格式
func (r *Room) ToListResponse(ownerName string) *RoomListResponse {
	return &RoomListResponse{
		ID:          r.ID,
		Name:        r.Name,
		Description: r.Description,
		PlayerCount: r.PlayerCount(),
		Capacity:    r.Capacity,
		IsPrivate:   r.IsPrivate,
		Status:      r.Status,
		OwnerName:   ownerName,
		CreateAt:    r.CreateAt,
	}
}

// DefaultRoomConfig 默认房间配置
func DefaultRoomConfig() RoomConfig {
	return RoomConfig{
		GameTimeout:    1800,  // 30分钟
		BiddingTimeout: 30,    // 30秒
		PlayTimeout:    60,    // 60秒
		AllowAI:        true,  // 允许AI
		AutoStart:      false, // 不自动开始
		ScoreMultiple:  1,     // 1倍积分
	}
}
