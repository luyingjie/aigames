package models

import (
	"encoding/json"
	"time"
)

// User 用户模型
type User struct {
	ID       string    `json:"id"`        // 用户ID
	Username string    `json:"username"`  // 用户名
	Password string    `json:"-"`         // 密码(不返回给前端)
	Nickname string    `json:"nickname"`  // 昵称
	Avatar   string    `json:"avatar"`    // 头像URL
	Score    int       `json:"score"`     // 游戏积分
	Level    int       `json:"level"`     // 用户等级
	Wins     int       `json:"wins"`      // 胜利次数
	Games    int       `json:"games"`     // 游戏总次数
	CreateAt time.Time `json:"create_at"` // 创建时间
	UpdateAt time.Time `json:"update_at"` // 更新时间
	Status   int       `json:"status"`    // 用户状态: 0-离线 1-在线 2-游戏中
}

// MarshalJSON 自定义JSON序列化（用于数据库存储）
func (u *User) MarshalJSON() ([]byte, error) {
	type Alias User
	return json.Marshal(&struct {
		*Alias
		Password string `json:"password"` // 强制包含密码字段
	}{
		Alias:    (*Alias)(u),
		Password: u.Password,
	})
}

// UnmarshalJSON 自定义JSON反序列化（用于数据库读取）
func (u *User) UnmarshalJSON(data []byte) error {
	type Alias User
	aux := &struct {
		*Alias
		Password string `json:"password"`
	}{
		Alias: (*Alias)(u),
	}
	if err := json.Unmarshal(data, &aux); err != nil {
		return err
	}
	u.Password = aux.Password
	return nil
}

// UserLoginRequest 用户登录请求
type UserLoginRequest struct {
	Username string `json:"username" binding:"required,min=3,max=20"` // 用户名
	Password string `json:"password" binding:"required,min=6,max=20"` // 密码
}

// UserRegisterRequest 用户注册请求
type UserRegisterRequest struct {
	Username string `json:"username" binding:"required,min=3,max=20"` // 用户名
	Password string `json:"password" binding:"required,min=6,max=20"` // 密码
	Nickname string `json:"nickname" binding:"required,min=2,max=20"` // 昵称
}

// UserProfileRequest 用户资料更新请求
type UserProfileRequest struct {
	Nickname string `json:"nickname" binding:"required,min=2,max=20"` // 昵称
	Avatar   string `json:"avatar"`                                   // 头像URL
}

// UserResponse 用户信息响应(不包含敏感信息)
type UserResponse struct {
	ID       string    `json:"id"`        // 用户ID
	Username string    `json:"username"`  // 用户名
	Nickname string    `json:"nickname"`  // 昵称
	Avatar   string    `json:"avatar"`    // 头像URL
	Score    int       `json:"score"`     // 游戏积分
	Level    int       `json:"level"`     // 用户等级
	Wins     int       `json:"wins"`      // 胜利次数
	Games    int       `json:"games"`     // 游戏总次数
	WinRate  float64   `json:"win_rate"`  // 胜率
	CreateAt time.Time `json:"create_at"` // 创建时间
	Status   int       `json:"status"`    // 用户状态
}

// ToResponse 将User转换为UserResponse
func (u *User) ToResponse() *UserResponse {
	var winRate float64
	if u.Games > 0 {
		winRate = float64(u.Wins) / float64(u.Games)
	}

	return &UserResponse{
		ID:       u.ID,
		Username: u.Username,
		Nickname: u.Nickname,
		Avatar:   u.Avatar,
		Score:    u.Score,
		Level:    u.Level,
		Wins:     u.Wins,
		Games:    u.Games,
		WinRate:  winRate,
		CreateAt: u.CreateAt,
		Status:   u.Status,
	}
}

// IsOnline 检查用户是否在线
func (u *User) IsOnline() bool {
	return u.Status > 0
}

// IsInGame 检查用户是否在游戏中
func (u *User) IsInGame() bool {
	return u.Status == 2
}

// CalculateLevel 根据积分计算用户等级
func (u *User) CalculateLevel() {
	// 简单的等级计算：每1000分升一级
	u.Level = u.Score/1000 + 1
	if u.Level > 100 {
		u.Level = 100 // 最高等级限制
	}
}

// UpdateStats 更新用户游戏统计
func (u *User) UpdateStats(won bool, scoreChange int) {
	u.Games++
	if won {
		u.Wins++
	}
	u.Score += scoreChange
	if u.Score < 0 {
		u.Score = 0 // 积分不能为负数
	}
	u.CalculateLevel()
	u.UpdateAt = time.Now()
}
