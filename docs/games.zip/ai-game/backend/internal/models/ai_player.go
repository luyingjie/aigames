package models

import (
	"time"
)

// AIPlayer AI玩家模型
type AIPlayer struct {
	ID          string            `json:"id" bolt:"id"`                   // AI玩家ID
	Name        string            `json:"name" bolt:"name"`               // AI玩家名称
	Avatar      string            `json:"avatar" bolt:"avatar"`           // 头像URL
	Personality string            `json:"personality" bolt:"personality"` // 性格类型
	Level       int               `json:"level" bolt:"level"`             // AI难度等级 1-10
	Description string            `json:"description" bolt:"description"` // 描述
	Prompts     map[string]string `json:"prompts" bolt:"prompts"`         // 提示词配置
	Config      AIConfig          `json:"config" bolt:"config"`           // AI配置参数
	Stats       AIStats           `json:"stats" bolt:"stats"`             // AI统计数据
	Status      int               `json:"status" bolt:"status"`           // 状态：0-禁用 1-启用
	CreateAt    time.Time         `json:"create_at" bolt:"create_at"`     // 创建时间
	UpdateAt    time.Time         `json:"update_at" bolt:"update_at"`     // 更新时间
}

// AIConfig AI配置参数
type AIConfig struct {
	APIKey        string     `json:"api_key"`        // AI API密钥
	Model         string     `json:"model"`          // 使用的AI模型
	Temperature   float64    `json:"temperature"`    // 创造性参数 0.0-2.0
	MaxTokens     int        `json:"max_tokens"`     // 最大token数
	ThinkTime     int        `json:"think_time"`     // 思考时间(秒)
	ChatEnabled   bool       `json:"chat_enabled"`   // 是否启用聊天
	ChatFrequency float64    `json:"chat_frequency"` // 聊天频率 0.0-1.0
	Strategy      AIStrategy `json:"strategy"`       // AI策略配置
}

// AIStrategy AI策略配置
type AIStrategy struct {
	Aggression    float64 `json:"aggression"`     // 攻击性 0.0-1.0
	RiskTolerance float64 `json:"risk_tolerance"` // 风险容忍度 0.0-1.0
	Cooperation   float64 `json:"cooperation"`    // 合作度 0.0-1.0 (农民之间)
	BluffTendency float64 `json:"bluff_tendency"` // 虚张声势倾向 0.0-1.0
	Memory        float64 `json:"memory"`         // 记忆能力 0.0-1.0
}

// AIStats AI统计数据
type AIStats struct {
	GamesPlayed    int       `json:"games_played"`    // 游戏次数
	GamesWon       int       `json:"games_won"`       // 获胜次数
	WinRate        float64   `json:"win_rate"`        // 胜率
	LandlordWins   int       `json:"landlord_wins"`   // 地主获胜次数
	LandlordGames  int       `json:"landlord_games"`  // 地主游戏次数
	FarmerWins     int       `json:"farmer_wins"`     // 农民获胜次数
	FarmerGames    int       `json:"farmer_games"`    // 农民游戏次数
	AverageScore   float64   `json:"average_score"`   // 平均得分
	MessagesPosted int       `json:"messages_posted"` // 发送消息数
	LastPlayed     time.Time `json:"last_played"`     // 最后游戏时间
}

// CreateAIPlayerRequest 创建AI玩家请求
type CreateAIPlayerRequest struct {
	Name        string            `json:"name" binding:"required,min=1,max=20"`                                  // AI玩家名称
	Avatar      string            `json:"avatar"`                                                                // 头像URL
	Personality string            `json:"personality" binding:"required,oneof=aggressive conservative balanced"` // 性格类型
	Level       int               `json:"level" binding:"required,min=1,max=10"`                                 // 难度等级
	Description string            `json:"description" binding:"max=200"`                                         // 描述
	Prompts     map[string]string `json:"prompts"`                                                               // 提示词配置
	Config      AIConfig          `json:"config"`                                                                // AI配置
}

// UpdateAIPlayerRequest 更新AI玩家请求
type UpdateAIPlayerRequest struct {
	Name        string            `json:"name" binding:"min=1,max=20"`                                  // AI玩家名称
	Avatar      string            `json:"avatar"`                                                       // 头像URL
	Personality string            `json:"personality" binding:"oneof=aggressive conservative balanced"` // 性格类型
	Level       int               `json:"level" binding:"min=1,max=10"`                                 // 难度等级
	Description string            `json:"description" binding:"max=200"`                                // 描述
	Prompts     map[string]string `json:"prompts"`                                                      // 提示词配置
	Config      AIConfig          `json:"config"`                                                       // AI配置
	Status      int               `json:"status" binding:"oneof=0 1"`                                   // 状态
}

// AIPlayerListResponse AI玩家列表响应
type AIPlayerListResponse struct {
	ID          string    `json:"id"`           // AI玩家ID
	Name        string    `json:"name"`         // AI玩家名称
	Avatar      string    `json:"avatar"`       // 头像URL
	Personality string    `json:"personality"`  // 性格类型
	Level       int       `json:"level"`        // 难度等级
	Description string    `json:"description"`  // 描述
	WinRate     float64   `json:"win_rate"`     // 胜率
	GamesPlayed int       `json:"games_played"` // 游戏次数
	Status      int       `json:"status"`       // 状态
	CreateAt    time.Time `json:"create_at"`    // 创建时间
}

// UpdateStats 更新AI统计数据
func (ai *AIPlayer) UpdateStats(won bool, role int, scoreChange float64) {
	ai.Stats.GamesPlayed++
	if won {
		ai.Stats.GamesWon++
	}

	// 更新胜率
	ai.Stats.WinRate = float64(ai.Stats.GamesWon) / float64(ai.Stats.GamesPlayed)

	// 根据角色更新统计
	if role == 1 { // 地主
		ai.Stats.LandlordGames++
		if won {
			ai.Stats.LandlordWins++
		}
	} else { // 农民
		ai.Stats.FarmerGames++
		if won {
			ai.Stats.FarmerWins++
		}
	}

	// 更新平均得分
	totalScore := ai.Stats.AverageScore * float64(ai.Stats.GamesPlayed-1)
	ai.Stats.AverageScore = (totalScore + scoreChange) / float64(ai.Stats.GamesPlayed)

	ai.Stats.LastPlayed = time.Now()
	ai.UpdateAt = time.Now()
}

// IncrementMessages 增加消息计数
func (ai *AIPlayer) IncrementMessages() {
	ai.Stats.MessagesPosted++
	ai.UpdateAt = time.Now()
}

// IsEnabled 检查AI是否启用
func (ai *AIPlayer) IsEnabled() bool {
	return ai.Status == 1
}

// ToListResponse 转换为列表响应格式
func (ai *AIPlayer) ToListResponse() *AIPlayerListResponse {
	return &AIPlayerListResponse{
		ID:          ai.ID,
		Name:        ai.Name,
		Avatar:      ai.Avatar,
		Personality: ai.Personality,
		Level:       ai.Level,
		Description: ai.Description,
		WinRate:     ai.Stats.WinRate,
		GamesPlayed: ai.Stats.GamesPlayed,
		Status:      ai.Status,
		CreateAt:    ai.CreateAt,
	}
}

// GetPersonalityDescription 获取性格描述
func (ai *AIPlayer) GetPersonalityDescription() string {
	descriptions := map[string]string{
		"aggressive":   "激进型：喜欢冒险，出牌较为激进，倾向于主动出击",
		"conservative": "保守型：谨慎稳重，出牌较为保守，注重防守",
		"balanced":     "平衡型：攻守兼备，根据局势灵活调整策略",
	}
	return descriptions[ai.Personality]
}

// DefaultAIConfig 默认AI配置
func DefaultAIConfig() AIConfig {
	return AIConfig{
		Model:         "gpt-3.5-turbo",
		Temperature:   0.7,
		MaxTokens:     1000,
		ThinkTime:     3,
		ChatEnabled:   true,
		ChatFrequency: 0.3,
		Strategy: AIStrategy{
			Aggression:    0.5,
			RiskTolerance: 0.5,
			Cooperation:   0.7,
			BluffTendency: 0.3,
			Memory:        0.8,
		},
	}
}

// DefaultPrompts 默认提示词模板
func DefaultPrompts() map[string]string {
	return map[string]string{
		"game_strategy": `你是一个斗地主AI玩家，名字是{name}，性格是{personality}。
游戏规则：{rules}
当前手牌：{hand_cards}
已出牌历史：{play_history}
请分析当前局面并制定策略。`,

		"bidding": `当前是叫地主阶段，你需要决定是否叫地主。
底牌：{hole_cards}
你的手牌：{hand_cards}
其他玩家叫牌情况：{bid_history}
你的性格是{personality}，请根据你的性格特点做决定。
请决定：1-叫地主，0-不叫。只回答数字。`,

		"playing": `轮到你出牌，请选择要出的牌。
当前手牌：{hand_cards}
上家出牌：{last_play}
可选出牌：{valid_plays}
游戏历史：{play_history}
你的性格是{personality}，请根据你的性格特点选择。
请选择出牌，格式：[牌面1,牌面2,...]，如果过牌则回答"pass"。`,

		"chat": `游戏进行中，你可以发送聊天消息。
你的性格：{personality}
当前游戏状态：{game_state}
最近聊天记录：{chat_history}
你的角色：{role}
请生成一条符合你性格的聊天消息。如果不想聊天，回答"none"。`,

		"personality": `你是一个{personality}性格的斗地主AI玩家。
{personality_description}
请始终保持这种性格特点在游戏和聊天中。`,
	}
}
