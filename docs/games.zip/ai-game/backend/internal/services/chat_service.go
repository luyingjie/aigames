package services

import (
	"strings"
	"time"

	"ai-game/internal/game/ai"
	"ai-game/internal/models"
	"ai-game/internal/repositories"
	"ai-game/internal/utils"
	"ai-game/pkg/constants"
	appErrors "ai-game/pkg/errors"
	"ai-game/pkg/logger"
)

// ChatService 聊天服务接口
type ChatService interface {
	// 消息管理
	SendMessage(message *models.ChatMessage) (*models.ChatMessage, error)
	GetMessageByID(id string) (*models.ChatMessage, error)
	DeleteMessage(messageID string) error

	// 房间消息
	GetRoomMessages(roomID string, page, limit int) ([]*models.ChatMessage, int, error)
	GetUserMessages(userID string, page, limit int) ([]*models.ChatMessage, int, error)

	// AI聊天
	TriggerAIChat(aiPlayerID, roomID, context string) (*models.ChatMessage, error)

	// 统计信息
	GetChatStats(roomID, userID string) (map[string]interface{}, error)
}

// chatService 聊天服务实现
type chatService struct {
	chatRepo     repositories.ChatRepository
	userRepo     repositories.UserRepository
	aiPlayerRepo repositories.AIPlayerRepository
	aiService    AIPlayerService
}

// NewChatService 创建聊天服务实例
func NewChatService(
	chatRepo repositories.ChatRepository,
	userRepo repositories.UserRepository,
	aiPlayerRepo repositories.AIPlayerRepository,
	aiService AIPlayerService,
) ChatService {
	return &chatService{
		chatRepo:     chatRepo,
		userRepo:     userRepo,
		aiPlayerRepo: aiPlayerRepo,
		aiService:    aiService,
	}
}

// SendMessage 发送消息
func (s *chatService) SendMessage(message *models.ChatMessage) (*models.ChatMessage, error) {
	logger.Debug("发送消息: UserID=%s, RoomID=%s", message.UserID, message.RoomID)

	// 验证消息内容
	if strings.TrimSpace(message.Content) == "" {
		return nil, appErrors.New(constants.StatusBadRequest, "消息内容不能为空")
	}

	// 内容过滤和清理
	message.Content = s.sanitizeContent(message.Content)

	// 生成消息ID
	if message.ID == "" {
		message.ID = utils.GenerateMessageID()
	}

	// 设置默认值
	if message.Status == 0 {
		message.Status = 1 // 正常状态
	}
	if message.Type == 0 {
		message.Type = 1 // 文本消息
	}

	// 保存到数据库
	if err := s.chatRepo.CreateMessage(message); err != nil {
		return nil, appErrors.NewWithDetails(constants.StatusServerError, "发送消息失败", err.Error())
	}

	logger.Info("消息发送成功: ID=%s, UserID=%s", message.ID, message.UserID)
	return message, nil
}

// GetMessageByID 获取消息
func (s *chatService) GetMessageByID(id string) (*models.ChatMessage, error) {
	logger.Debug("获取消息: ID=%s", id)

	message, err := s.chatRepo.GetMessage(id)
	if err != nil {
		return nil, err
	}

	return message, nil
}

// DeleteMessage 删除消息
func (s *chatService) DeleteMessage(messageID string) error {
	logger.Debug("删除消息: MessageID=%s", messageID)

	// 获取现有消息
	message, err := s.chatRepo.GetMessage(messageID)
	if err != nil {
		return err
	}

	// 标记为已删除而不是物理删除
	message.Status = 0 // 已删除
	message.UpdateAt = time.Now()

	if err := s.chatRepo.UpdateMessage(message); err != nil {
		return appErrors.NewWithDetails(constants.StatusServerError, "删除消息失败", err.Error())
	}

	logger.Info("消息删除成功: ID=%s", messageID)
	return nil
}

// GetRoomMessages 获取房间消息列表
func (s *chatService) GetRoomMessages(roomID string, page, limit int) ([]*models.ChatMessage, int, error) {
	logger.Debug("获取房间消息: RoomID=%s, page=%d, limit=%d", roomID, page, limit)

	messages, total, err := s.chatRepo.GetRoomMessages(roomID, page, limit)
	if err != nil {
		return nil, 0, appErrors.NewWithDetails(constants.StatusServerError, "获取房间消息失败", err.Error())
	}

	return messages, total, nil
}

// GetUserMessages 获取用户消息列表
func (s *chatService) GetUserMessages(userID string, page, limit int) ([]*models.ChatMessage, int, error) {
	logger.Debug("获取用户消息: UserID=%s, page=%d, limit=%d", userID, page, limit)

	messages, total, err := s.chatRepo.GetUserMessages(userID, page, limit)
	if err != nil {
		return nil, 0, appErrors.NewWithDetails(constants.StatusServerError, "获取用户消息失败", err.Error())
	}

	return messages, total, nil
}

// TriggerAIChat 触发AI聊天
func (s *chatService) TriggerAIChat(aiPlayerID, roomID, context string) (*models.ChatMessage, error) {
	logger.Debug("触发AI聊天: AIPlayerID=%s, RoomID=%s", aiPlayerID, roomID)

	// 获取AI玩家信息
	aiPlayer, err := s.aiPlayerRepo.GetByID(aiPlayerID)
	if err != nil {
		return nil, appErrors.NewWithDetails(constants.StatusBadRequest, "AI玩家不存在", err.Error())
	}

	// 检查AI是否启用聊天
	if !aiPlayer.Config.ChatEnabled {
		return nil, nil // 未启用聊天，不生成消息
	}

	// 构建决策上下文
	decisionCtx := &ai.DecisionContext{
		AIPlayer: aiPlayer,
		// 暂时不设置GameState和ChatHistory，在实际应用中需要从上下文获取
	}

	// 生成AI聊天消息
	chatContent, err := s.aiService.GenerateChatMessage(aiPlayerID, decisionCtx)
	if err != nil {
		return nil, appErrors.NewWithDetails(constants.StatusServerError, "AI聊天生成失败", err.Error())
	}

	// 如果AI没有生成消息，返回null
	if chatContent == "" {
		return nil, nil
	}

	// 创建聊天消息
	message := &models.ChatMessage{
		ID:       utils.GenerateMessageID(),
		RoomID:   roomID,
		UserID:   aiPlayerID,
		Content:  chatContent,
		Type:     1, // 文本消息
		IsAI:     true,
		AIPlayer: aiPlayerID,
		Status:   1, // 正常状态
		CreateAt: time.Now(),
		UpdateAt: time.Now(),
	}

	// 保存消息
	if err := s.chatRepo.CreateMessage(message); err != nil {
		return nil, appErrors.NewWithDetails(constants.StatusServerError, "保存AI消息失败", err.Error())
	}

	logger.Info("AI聊天消息生成成功: ID=%s, AIPlayer=%s", message.ID, aiPlayerID)
	return message, nil
}

// GetChatStats 获取聊天统计
func (s *chatService) GetChatStats(roomID, userID string) (map[string]interface{}, error) {
	logger.Debug("获取聊天统计: RoomID=%s, UserID=%s", roomID, userID)

	stats, err := s.chatRepo.GetMessageStats(roomID, userID)
	if err != nil {
		return nil, appErrors.NewWithDetails(constants.StatusServerError, "获取统计数据失败", err.Error())
	}

	return stats, nil
}

// sanitizeContent 清理和过滤消息内容
func (s *chatService) sanitizeContent(content string) string {
	// 移除首尾空格
	content = strings.TrimSpace(content)

	// 简单的敏感词过滤(实际应用中可以使用更复杂的过滤规则)
	bannedWords := []string{"辱骂", "攻击", "伤害"} // 示例敏感词
	for _, word := range bannedWords {
		content = strings.ReplaceAll(content, word, "***")
	}

	// 清理危险字符
	content = utils.SanitizeString(content)

	return content
}
