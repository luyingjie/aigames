package services

import (
	"time"

	"ai-game/internal/models"
	"ai-game/internal/repositories"
	"ai-game/pkg/constants"
	appErrors "ai-game/pkg/errors"
	"ai-game/pkg/logger"
	"ai-game/pkg/utils"
)

// GameService 游戏服务接口
type GameService interface {
	// 房间管理
	GetRoomList(page, limit int) ([]*models.Room, int, error)
	CreateRoom(room *models.Room) (*models.Room, error)
	JoinRoom(roomID, userID string) (*models.Room, error)
	LeaveRoom(roomID, userID string) error
	GetRoom(roomID string) (*models.Room, error)

	// 游戏状态
	GetGameState(roomID, userID string) (*models.Game, error)
	StartGame(roomID string) (*models.Game, error)

	// 游戏操作
	MakeBid(roomID, userID string, bid bool) (*models.Game, error)
	PlayCards(roomID, userID string, cardIndexes []int) (*models.Game, error)
	Pass(roomID, userID string) (*models.Game, error)
}

// gameService 游戏服务实现
type gameService struct {
	roomRepo repositories.RoomRepository
	gameRepo repositories.GameRepository
	userRepo repositories.UserRepository
}

// NewGameService 创建游戏服务实例
func NewGameService(roomRepo repositories.RoomRepository, gameRepo repositories.GameRepository, userRepo repositories.UserRepository) GameService {
	return &gameService{
		roomRepo: roomRepo,
		gameRepo: gameRepo,
		userRepo: userRepo,
	}
}

// GetRoomList 获取房间列表
func (s *gameService) GetRoomList(page, limit int) ([]*models.Room, int, error) {
	logger.Debug("获取房间列表: page=%d, limit=%d", page, limit)

	rooms, total, err := s.roomRepo.GetRoomList(page, limit)
	if err != nil {
		return nil, 0, appErrors.NewWithDetails(constants.StatusServerError, "获取房间列表失败", err.Error())
	}

	return rooms, total, nil
}

// CreateRoom 创建房间
func (s *gameService) CreateRoom(room *models.Room) (*models.Room, error) {
	logger.Debug("创建房间: Name=%s, OwnerID=%s", room.Name, room.OwnerID)

	// 生成房间ID
	if room.ID == "" {
		room.ID = utils.GenerateID()
	}

	// 设置默认值
	room.Capacity = 3 // 斗地主固定3人
	room.Status = 0   // 等待中
	room.CreateAt = time.Now()
	room.UpdateAt = time.Now()
	room.Config = models.DefaultRoomConfig()

	// 初始化玩家列表，创建者作为第一个玩家
	room.Players = []models.Player{
		{
			UserID:   room.OwnerID,
			Position: 0,
			IsReady:  true, // 房主默认准备
			JoinAt:   time.Now(),
		},
	}

	// 保存房间
	if err := s.roomRepo.CreateRoom(room); err != nil {
		return nil, appErrors.NewWithDetails(constants.StatusServerError, "创建房间失败", err.Error())
	}

	logger.Info("房间创建成功: ID=%s, Name=%s", room.ID, room.Name)
	return room, nil
}

// JoinRoom 加入房间
func (s *gameService) JoinRoom(roomID, userID string) (*models.Room, error) {
	logger.Debug("加入房间: RoomID=%s, UserID=%s", roomID, userID)

	// 获取房间信息
	room, err := s.roomRepo.GetRoom(roomID)
	if err != nil {
		return nil, appErrors.NewWithDetails(constants.StatusNotFound, "房间不存在", err.Error())
	}

	// 检查房间状态
	if room.Status != 0 {
		return nil, appErrors.New(constants.StatusBadRequest, "房间不可加入")
	}

	// 检查房间是否已满
	if room.IsFull() {
		return nil, appErrors.New(constants.StatusBadRequest, "房间已满")
	}

	// 检查用户是否已在房间中
	if room.HasPlayer(userID) {
		return room, nil // 已在房间中，直接返回
	}

	// 添加新玩家
	newPlayer := models.Player{
		UserID:   userID,
		Position: room.FindEmptyPosition(),
		IsReady:  false,
		JoinAt:   time.Now(),
	}

	if !room.AddPlayer(newPlayer) {
		return nil, appErrors.New(constants.StatusBadRequest, "加入房间失败")
	}

	// 更新房间信息
	if err := s.roomRepo.UpdateRoom(room); err != nil {
		return nil, appErrors.NewWithDetails(constants.StatusServerError, "加入房间失败", err.Error())
	}

	logger.Info("用户加入房间成功: RoomID=%s, UserID=%s", roomID, userID)
	return room, nil
}

// LeaveRoom 离开房间
func (s *gameService) LeaveRoom(roomID, userID string) error {
	logger.Debug("离开房间: RoomID=%s, UserID=%s", roomID, userID)

	// 获取房间信息
	room, err := s.roomRepo.GetRoom(roomID)
	if err != nil {
		return appErrors.NewWithDetails(constants.StatusNotFound, "房间不存在", err.Error())
	}

	// 移除玩家
	if !room.RemovePlayer(userID) {
		return nil // 用户不在房间中，直接返回
	}

	// 如果房间空了，删除房间
	if room.IsEmpty() {
		if err := s.roomRepo.DeleteRoom(roomID); err != nil {
			logger.Error("删除空房间失败: %v", err)
		}
		logger.Info("房间已删除: ID=%s", roomID)
		return nil
	}

	// 如果离开的是房主，转移房主权限
	if room.IsOwner(userID) {
		room.TransferOwnership()
	}

	// 更新房间信息
	if err := s.roomRepo.UpdateRoom(room); err != nil {
		return appErrors.NewWithDetails(constants.StatusServerError, "离开房间失败", err.Error())
	}

	logger.Info("用户离开房间成功: RoomID=%s, UserID=%s", roomID, userID)
	return nil
}

// GetRoom 获取房间信息
func (s *gameService) GetRoom(roomID string) (*models.Room, error) {
	room, err := s.roomRepo.GetRoom(roomID)
	if err != nil {
		return nil, appErrors.NewWithDetails(constants.StatusNotFound, "房间不存在", err.Error())
	}
	return room, nil
}

// GetGameState 获取游戏状态
func (s *gameService) GetGameState(roomID, userID string) (*models.Game, error) {
	logger.Debug("获取游戏状态: RoomID=%s, UserID=%s", roomID, userID)

	// 检查用户是否在房间中
	room, err := s.GetRoom(roomID)
	if err != nil {
		return nil, err
	}

	if !room.HasPlayer(userID) {
		return nil, appErrors.New(constants.StatusForbidden, "用户不在房间中")
	}

	// 获取游戏状态
	gameState, err := s.gameRepo.GetGameState(roomID)
	if err != nil {
		// 如果游戏状态不存在，创建一个新的
		gameState = &models.Game{
			ID:      utils.GenerateID(),
			RoomID:  roomID,
			Status:  0, // 等待开始
			Players: room.Players,
		}
	}

	return gameState, nil
}

// StartGame 开始游戏
func (s *gameService) StartGame(roomID string) (*models.Game, error) {
	logger.Debug("开始游戏: RoomID=%s", roomID)

	// 获取房间信息
	room, err := s.GetRoom(roomID)
	if err != nil {
		return nil, err
	}

	// 检查房间人数
	if room.PlayerCount() < 3 {
		return nil, appErrors.New(constants.StatusBadRequest, "房间人数不足，无法开始游戏")
	}

	// 创建游戏状态
	gameState := &models.Game{
		ID:      utils.GenerateID(),
		RoomID:  roomID,
		Status:  1, // 游戏中
		Players: room.Players,
		StartAt: time.Now(),
	}

	// TODO: 实现发牌逻辑

	// 保存游戏状态
	if err := s.gameRepo.CreateGameState(gameState); err != nil {
		return nil, appErrors.NewWithDetails(constants.StatusServerError, "开始游戏失败", err.Error())
	}

	logger.Info("游戏开始成功: RoomID=%s", roomID)
	return gameState, nil
}

// MakeBid 叫地主
func (s *gameService) MakeBid(roomID, userID string, bid bool) (*models.Game, error) {
	logger.Debug("叫地主: RoomID=%s, UserID=%s, Bid=%t", roomID, userID, bid)

	// 获取游戏状态
	gameState, err := s.GetGameState(roomID, userID)
	if err != nil {
		return nil, err
	}

	// TODO: 实现叫地主逻辑

	// 更新游戏状态
	if err := s.gameRepo.UpdateGameState(gameState); err != nil {
		return nil, appErrors.NewWithDetails(constants.StatusServerError, "叫地主失败", err.Error())
	}

	return gameState, nil
}

// PlayCards 出牌
func (s *gameService) PlayCards(roomID, userID string, cardIndexes []int) (*models.Game, error) {
	logger.Debug("出牌: RoomID=%s, UserID=%s, Cards=%v", roomID, userID, cardIndexes)

	// 获取游戏状态
	gameState, err := s.GetGameState(roomID, userID)
	if err != nil {
		return nil, err
	}

	// TODO: 实现出牌逻辑

	// 更新游戏状态
	if err := s.gameRepo.UpdateGameState(gameState); err != nil {
		return nil, appErrors.NewWithDetails(constants.StatusServerError, "出牌失败", err.Error())
	}

	return gameState, nil
}

// Pass 不出牌(过)
func (s *gameService) Pass(roomID, userID string) (*models.Game, error) {
	logger.Debug("过牌: RoomID=%s, UserID=%s", roomID, userID)

	// 获取游戏状态
	gameState, err := s.GetGameState(roomID, userID)
	if err != nil {
		return nil, err
	}

	// TODO: 实现过牌逻辑

	// 更新游戏状态
	if err := s.gameRepo.UpdateGameState(gameState); err != nil {
		return nil, appErrors.NewWithDetails(constants.StatusServerError, "过牌失败", err.Error())
	}

	return gameState, nil
}
