package services

import (
	"time"

	"ai-game/internal/game/ai"
	"ai-game/internal/models"
	"ai-game/internal/repositories"
	"ai-game/internal/utils"
	"ai-game/pkg/constants"
	appErrors "ai-game/pkg/errors"
	"ai-game/pkg/logger"
)

// AIPlayerService AI玩家服务接口
type AIPlayerService interface {
	// AI玩家管理
	CreateAIPlayer(req *models.CreateAIPlayerRequest) (*models.AIPlayer, error)
	GetAIPlayer(id string) (*models.AIPlayer, error)
	UpdateAIPlayer(id string, req *models.UpdateAIPlayerRequest) (*models.AIPlayer, error)
	DeleteAIPlayer(id string) error
	ListAIPlayers(page, size int) ([]*models.AIPlayerListResponse, int, error)
	ListEnabledAIPlayers() ([]*models.AIPlayerListResponse, error)
	GetAIPlayersByPersonality(personality string) ([]*models.AIPlayerListResponse, error)

	// AI决策相关
	MakeBidDecision(aiPlayerID string, ctx *ai.DecisionContext) (bool, error)
	MakePlayDecision(aiPlayerID string, ctx *ai.DecisionContext) ([]models.Card, error)
	GenerateChatMessage(aiPlayerID string, ctx *ai.DecisionContext) (string, error)

	// AI配置管理
	TestAIConnection(apiKey, model string) error
	UpdateAIConfig(id string, config models.AIConfig) error
	UpdatePrompts(id string, prompts map[string]string) error

	// AI统计相关
	UpdateAIStats(id string, won bool, role int, scoreChange float64) error
	IncrementMessages(id string) error
	GetAIStats(id string) (*models.AIStats, error)

	// 内部方法
	GetDecisionEngine() *ai.DecisionEngine
}

// aiPlayerService AI玩家服务实现
type aiPlayerService struct {
	aiPlayerRepo   repositories.AIPlayerRepository
	decisionEngine *ai.DecisionEngine
	aiClient       *ai.AIClient
}

// NewAIPlayerService 创建AI玩家服务实例
func NewAIPlayerService(aiPlayerRepo repositories.AIPlayerRepository) AIPlayerService {
	// 创建AI客户端
	aiClient := ai.NewAIClient(30 * time.Second)

	// 创建决策引擎
	decisionEngine := ai.NewDecisionEngine(aiClient)

	return &aiPlayerService{
		aiPlayerRepo:   aiPlayerRepo,
		decisionEngine: decisionEngine,
		aiClient:       aiClient,
	}
}

// CreateAIPlayer 创建AI玩家
func (s *aiPlayerService) CreateAIPlayer(req *models.CreateAIPlayerRequest) (*models.AIPlayer, error) {
	logger.Info("创建AI玩家: %s", req.Name)

	// 验证请求参数
	if err := s.validateCreateRequest(req); err != nil {
		return nil, err
	}

	// 检查名称是否已存在
	exists, err := s.aiPlayerRepo.ExistsByName(req.Name)
	if err != nil {
		return nil, appErrors.NewWithDetails(constants.StatusServerError, "检查AI玩家名称失败", err.Error())
	}
	if exists {
		return nil, appErrors.New(constants.StatusBadRequest, "AI玩家名称已存在")
	}

	// 创建AI玩家实例
	aiPlayer := &models.AIPlayer{
		ID:          utils.GenerateAIPlayerID(),
		Name:        req.Name,
		Avatar:      req.Avatar,
		Personality: req.Personality,
		Level:       req.Level,
		Description: req.Description,
		Prompts:     req.Prompts,
		Config:      req.Config,
		Stats:       models.AIStats{}, // 初始化空统计
		Status:      1,                // 默认启用
	}

	// 设置默认头像
	if aiPlayer.Avatar == "" {
		aiPlayer.Avatar = utils.GenerateAvatar(aiPlayer.Name)
	}

	// 设置默认配置
	if aiPlayer.Config.Model == "" {
		aiPlayer.Config = models.DefaultAIConfig()
	}

	// 设置默认提示词
	if len(aiPlayer.Prompts) == 0 {
		aiPlayer.Prompts = models.DefaultPrompts()
	}

	// 保存到数据库
	if err := s.aiPlayerRepo.Create(aiPlayer); err != nil {
		return nil, appErrors.NewWithDetails(constants.StatusServerError, "创建AI玩家失败", err.Error())
	}

	logger.Info("AI玩家创建成功: ID=%s, Name=%s", aiPlayer.ID, aiPlayer.Name)
	return aiPlayer, nil
}

// GetAIPlayer 获取AI玩家
func (s *aiPlayerService) GetAIPlayer(id string) (*models.AIPlayer, error) {
	logger.Debug("获取AI玩家: ID=%s", id)

	aiPlayer, err := s.aiPlayerRepo.GetByID(id)
	if err != nil {
		return nil, err
	}

	return aiPlayer, nil
}

// UpdateAIPlayer 更新AI玩家
func (s *aiPlayerService) UpdateAIPlayer(id string, req *models.UpdateAIPlayerRequest) (*models.AIPlayer, error) {
	logger.Info("更新AI玩家: ID=%s", id)

	// 获取现有AI玩家
	aiPlayer, err := s.aiPlayerRepo.GetByID(id)
	if err != nil {
		return nil, err
	}

	// 验证请求参数
	if err := s.validateUpdateRequest(req); err != nil {
		return nil, err
	}

	// 检查名称冲突
	if req.Name != "" && req.Name != aiPlayer.Name {
		exists, err := s.aiPlayerRepo.ExistsByName(req.Name)
		if err != nil {
			return nil, appErrors.NewWithDetails(constants.StatusServerError, "检查AI玩家名称失败", err.Error())
		}
		if exists {
			return nil, appErrors.New(constants.StatusBadRequest, "AI玩家名称已存在")
		}
	}

	// 更新字段
	if req.Name != "" {
		aiPlayer.Name = req.Name
	}
	if req.Avatar != "" {
		aiPlayer.Avatar = req.Avatar
	}
	if req.Personality != "" {
		aiPlayer.Personality = req.Personality
	}
	if req.Level > 0 {
		aiPlayer.Level = req.Level
	}
	if req.Description != "" {
		aiPlayer.Description = req.Description
	}
	if len(req.Prompts) > 0 {
		aiPlayer.Prompts = req.Prompts
	}
	if req.Config.Model != "" {
		aiPlayer.Config = req.Config
	}
	if req.Status >= 0 {
		aiPlayer.Status = req.Status
	}

	// 保存更新
	if err := s.aiPlayerRepo.Update(aiPlayer); err != nil {
		return nil, appErrors.NewWithDetails(constants.StatusServerError, "更新AI玩家失败", err.Error())
	}

	logger.Info("AI玩家更新成功: ID=%s", id)
	return aiPlayer, nil
}

// DeleteAIPlayer 删除AI玩家
func (s *aiPlayerService) DeleteAIPlayer(id string) error {
	logger.Info("删除AI玩家: ID=%s", id)

	// 检查AI玩家是否存在
	_, err := s.aiPlayerRepo.GetByID(id)
	if err != nil {
		return err
	}

	// TODO: 检查AI玩家是否正在游戏中，如果是则拒绝删除

	// 删除AI玩家
	if err := s.aiPlayerRepo.Delete(id); err != nil {
		return appErrors.NewWithDetails(constants.StatusServerError, "删除AI玩家失败", err.Error())
	}

	logger.Info("AI玩家删除成功: ID=%s", id)
	return nil
}

// ListAIPlayers 获取AI玩家列表
func (s *aiPlayerService) ListAIPlayers(page, size int) ([]*models.AIPlayerListResponse, int, error) {
	logger.Debug("获取AI玩家列表: page=%d, size=%d", page, size)

	aiPlayers, total, err := s.aiPlayerRepo.List(page, size)
	if err != nil {
		return nil, 0, appErrors.NewWithDetails(constants.StatusServerError, "获取AI玩家列表失败", err.Error())
	}

	// 转换为响应格式
	responses := make([]*models.AIPlayerListResponse, len(aiPlayers))
	for i, aiPlayer := range aiPlayers {
		responses[i] = aiPlayer.ToListResponse()
	}

	return responses, total, nil
}

// ListEnabledAIPlayers 获取启用的AI玩家列表
func (s *aiPlayerService) ListEnabledAIPlayers() ([]*models.AIPlayerListResponse, error) {
	logger.Debug("获取启用的AI玩家列表")

	aiPlayers, err := s.aiPlayerRepo.ListEnabled()
	if err != nil {
		return nil, appErrors.NewWithDetails(constants.StatusServerError, "获取启用AI玩家列表失败", err.Error())
	}

	// 转换为响应格式
	responses := make([]*models.AIPlayerListResponse, len(aiPlayers))
	for i, aiPlayer := range aiPlayers {
		responses[i] = aiPlayer.ToListResponse()
	}

	return responses, nil
}

// GetAIPlayersByPersonality 根据性格获取AI玩家
func (s *aiPlayerService) GetAIPlayersByPersonality(personality string) ([]*models.AIPlayerListResponse, error) {
	logger.Debug("根据性格获取AI玩家: personality=%s", personality)

	aiPlayers, err := s.aiPlayerRepo.GetByPersonality(personality)
	if err != nil {
		return nil, appErrors.NewWithDetails(constants.StatusServerError, "根据性格获取AI玩家失败", err.Error())
	}

	// 转换为响应格式
	responses := make([]*models.AIPlayerListResponse, len(aiPlayers))
	for i, aiPlayer := range aiPlayers {
		responses[i] = aiPlayer.ToListResponse()
	}

	return responses, nil
}

// MakeBidDecision AI叫地主决策
func (s *aiPlayerService) MakeBidDecision(aiPlayerID string, ctx *ai.DecisionContext) (bool, error) {
	logger.Debug("AI叫地主决策: ID=%s", aiPlayerID)

	// 获取AI玩家
	aiPlayer, err := s.aiPlayerRepo.GetByID(aiPlayerID)
	if err != nil {
		return false, err
	}

	// 检查AI玩家是否启用
	if !aiPlayer.IsEnabled() {
		return false, appErrors.New(constants.StatusBadRequest, "AI玩家已禁用")
	}

	// 设置决策上下文
	ctx.AIPlayer = aiPlayer

	// 调用决策引擎
	decision, err := s.decisionEngine.MakeBidDecision(ctx)
	if err != nil {
		logger.Error("AI叫地主决策失败: %v", err)
		return false, appErrors.NewWithDetails(constants.StatusServerError, "AI决策失败", err.Error())
	}

	logger.Debug("AI叫地主决策完成: ID=%s, 决策=%v", aiPlayerID, decision)
	return decision, nil
}

// MakePlayDecision AI出牌决策
func (s *aiPlayerService) MakePlayDecision(aiPlayerID string, ctx *ai.DecisionContext) ([]models.Card, error) {
	logger.Debug("AI出牌决策: ID=%s", aiPlayerID)

	// 获取AI玩家
	aiPlayer, err := s.aiPlayerRepo.GetByID(aiPlayerID)
	if err != nil {
		return nil, err
	}

	// 检查AI玩家是否启用
	if !aiPlayer.IsEnabled() {
		return nil, appErrors.New(constants.StatusBadRequest, "AI玩家已禁用")
	}

	// 设置决策上下文
	ctx.AIPlayer = aiPlayer

	// 调用决策引擎
	cards, err := s.decisionEngine.MakePlayDecision(ctx)
	if err != nil {
		logger.Error("AI出牌决策失败: %v", err)
		return nil, appErrors.NewWithDetails(constants.StatusServerError, "AI决策失败", err.Error())
	}

	logger.Debug("AI出牌决策完成: ID=%s, 出牌=%v", aiPlayerID, cards)
	return cards, nil
}

// GenerateChatMessage AI生成聊天消息
func (s *aiPlayerService) GenerateChatMessage(aiPlayerID string, ctx *ai.DecisionContext) (string, error) {
	logger.Debug("AI生成聊天消息: ID=%s", aiPlayerID)

	// 获取AI玩家
	aiPlayer, err := s.aiPlayerRepo.GetByID(aiPlayerID)
	if err != nil {
		return "", err
	}

	// 检查AI玩家是否启用聊天
	if !aiPlayer.Config.ChatEnabled {
		return "", nil
	}

	// 设置决策上下文
	ctx.AIPlayer = aiPlayer

	// 调用决策引擎
	message, err := s.decisionEngine.GenerateChatMessage(ctx)
	if err != nil {
		logger.Error("AI生成聊天消息失败: %v", err)
		return "", appErrors.NewWithDetails(constants.StatusServerError, "AI聊天生成失败", err.Error())
	}

	// 如果生成了消息，更新统计
	if message != "" {
		s.IncrementMessages(aiPlayerID)
	}

	logger.Debug("AI聊天消息生成完成: ID=%s, 消息=%s", aiPlayerID, message)
	return message, nil
}

// TestAIConnection 测试AI连接
func (s *aiPlayerService) TestAIConnection(apiKey, model string) error {
	logger.Info("测试AI连接: model=%s", model)

	err := s.aiClient.TestConnection(apiKey, model)
	if err != nil {
		return appErrors.NewWithDetails(constants.StatusBadRequest, "AI连接测试失败", err.Error())
	}

	logger.Info("AI连接测试成功: model=%s", model)
	return nil
}

// UpdateAIConfig 更新AI配置
func (s *aiPlayerService) UpdateAIConfig(id string, config models.AIConfig) error {
	logger.Info("更新AI配置: ID=%s", id)

	// 获取AI玩家
	aiPlayer, err := s.aiPlayerRepo.GetByID(id)
	if err != nil {
		return err
	}

	// 更新配置
	aiPlayer.Config = config

	// 保存更新
	if err := s.aiPlayerRepo.Update(aiPlayer); err != nil {
		return appErrors.NewWithDetails(constants.StatusServerError, "更新AI配置失败", err.Error())
	}

	logger.Info("AI配置更新成功: ID=%s", id)
	return nil
}

// UpdatePrompts 更新提示词
func (s *aiPlayerService) UpdatePrompts(id string, prompts map[string]string) error {
	logger.Info("更新AI提示词: ID=%s", id)

	// 获取AI玩家
	aiPlayer, err := s.aiPlayerRepo.GetByID(id)
	if err != nil {
		return err
	}

	// 更新提示词
	aiPlayer.Prompts = prompts

	// 保存更新
	if err := s.aiPlayerRepo.Update(aiPlayer); err != nil {
		return appErrors.NewWithDetails(constants.StatusServerError, "更新AI提示词失败", err.Error())
	}

	logger.Info("AI提示词更新成功: ID=%s", id)
	return nil
}

// UpdateAIStats 更新AI统计数据
func (s *aiPlayerService) UpdateAIStats(id string, won bool, role int, scoreChange float64) error {
	logger.Debug("更新AI统计: ID=%s, won=%v, role=%d, score=%f", id, won, role, scoreChange)

	// 获取AI玩家
	aiPlayer, err := s.aiPlayerRepo.GetByID(id)
	if err != nil {
		return err
	}

	// 更新统计数据
	aiPlayer.UpdateStats(won, role, scoreChange)

	// 保存更新
	if err := s.aiPlayerRepo.Update(aiPlayer); err != nil {
		return appErrors.NewWithDetails(constants.StatusServerError, "更新AI统计失败", err.Error())
	}

	logger.Debug("AI统计更新成功: ID=%s", id)
	return nil
}

// IncrementMessages 增加消息计数
func (s *aiPlayerService) IncrementMessages(id string) error {
	// 获取AI玩家
	aiPlayer, err := s.aiPlayerRepo.GetByID(id)
	if err != nil {
		return err
	}

	// 增加消息计数
	aiPlayer.IncrementMessages()

	// 保存更新
	return s.aiPlayerRepo.Update(aiPlayer)
}

// GetAIStats 获取AI统计数据
func (s *aiPlayerService) GetAIStats(id string) (*models.AIStats, error) {
	logger.Debug("获取AI统计: ID=%s", id)

	aiPlayer, err := s.aiPlayerRepo.GetByID(id)
	if err != nil {
		return nil, err
	}

	return &aiPlayer.Stats, nil
}

// GetDecisionEngine 获取决策引擎
func (s *aiPlayerService) GetDecisionEngine() *ai.DecisionEngine {
	return s.decisionEngine
}

// 验证方法

// validateCreateRequest 验证创建请求
func (s *aiPlayerService) validateCreateRequest(req *models.CreateAIPlayerRequest) error {
	if req.Name == "" {
		return appErrors.New(constants.StatusBadRequest, "AI玩家名称不能为空")
	}

	if len(req.Name) < 1 || len(req.Name) > 20 {
		return appErrors.New(constants.StatusBadRequest, "AI玩家名称长度必须在1-20字符之间")
	}

	if req.Personality == "" {
		return appErrors.New(constants.StatusBadRequest, "AI玩家性格不能为空")
	}

	validPersonalities := []string{"aggressive", "conservative", "balanced"}
	isValidPersonality := false
	for _, p := range validPersonalities {
		if req.Personality == p {
			isValidPersonality = true
			break
		}
	}
	if !isValidPersonality {
		return appErrors.New(constants.StatusBadRequest, "无效的AI玩家性格")
	}

	if req.Level < 1 || req.Level > 10 {
		return appErrors.New(constants.StatusBadRequest, "AI难度等级必须在1-10之间")
	}

	if len(req.Description) > 200 {
		return appErrors.New(constants.StatusBadRequest, "AI玩家描述不能超过200字符")
	}

	return nil
}

// validateUpdateRequest 验证更新请求
func (s *aiPlayerService) validateUpdateRequest(req *models.UpdateAIPlayerRequest) error {
	if req.Name != "" && (len(req.Name) < 1 || len(req.Name) > 20) {
		return appErrors.New(constants.StatusBadRequest, "AI玩家名称长度必须在1-20字符之间")
	}

	if req.Personality != "" {
		validPersonalities := []string{"aggressive", "conservative", "balanced"}
		isValidPersonality := false
		for _, p := range validPersonalities {
			if req.Personality == p {
				isValidPersonality = true
				break
			}
		}
		if !isValidPersonality {
			return appErrors.New(constants.StatusBadRequest, "无效的AI玩家性格")
		}
	}

	if req.Level > 0 && (req.Level < 1 || req.Level > 10) {
		return appErrors.New(constants.StatusBadRequest, "AI难度等级必须在1-10之间")
	}

	if len(req.Description) > 200 {
		return appErrors.New(constants.StatusBadRequest, "AI玩家描述不能超过200字符")
	}

	if req.Status < 0 || req.Status > 1 {
		return appErrors.New(constants.StatusBadRequest, "无效的AI玩家状态")
	}

	return nil
}
