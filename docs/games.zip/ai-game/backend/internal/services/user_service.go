package services

import (
	"time"

	"ai-game/internal/models"
	"ai-game/internal/repositories"
	"ai-game/internal/utils"
	"ai-game/pkg/constants"
	appErrors "ai-game/pkg/errors"
	"ai-game/pkg/logger"
)

// UserService 用户服务接口
type UserService interface {
	Register(req *models.UserRegisterRequest) (*models.UserResponse, error)
	Login(req *models.UserLoginRequest) (*models.UserResponse, string, error)
	GetProfile(userID string) (*models.UserResponse, error)
	UpdateProfile(userID string, req *models.UserProfileRequest) (*models.UserResponse, error)
	GetUserList(page, size int) ([]*models.UserResponse, int, error)
	GetTopPlayers(limit int) ([]*models.UserResponse, error)
	SearchUsers(nickname string, page, size int) ([]*models.UserResponse, int, error)
	UpdateUserStatus(userID string, status int) error
	UpdateUserScore(userID string, scoreChange int, won bool) error
	DeleteUser(userID string) error
	ValidateToken(token string) (*models.User, error)
}

// userService 用户服务实现
type userService struct {
	userRepo  repositories.UserRepository
	jwtSecret string
	jwtExpire int
}

// NewUserService 创建用户服务实例
func NewUserService(userRepo repositories.UserRepository, jwtSecret string, jwtExpire int) UserService {
	return &userService{
		userRepo:  userRepo,
		jwtSecret: jwtSecret,
		jwtExpire: jwtExpire,
	}
}

// Register 用户注册
func (s *userService) Register(req *models.UserRegisterRequest) (*models.UserResponse, error) {
	// 验证输入参数
	if err := utils.ValidateUsername(req.Username); err != nil {
		return nil, err
	}

	if err := utils.ValidatePassword(req.Password); err != nil {
		return nil, err
	}

	if err := utils.ValidateNickname(req.Nickname); err != nil {
		return nil, err
	}

	// 清理输入数据
	req.Username = utils.SanitizeString(req.Username)
	req.Nickname = utils.SanitizeString(req.Nickname)

	// 检查用户名是否已存在
	if s.userRepo.ExistsByUsername(req.Username) {
		return nil, appErrors.ErrUserExists
	}

	// 加密密码
	hashedPassword, err := utils.HashPassword(req.Password)
	if err != nil {
		logger.Error("密码加密失败: %v", err)
		return nil, appErrors.ErrInternalServer
	}

	// 创建用户对象
	user := &models.User{
		ID:       utils.GenerateUserID(),
		Username: req.Username,
		Password: hashedPassword,
		Nickname: req.Nickname,
		Avatar:   utils.GenerateAvatar(req.Username),
		Score:    1000, // 初始积分
		Level:    1,    // 初始等级
		Wins:     0,
		Games:    0,
		Status:   constants.UserStatusOffline,
	}

	// 保存用户
	if err := s.userRepo.Create(user); err != nil {
		logger.Error("创建用户失败: %v", err)
		return nil, err
	}

	logger.Info("用户注册成功: %s (%s)", user.Username, user.ID)
	return user.ToResponse(), nil
}

// Login 用户登录
func (s *userService) Login(req *models.UserLoginRequest) (*models.UserResponse, string, error) {
	// 验证输入参数
	if err := utils.ValidateUsername(req.Username); err != nil {
		return nil, "", err
	}

	// 根据用户名查找用户
	user, err := s.userRepo.GetByUsername(req.Username)
	if err != nil {
		return nil, "", appErrors.ErrInvalidCredentials
	}

	// 验证密码
	logger.Debug("验证密码: 输入密码长度=%d, 存储哈希长度=%d", len(req.Password), len(user.Password))
	if !utils.CheckPassword(req.Password, user.Password) {
		logger.Warn("用户 %s 登录失败: 密码错误", req.Username)
		return nil, "", appErrors.ErrInvalidCredentials
	}

	// 更新用户状态为在线
	user.Status = constants.UserStatusOnline
	user.UpdateAt = time.Now()
	if err := s.userRepo.Update(user); err != nil {
		logger.Error("更新用户状态失败: %v", err)
	}

	// 生成JWT令牌
	token, err := utils.GenerateToken(user.ID, user.Username, s.jwtSecret, s.jwtExpire)
	if err != nil {
		logger.Error("生成令牌失败: %v", err)
		return nil, "", appErrors.ErrInternalServer
	}

	logger.Info("用户登录成功: %s (%s)", user.Username, user.ID)
	return user.ToResponse(), token, nil
}

// GetProfile 获取用户资料
func (s *userService) GetProfile(userID string) (*models.UserResponse, error) {
	user, err := s.userRepo.GetByID(userID)
	if err != nil {
		return nil, err
	}
	return user.ToResponse(), nil
}

// UpdateProfile 更新用户资料
func (s *userService) UpdateProfile(userID string, req *models.UserProfileRequest) (*models.UserResponse, error) {
	// 验证输入参数
	if err := utils.ValidateNickname(req.Nickname); err != nil {
		return nil, err
	}

	// 获取用户
	user, err := s.userRepo.GetByID(userID)
	if err != nil {
		return nil, err
	}

	// 更新用户信息
	user.Nickname = utils.SanitizeString(req.Nickname)
	if req.Avatar != "" {
		user.Avatar = utils.SanitizeString(req.Avatar)
	}

	// 保存更新
	if err := s.userRepo.Update(user); err != nil {
		return nil, err
	}

	logger.Info("用户资料更新成功: %s (%s)", user.Username, user.ID)
	return user.ToResponse(), nil
}

// GetUserList 获取用户列表
func (s *userService) GetUserList(page, size int) ([]*models.UserResponse, int, error) {
	users, total, err := s.userRepo.List(page, size)
	if err != nil {
		return nil, 0, err
	}

	userResponses := make([]*models.UserResponse, len(users))
	for i, user := range users {
		userResponses[i] = user.ToResponse()
	}

	return userResponses, total, nil
}

// GetTopPlayers 获取积分排行榜
func (s *userService) GetTopPlayers(limit int) ([]*models.UserResponse, error) {
	if limit <= 0 || limit > 100 {
		limit = 10 // 默认返回前10名
	}

	users, err := s.userRepo.GetTopPlayers(limit)
	if err != nil {
		return nil, err
	}

	userResponses := make([]*models.UserResponse, len(users))
	for i, user := range users {
		userResponses[i] = user.ToResponse()
	}

	return userResponses, nil
}

// SearchUsers 搜索用户
func (s *userService) SearchUsers(nickname string, page, size int) ([]*models.UserResponse, int, error) {
	// 清理搜索关键词
	nickname = utils.SanitizeString(nickname)

	users, total, err := s.userRepo.SearchByNickname(nickname, page, size)
	if err != nil {
		return nil, 0, err
	}

	userResponses := make([]*models.UserResponse, len(users))
	for i, user := range users {
		userResponses[i] = user.ToResponse()
	}

	return userResponses, total, nil
}

// UpdateUserStatus 更新用户状态
func (s *userService) UpdateUserStatus(userID string, status int) error {
	// 验证状态值
	if status < 0 || status > 2 {
		return appErrors.New(constants.StatusBadRequest, "无效的用户状态")
	}

	return s.userRepo.UpdateStatus(userID, status)
}

// UpdateUserScore 更新用户积分和游戏统计
func (s *userService) UpdateUserScore(userID string, scoreChange int, won bool) error {
	// 获取用户
	user, err := s.userRepo.GetByID(userID)
	if err != nil {
		return err
	}

	// 更新游戏统计
	user.UpdateStats(won, scoreChange)

	// 保存更新
	if err := s.userRepo.Update(user); err != nil {
		return err
	}

	logger.Info("用户 %s 积分更新: %+d, 总积分: %d", userID, scoreChange, user.Score)
	return nil
}

// DeleteUser 删除用户
func (s *userService) DeleteUser(userID string) error {
	// 检查用户是否存在
	user, err := s.userRepo.GetByID(userID)
	if err != nil {
		return err
	}

	// 检查用户是否在游戏中
	if user.Status == constants.UserStatusInGame {
		return appErrors.New(constants.StatusBadRequest, "用户正在游戏中，无法删除")
	}

	// 删除用户
	if err := s.userRepo.Delete(userID); err != nil {
		return err
	}

	logger.Info("用户删除成功: %s (%s)", user.Username, user.ID)
	return nil
}

// ValidateToken 验证JWT令牌
func (s *userService) ValidateToken(token string) (*models.User, error) {
	// 解析令牌
	claims, err := utils.ParseToken(token, s.jwtSecret)
	if err != nil {
		return nil, appErrors.ErrInvalidToken
	}

	// 获取用户信息
	user, err := s.userRepo.GetByID(claims.UserID)
	if err != nil {
		return nil, appErrors.ErrUserNotFound
	}

	return user, nil
}
