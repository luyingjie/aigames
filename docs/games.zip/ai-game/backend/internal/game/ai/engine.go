package ai

import (
	"encoding/json"
	"fmt"
	"math/rand"
	"strings"
	"time"

	"ai-game/internal/models"
	"ai-game/pkg/logger"
)

// DecisionEngine AI决策引擎
type DecisionEngine struct {
	aiClient *AIClient  // AI API客户端
	random   *rand.Rand // 随机数生成器
}

// NewDecisionEngine 创建AI决策引擎
func NewDecisionEngine(aiClient *AIClient) *DecisionEngine {
	return &DecisionEngine{
		aiClient: aiClient,
		random:   rand.New(rand.NewSource(time.Now().UnixNano())),
	}
}

// DecisionContext 决策上下文
type DecisionContext struct {
	AIPlayer    *models.AIPlayer         `json:"ai_player"`    // AI玩家信息
	GameState   *GameState               `json:"game_state"`   // 游戏状态
	HandCards   []models.Card            `json:"hand_cards"`   // 手牌
	LastPlay    *models.PlayCards        `json:"last_play"`    // 上家出牌
	ValidPlays  [][]models.Card          `json:"valid_plays"`  // 可选出牌
	PlayHistory []*models.PlayCards      `json:"play_history"` // 出牌历史
	ChatHistory []models.ChatMessageData `json:"chat_history"` // 聊天历史
	HoleCards   []models.Card            `json:"hole_cards"`   // 底牌(叫地主时可见)
	BidHistory  []BidAction              `json:"bid_history"`  // 叫牌历史
}

// GameState 游戏状态信息
type GameState struct {
	Phase         string                  `json:"phase"`          // 游戏阶段: bidding, playing, ended
	CurrentPlayer string                  `json:"current_player"` // 当前玩家ID
	Landlord      string                  `json:"landlord"`       // 地主ID
	Players       map[string]*PlayerState `json:"players"`        // 玩家状态
	CardsLeft     map[string]int          `json:"cards_left"`     // 各玩家剩余牌数
	LastWinner    string                  `json:"last_winner"`    // 上一轮获胜者
}

// PlayerState 玩家状态
type PlayerState struct {
	ID       string `json:"id"`        // 玩家ID
	Name     string `json:"name"`      // 玩家名称
	Role     int    `json:"role"`      // 角色: 0-农民, 1-地主
	CardsNum int    `json:"cards_num"` // 剩余牌数
	IsAI     bool   `json:"is_ai"`     // 是否为AI
}

// BidAction 叫牌行为
type BidAction struct {
	PlayerID string `json:"player_id"` // 玩家ID
	Action   int    `json:"action"`    // 0-不叫, 1-叫地主
	Score    int    `json:"score"`     // 叫分
}

// MakeBidDecision 做出叫地主决策
func (engine *DecisionEngine) MakeBidDecision(ctx *DecisionContext) (bool, error) {
	logger.Info("AI玩家 %s 开始叫地主决策", ctx.AIPlayer.Name)

	// 基于AI配置决定是否使用AI API
	if engine.shouldUseAI(ctx.AIPlayer) {
		return engine.makeBidDecisionWithAI(ctx)
	}

	// 使用基础策略
	return engine.makeBidDecisionBasic(ctx)
}

// MakePlayDecision 做出出牌决策
func (engine *DecisionEngine) MakePlayDecision(ctx *DecisionContext) ([]models.Card, error) {
	logger.Info("AI玩家 %s 开始出牌决策", ctx.AIPlayer.Name)

	// 添加思考时间
	time.Sleep(time.Duration(ctx.AIPlayer.Config.ThinkTime) * time.Second)

	// 基于AI配置决定是否使用AI API
	if engine.shouldUseAI(ctx.AIPlayer) {
		return engine.makePlayDecisionWithAI(ctx)
	}

	// 使用基础策略
	return engine.makePlayDecisionBasic(ctx)
}

// GenerateChatMessage 生成聊天消息
func (engine *DecisionEngine) GenerateChatMessage(ctx *DecisionContext) (string, error) {
	// 检查是否启用聊天
	if !ctx.AIPlayer.Config.ChatEnabled {
		return "", nil
	}

	// 根据聊天频率决定是否发送消息
	if engine.random.Float64() > ctx.AIPlayer.Config.ChatFrequency {
		return "", nil
	}

	logger.Info("AI玩家 %s 开始生成聊天消息", ctx.AIPlayer.Name)

	// 基于AI配置决定是否使用AI API
	if engine.shouldUseAI(ctx.AIPlayer) {
		return engine.generateChatWithAI(ctx)
	}

	// 使用预设消息
	return engine.generateChatBasic(ctx)
}

// shouldUseAI 判断是否应该使用AI API
func (engine *DecisionEngine) shouldUseAI(aiPlayer *models.AIPlayer) bool {
	return engine.aiClient != nil &&
		aiPlayer.Config.APIKey != "" &&
		aiPlayer.Config.Model != ""
}

// makeBidDecisionWithAI 使用AI API做叫地主决策
func (engine *DecisionEngine) makeBidDecisionWithAI(ctx *DecisionContext) (bool, error) {
	prompt := engine.buildBidPrompt(ctx)

	response, err := engine.aiClient.GenerateResponse(&AIRequest{
		Model:       ctx.AIPlayer.Config.Model,
		Prompt:      prompt,
		Temperature: ctx.AIPlayer.Config.Temperature,
		MaxTokens:   100, // 叫地主决策只需要简单回答
		APIKey:      ctx.AIPlayer.Config.APIKey,
	})

	if err != nil {
		logger.Warn("AI叫地主决策失败，使用基础策略: %v", err)
		return engine.makeBidDecisionBasic(ctx)
	}

	// 解析AI回复
	response = strings.TrimSpace(response)
	return response == "1" || strings.Contains(strings.ToLower(response), "叫"), nil
}

// makeBidDecisionBasic 使用基础策略做叫地主决策
func (engine *DecisionEngine) makeBidDecisionBasic(ctx *DecisionContext) (bool, error) {
	// 计算手牌强度
	strength := engine.calculateHandStrength(ctx.HandCards)

	// 根据性格和策略调整阈值
	threshold := 0.6
	switch ctx.AIPlayer.Personality {
	case "aggressive":
		threshold = 0.5 // 激进型更容易叫地主
	case "conservative":
		threshold = 0.7 // 保守型更谨慎
	case "balanced":
		threshold = 0.6 // 平衡型中等阈值
	}

	// 根据AI策略进一步调整
	threshold -= ctx.AIPlayer.Config.Strategy.Aggression * 0.2
	threshold += ctx.AIPlayer.Config.Strategy.RiskTolerance * 0.1

	return strength >= threshold, nil
}

// makePlayDecisionWithAI 使用AI API做出牌决策
func (engine *DecisionEngine) makePlayDecisionWithAI(ctx *DecisionContext) ([]models.Card, error) {
	prompt := engine.buildPlayPrompt(ctx)

	response, err := engine.aiClient.GenerateResponse(&AIRequest{
		Model:       ctx.AIPlayer.Config.Model,
		Prompt:      prompt,
		Temperature: ctx.AIPlayer.Config.Temperature,
		MaxTokens:   ctx.AIPlayer.Config.MaxTokens,
		APIKey:      ctx.AIPlayer.Config.APIKey,
	})

	if err != nil {
		logger.Warn("AI出牌决策失败，使用基础策略: %v", err)
		return engine.makePlayDecisionBasic(ctx)
	}

	// 解析AI回复
	cards, err := engine.parsePlayResponse(response, ctx.ValidPlays)
	if err != nil {
		logger.Warn("AI出牌回复解析失败，使用基础策略: %v", err)
		return engine.makePlayDecisionBasic(ctx)
	}

	return cards, nil
}

// makePlayDecisionBasic 使用基础策略做出牌决策
func (engine *DecisionEngine) makePlayDecisionBasic(ctx *DecisionContext) ([]models.Card, error) {
	// 如果没有可选出牌，则过牌
	if len(ctx.ValidPlays) == 0 {
		return nil, nil
	}

	// 根据策略选择出牌
	strategy := &BasicStrategy{
		aggression:    ctx.AIPlayer.Config.Strategy.Aggression,
		riskTolerance: ctx.AIPlayer.Config.Strategy.RiskTolerance,
		cooperation:   ctx.AIPlayer.Config.Strategy.Cooperation,
	}

	return strategy.SelectPlay(ctx.ValidPlays, ctx.HandCards, ctx.GameState)
}

// generateChatWithAI 使用AI API生成聊天消息
func (engine *DecisionEngine) generateChatWithAI(ctx *DecisionContext) (string, error) {
	prompt := engine.buildChatPrompt(ctx)

	response, err := engine.aiClient.GenerateResponse(&AIRequest{
		Model:       ctx.AIPlayer.Config.Model,
		Prompt:      prompt,
		Temperature: ctx.AIPlayer.Config.Temperature + 0.2, // 聊天时增加创造性
		MaxTokens:   200,                                   // 聊天消息不需要太长
		APIKey:      ctx.AIPlayer.Config.APIKey,
	})

	if err != nil {
		logger.Warn("AI聊天生成失败，使用预设消息: %v", err)
		return engine.generateChatBasic(ctx)
	}

	response = strings.TrimSpace(response)
	if response == "none" || response == "" {
		return "", nil
	}

	return response, nil
}

// generateChatBasic 使用预设消息生成聊天
func (engine *DecisionEngine) generateChatBasic(ctx *DecisionContext) (string, error) {
	messages := engine.getPresetMessages(ctx.AIPlayer.Personality, ctx.GameState.Phase)
	if len(messages) == 0 {
		return "", nil
	}

	index := engine.random.Intn(len(messages))
	return messages[index], nil
}

// buildBidPrompt 构建叫地主提示词
func (engine *DecisionEngine) buildBidPrompt(ctx *DecisionContext) string {
	template := ctx.AIPlayer.Prompts["bidding"]
	if template == "" {
		template = models.DefaultPrompts()["bidding"]
	}

	// 替换模板变量
	prompt := strings.ReplaceAll(template, "{name}", ctx.AIPlayer.Name)
	prompt = strings.ReplaceAll(prompt, "{personality}", ctx.AIPlayer.GetPersonalityDescription())
	prompt = strings.ReplaceAll(prompt, "{hand_cards}", engine.formatCards(ctx.HandCards))
	prompt = strings.ReplaceAll(prompt, "{hole_cards}", engine.formatCards(ctx.HoleCards))
	prompt = strings.ReplaceAll(prompt, "{bid_history}", engine.formatBidHistory(ctx.BidHistory))

	return prompt
}

// buildPlayPrompt 构建出牌提示词
func (engine *DecisionEngine) buildPlayPrompt(ctx *DecisionContext) string {
	template := ctx.AIPlayer.Prompts["playing"]
	if template == "" {
		template = models.DefaultPrompts()["playing"]
	}

	// 替换模板变量
	prompt := strings.ReplaceAll(template, "{name}", ctx.AIPlayer.Name)
	prompt = strings.ReplaceAll(prompt, "{personality}", ctx.AIPlayer.GetPersonalityDescription())
	prompt = strings.ReplaceAll(prompt, "{hand_cards}", engine.formatCards(ctx.HandCards))
	prompt = strings.ReplaceAll(prompt, "{last_play}", engine.formatLastPlay(ctx.LastPlay))
	prompt = strings.ReplaceAll(prompt, "{valid_plays}", engine.formatValidPlays(ctx.ValidPlays))
	prompt = strings.ReplaceAll(prompt, "{play_history}", engine.formatPlayHistory(ctx.PlayHistory))

	return prompt
}

// buildChatPrompt 构建聊天提示词
func (engine *DecisionEngine) buildChatPrompt(ctx *DecisionContext) string {
	template := ctx.AIPlayer.Prompts["chat"]
	if template == "" {
		template = models.DefaultPrompts()["chat"]
	}

	// 替换模板变量
	prompt := strings.ReplaceAll(template, "{name}", ctx.AIPlayer.Name)
	prompt = strings.ReplaceAll(prompt, "{personality}", ctx.AIPlayer.GetPersonalityDescription())
	prompt = strings.ReplaceAll(prompt, "{game_state}", engine.formatGameState(ctx.GameState))
	prompt = strings.ReplaceAll(prompt, "{chat_history}", engine.formatChatHistory(ctx.ChatHistory))
	prompt = strings.ReplaceAll(prompt, "{role}", engine.formatRole(ctx.GameState, ctx.AIPlayer.ID))

	return prompt
}

// 辅助方法

// calculateHandStrength 计算手牌强度
func (engine *DecisionEngine) calculateHandStrength(cards []models.Card) float64 {
	if len(cards) == 0 {
		return 0.0
	}

	// 简单的牌力评估算法
	strength := 0.0
	totalCards := float64(len(cards))

	// 统计各点数的牌
	rankCount := make(map[int]int)
	for _, card := range cards {
		rankCount[card.Rank]++
	}

	// 评估炸弹和王炸
	for rank, count := range rankCount {
		if count == 4 {
			strength += 0.3 // 炸弹价值高
		}
		if rank >= 16 { // 王牌
			strength += 0.1
		}
		if rank >= 14 { // 大牌(A, 2)
			strength += 0.05 * float64(count)
		}
	}

	// 检查王炸
	if rankCount[16] > 0 && rankCount[17] > 0 {
		strength += 0.4 // 王炸价值很高
	}

	// 根据牌数调整(牌少时更容易出完)
	if totalCards <= 10 {
		strength += (10 - totalCards) * 0.02
	}

	// 归一化到0-1范围
	if strength > 1.0 {
		strength = 1.0
	}

	return strength
}

// formatCards 格式化牌组
func (engine *DecisionEngine) formatCards(cards []models.Card) string {
	if len(cards) == 0 {
		return "无"
	}

	cardStrs := make([]string, len(cards))
	for i, card := range cards {
		cardStrs[i] = card.String()
	}
	return strings.Join(cardStrs, " ")
}

// formatBidHistory 格式化叫牌历史
func (engine *DecisionEngine) formatBidHistory(history []BidAction) string {
	if len(history) == 0 {
		return "无人叫牌"
	}

	parts := make([]string, len(history))
	for i, bid := range history {
		action := "不叫"
		if bid.Action == 1 {
			action = "叫地主"
		}
		parts[i] = fmt.Sprintf("玩家%s: %s", bid.PlayerID, action)
	}
	return strings.Join(parts, ", ")
}

// formatLastPlay 格式化上家出牌
func (engine *DecisionEngine) formatLastPlay(lastPlay *models.PlayCards) string {
	if lastPlay == nil {
		return "首出"
	}
	return fmt.Sprintf("%s出牌: %s", lastPlay.PlayerID, engine.formatCards(lastPlay.Cards))
}

// formatValidPlays 格式化可选出牌
func (engine *DecisionEngine) formatValidPlays(validPlays [][]models.Card) string {
	if len(validPlays) == 0 {
		return "只能过牌"
	}

	parts := make([]string, len(validPlays))
	for i, play := range validPlays {
		parts[i] = engine.formatCards(play)
	}
	return strings.Join(parts, " | ")
}

// formatPlayHistory 格式化出牌历史
func (engine *DecisionEngine) formatPlayHistory(history []*models.PlayCards) string {
	if len(history) == 0 {
		return "无出牌历史"
	}

	parts := make([]string, 0, len(history))
	for _, play := range history {
		if len(play.Cards) > 0 {
			parts = append(parts, fmt.Sprintf("%s: %s", play.PlayerID, engine.formatCards(play.Cards)))
		}
	}
	return strings.Join(parts, ", ")
}

// formatGameState 格式化游戏状态
func (engine *DecisionEngine) formatGameState(state *GameState) string {
	return fmt.Sprintf("阶段: %s, 当前玩家: %s, 地主: %s", state.Phase, state.CurrentPlayer, state.Landlord)
}

// formatChatHistory 格式化聊天历史
func (engine *DecisionEngine) formatChatHistory(history []models.ChatMessageData) string {
	if len(history) == 0 {
		return "无聊天记录"
	}

	parts := make([]string, 0, len(history))
	for _, msg := range history {
		parts = append(parts, fmt.Sprintf("%s: %s", msg.UserID, msg.Message))
	}
	return strings.Join(parts, ", ")
}

// formatRole 格式化角色信息
func (engine *DecisionEngine) formatRole(state *GameState, playerID string) string {
	if state.Landlord == playerID {
		return "地主"
	}
	return "农民"
}

// parsePlayResponse 解析出牌回复
func (engine *DecisionEngine) parsePlayResponse(response string, validPlays [][]models.Card) ([]models.Card, error) {
	response = strings.TrimSpace(response)

	// 检查是否过牌
	if strings.ToLower(response) == "pass" || response == "过牌" {
		return nil, nil
	}

	// 尝试解析JSON格式的牌
	var cardStrs []string
	if err := json.Unmarshal([]byte(response), &cardStrs); err == nil {
		// JSON解析成功，查找匹配的出牌
		for _, validPlay := range validPlays {
			if engine.matchCards(cardStrs, validPlay) {
				return validPlay, nil
			}
		}
	}

	// 如果解析失败，返回第一个可选出牌(保底策略)
	if len(validPlays) > 0 {
		return validPlays[0], nil
	}

	return nil, nil
}

// matchCards 匹配牌组
func (engine *DecisionEngine) matchCards(cardStrs []string, cards []models.Card) bool {
	if len(cardStrs) != len(cards) {
		return false
	}

	// 简单的字符串匹配
	for _, cardStr := range cardStrs {
		found := false
		for _, card := range cards {
			if card.String() == cardStr {
				found = true
				break
			}
		}
		if !found {
			return false
		}
	}

	return true
}

// getPresetMessages 获取预设消息
func (engine *DecisionEngine) getPresetMessages(personality, phase string) []string {
	messages := make([]string, 0)

	switch personality {
	case "aggressive":
		switch phase {
		case "bidding":
			messages = []string{"我要当地主！", "这把我必须叫！", "让我来！"}
		case "playing":
			messages = []string{"看我的牌！", "这局稳了！", "你们要输了！"}
		}
	case "conservative":
		switch phase {
		case "bidding":
			messages = []string{"我再看看...", "牌不太好啊", "算了算了"}
		case "playing":
			messages = []string{"小心一点", "稳扎稳打", "慢慢来"}
		}
	case "balanced":
		switch phase {
		case "bidding":
			messages = []string{"考虑一下", "可以试试", "看情况吧"}
		case "playing":
			messages = []string{"不错的牌", "继续加油", "好牌局"}
		}
	}

	return messages
}
