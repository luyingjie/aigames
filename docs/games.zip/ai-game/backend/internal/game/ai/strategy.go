package ai

import (
	"math/rand"

	"ai-game/internal/models"
	"ai-game/pkg/logger"
)

// BasicStrategy 基础AI策略
type BasicStrategy struct {
	aggression    float64 // 攻击性 0.0-1.0
	riskTolerance float64 // 风险容忍度 0.0-1.0
	cooperation   float64 // 合作度 0.0-1.0
}

// NewBasicStrategy 创建基础策略
func NewBasicStrategy(aggression, riskTolerance, cooperation float64) *BasicStrategy {
	return &BasicStrategy{
		aggression:    aggression,
		riskTolerance: riskTolerance,
		cooperation:   cooperation,
	}
}

// SelectPlay 选择出牌
func (s *BasicStrategy) SelectPlay(validPlays [][]models.Card, handCards []models.Card, gameState *GameState) ([]models.Card, error) {
	if len(validPlays) == 0 {
		return nil, nil // 过牌
	}

	logger.Debug("基础策略选择出牌: 可选方案=%d", len(validPlays))

	// 分析手牌和游戏状态
	analysis := s.analyzeHandCards(handCards)
	gameAnalysis := s.analyzeGameState(gameState)

	// 根据策略选择最佳出牌
	selectedPlay := s.selectBestPlay(validPlays, analysis, gameAnalysis)

	logger.Debug("基础策略选择: %v", selectedPlay)
	return selectedPlay, nil
}

// HandAnalysis 手牌分析
type HandAnalysis struct {
	totalCards   int
	singleCards  []models.Card
	pairs        [][]models.Card
	triples      [][]models.Card
	bombs        [][]models.Card
	hasJokerBomb bool
	avgRank      float64
	maxRank      int
	minRank      int
}

// GameAnalysis 游戏状态分析
type GameAnalysis struct {
	isLandlord        bool
	otherPlayersCards map[string]int
	gamePhase         string
	lastPlayStrength  float64
	position          int // 出牌位置: 0-首出, 1-跟牌, 2-收尾
}

// analyzeHandCards 分析手牌
func (s *BasicStrategy) analyzeHandCards(cards []models.Card) *HandAnalysis {
	analysis := &HandAnalysis{
		totalCards:  len(cards),
		singleCards: make([]models.Card, 0),
		pairs:       make([][]models.Card, 0),
		triples:     make([][]models.Card, 0),
		bombs:       make([][]models.Card, 0),
	}

	if len(cards) == 0 {
		return analysis
	}

	// 统计各点数的牌
	rankCount := make(map[int][]models.Card)
	totalRank := 0
	maxRank := 0
	minRank := 20

	for _, card := range cards {
		rankCount[card.Rank] = append(rankCount[card.Rank], card)
		totalRank += card.Rank
		if card.Rank > maxRank {
			maxRank = card.Rank
		}
		if card.Rank < minRank {
			minRank = card.Rank
		}
	}

	analysis.avgRank = float64(totalRank) / float64(len(cards))
	analysis.maxRank = maxRank
	analysis.minRank = minRank

	// 分类牌型
	for _, rankCards := range rankCount {
		count := len(rankCards)
		switch count {
		case 1:
			analysis.singleCards = append(analysis.singleCards, rankCards[0])
		case 2:
			analysis.pairs = append(analysis.pairs, rankCards)
		case 3:
			analysis.triples = append(analysis.triples, rankCards)
		case 4:
			analysis.bombs = append(analysis.bombs, rankCards)
		}
	}

	// 检查王炸
	hasLittleJoker := false
	hasBigJoker := false
	for _, card := range cards {
		if card.Rank == 16 {
			hasLittleJoker = true
		} else if card.Rank == 17 {
			hasBigJoker = true
		}
	}
	analysis.hasJokerBomb = hasLittleJoker && hasBigJoker

	return analysis
}

// analyzeGameState 分析游戏状态
func (s *BasicStrategy) analyzeGameState(gameState *GameState) *GameAnalysis {
	analysis := &GameAnalysis{
		otherPlayersCards: make(map[string]int),
		gamePhase:         gameState.Phase,
		position:          0,
	}

	// 分析其他玩家牌数
	for playerID, cardCount := range gameState.CardsLeft {
		analysis.otherPlayersCards[playerID] = cardCount
	}

	// TODO: 根据实际游戏状态确定更多信息
	return analysis
}

// selectBestPlay 选择最佳出牌
func (s *BasicStrategy) selectBestPlay(validPlays [][]models.Card, handAnalysis *HandAnalysis, gameAnalysis *GameAnalysis) []models.Card {
	if len(validPlays) == 1 {
		return validPlays[0]
	}

	// 评估每个可选出牌
	playScores := make([]float64, len(validPlays))
	for i, play := range validPlays {
		playScores[i] = s.evaluatePlay(play, handAnalysis, gameAnalysis)
	}

	// 选择得分最高的出牌
	bestIndex := 0
	bestScore := playScores[0]
	for i, score := range playScores {
		if score > bestScore {
			bestScore = score
			bestIndex = i
		}
	}

	// 添加一些随机性
	if s.riskTolerance > 0.5 {
		// 风险容忍度高时，有机会选择次优方案
		if rand.Float64() < 0.2 && len(validPlays) > 1 {
			// 20%概率选择随机方案
			randomIndex := rand.Intn(len(validPlays))
			if randomIndex != bestIndex {
				logger.Debug("基础策略随机选择: index=%d (最优=%d)", randomIndex, bestIndex)
				return validPlays[randomIndex]
			}
		}
	}

	return validPlays[bestIndex]
}

// evaluatePlay 评估出牌方案
func (s *BasicStrategy) evaluatePlay(play []models.Card, handAnalysis *HandAnalysis, gameAnalysis *GameAnalysis) float64 {
	score := 0.0

	// 基础分数：根据牌型给分
	playType := s.classifyPlayType(play)
	score += s.getPlayTypeScore(playType)

	// 牌的强度评估
	playStrength := s.calculatePlayStrength(play)
	score += playStrength * 0.3

	// 手牌优化评估
	remainingOptimization := s.evaluateRemainingCards(play, handAnalysis)
	score += remainingOptimization * 0.4

	// 策略调整
	score = s.applyStrategyAdjustments(score, play, playType, gameAnalysis)

	return score
}

// PlayType 牌型
type PlayType int

const (
	PlayTypeSingle PlayType = iota
	PlayTypePair
	PlayTypeTriple
	PlayTypeBomb
	PlayTypeJokerBomb
	PlayTypeStraight
	PlayTypePairStraight
	PlayTypeTripleStraight
	PlayTypeQuadSingle
	PlayTypeQuadPair
)

// classifyPlayType 分类牌型
func (s *BasicStrategy) classifyPlayType(cards []models.Card) PlayType {
	count := len(cards)
	if count == 0 {
		return PlayTypeSingle
	}

	// 统计各点数
	rankCount := make(map[int]int)
	for _, card := range cards {
		rankCount[card.Rank]++
	}

	// 判断牌型
	switch count {
	case 1:
		return PlayTypeSingle
	case 2:
		// 可能是对子或王炸
		if s.isJokerBomb(cards) {
			return PlayTypeJokerBomb
		}
		return PlayTypePair
	case 3:
		return PlayTypeTriple
	case 4:
		// 可能是炸弹或四带二
		if len(rankCount) == 1 {
			return PlayTypeBomb
		}
		return PlayTypeQuadSingle
	default:
		// 复杂牌型分析
		return s.classifyComplexPlayType(cards, rankCount)
	}
}

// classifyComplexPlayType 分类复杂牌型
func (s *BasicStrategy) classifyComplexPlayType(cards []models.Card, rankCount map[int]int) PlayType {
	// 简化实现，实际应该更精确地分析
	maxCount := 0
	for _, count := range rankCount {
		if count > maxCount {
			maxCount = count
		}
	}

	switch maxCount {
	case 1:
		return PlayTypeStraight
	case 2:
		return PlayTypePairStraight
	case 3:
		return PlayTypeTripleStraight
	case 4:
		return PlayTypeBomb
	default:
		return PlayTypeSingle
	}
}

// getPlayTypeScore 获取牌型基础分数
func (s *BasicStrategy) getPlayTypeScore(playType PlayType) float64 {
	scores := map[PlayType]float64{
		PlayTypeSingle:         1.0,
		PlayTypePair:           1.5,
		PlayTypeTriple:         2.0,
		PlayTypeBomb:           5.0,
		PlayTypeJokerBomb:      6.0,
		PlayTypeStraight:       2.5,
		PlayTypePairStraight:   3.0,
		PlayTypeTripleStraight: 3.5,
		PlayTypeQuadSingle:     4.0,
		PlayTypeQuadPair:       4.5,
	}
	return scores[playType]
}

// calculatePlayStrength 计算出牌强度
func (s *BasicStrategy) calculatePlayStrength(cards []models.Card) float64 {
	if len(cards) == 0 {
		return 0.0
	}

	totalStrength := 0.0
	for _, card := range cards {
		// 根据牌的点数给分
		cardStrength := float64(card.Rank) / 17.0
		totalStrength += cardStrength
	}

	return totalStrength / float64(len(cards))
}

// evaluateRemainingCards 评估剩余手牌优化程度
func (s *BasicStrategy) evaluateRemainingCards(playCards []models.Card, handAnalysis *HandAnalysis) float64 {
	// 简化实现：出牌后手牌数量减少得分
	score := 0.0

	// 出牌数量奖励
	playCount := len(playCards)
	score += float64(playCount) * 0.1

	// 如果出牌后剩余牌数较少，额外奖励
	remainingCards := handAnalysis.totalCards - playCount
	if remainingCards <= 5 {
		score += (5 - float64(remainingCards)) * 0.2
	}

	return score
}

// applyStrategyAdjustments 应用策略调整
func (s *BasicStrategy) applyStrategyAdjustments(baseScore float64, cards []models.Card, playType PlayType, gameAnalysis *GameAnalysis) float64 {
	score := baseScore

	// 攻击性调整
	if s.aggression > 0.5 {
		// 攻击性强时，偏好强牌和炸弹
		if playType == PlayTypeBomb || playType == PlayTypeJokerBomb {
			score *= (1.0 + s.aggression)
		}
		// 强牌优势
		playStrength := s.calculatePlayStrength(cards)
		if playStrength > 0.7 {
			score *= (1.0 + s.aggression*0.3)
		}
	} else {
		// 保守时，偏好小牌
		playStrength := s.calculatePlayStrength(cards)
		if playStrength < 0.5 {
			score *= (1.0 + (1.0-s.aggression)*0.2)
		}
	}

	// 风险容忍度调整
	if s.riskTolerance < 0.5 {
		// 风险容忍度低时，避免复杂牌型
		if playType == PlayTypeStraight || playType == PlayTypeTripleStraight {
			score *= (1.0 - (1.0-s.riskTolerance)*0.2)
		}
	}

	return score
}

// isJokerBomb 检查是否为王炸
func (s *BasicStrategy) isJokerBomb(cards []models.Card) bool {
	if len(cards) != 2 {
		return false
	}

	hasLittleJoker := false
	hasBigJoker := false
	for _, card := range cards {
		if card.Rank == 16 {
			hasLittleJoker = true
		} else if card.Rank == 17 {
			hasBigJoker = true
		}
	}

	return hasLittleJoker && hasBigJoker
}

// SmartStrategy 智能策略(更高级的AI策略)
type SmartStrategy struct {
	*BasicStrategy
	memory []GameMemory // 记忆系统
}

// GameMemory 游戏记忆
type GameMemory struct {
	PlayerID      string
	PlayedCards   []models.Card
	PlayType      PlayType
	GameContext   string
	Effectiveness float64 // 效果评分
}

// NewSmartStrategy 创建智能策略
func NewSmartStrategy(aggression, riskTolerance, cooperation float64) *SmartStrategy {
	return &SmartStrategy{
		BasicStrategy: NewBasicStrategy(aggression, riskTolerance, cooperation),
		memory:        make([]GameMemory, 0),
	}
}

// SelectPlay 智能策略选择出牌
func (s *SmartStrategy) SelectPlay(validPlays [][]models.Card, handCards []models.Card, gameState *GameState) ([]models.Card, error) {
	// 先使用基础策略
	selectedPlay, err := s.BasicStrategy.SelectPlay(validPlays, handCards, gameState)
	if err != nil {
		return selectedPlay, err
	}

	// 应用记忆和学习
	selectedPlay = s.applyMemoryOptimization(selectedPlay, validPlays, gameState)

	// 记录这次选择
	s.recordPlay(selectedPlay, gameState)

	return selectedPlay, nil
}

// applyMemoryOptimization 应用记忆优化
func (s *SmartStrategy) applyMemoryOptimization(selectedPlay []models.Card, validPlays [][]models.Card, gameState *GameState) []models.Card {
	// 简化实现：根据历史效果调整选择
	if len(s.memory) < 10 {
		return selectedPlay // 记忆不足时使用基础选择
	}

	// 分析历史记忆，寻找更好的选择
	for _, validPlay := range validPlays {
		playType := s.classifyPlayType(validPlay)
		historicalScore := s.getHistoricalScore(playType, gameState.Phase)

		// 如果历史数据显示这种出牌更有效，考虑切换
		if historicalScore > 0.8 && len(validPlay) != len(selectedPlay) {
			logger.Debug("智能策略基于记忆调整出牌选择")
			return validPlay
		}
	}

	return selectedPlay
}

// recordPlay 记录出牌
func (s *SmartStrategy) recordPlay(cards []models.Card, gameState *GameState) {
	if len(cards) == 0 {
		return
	}

	memory := GameMemory{
		PlayerID:      gameState.CurrentPlayer,
		PlayedCards:   cards,
		PlayType:      s.classifyPlayType(cards),
		GameContext:   gameState.Phase,
		Effectiveness: 0.5, // 初始评分，后续会根据结果调整
	}

	s.memory = append(s.memory, memory)

	// 限制记忆数量
	if len(s.memory) > 100 {
		s.memory = s.memory[len(s.memory)-100:]
	}
}

// getHistoricalScore 获取历史评分
func (s *SmartStrategy) getHistoricalScore(playType PlayType, gamePhase string) float64 {
	totalScore := 0.0
	count := 0

	for _, mem := range s.memory {
		if mem.PlayType == playType && mem.GameContext == gamePhase {
			totalScore += mem.Effectiveness
			count++
		}
	}

	if count == 0 {
		return 0.5 // 默认评分
	}

	return totalScore / float64(count)
}

// UpdateMemoryEffectiveness 更新记忆效果(游戏结束后调用)
func (s *SmartStrategy) UpdateMemoryEffectiveness(won bool, playerID string) {
	effectiveness := 0.3
	if won {
		effectiveness = 0.8
	}

	// 更新相关记忆的效果评分
	for i := range s.memory {
		if s.memory[i].PlayerID == playerID {
			// 使用指数衰减更新
			s.memory[i].Effectiveness = s.memory[i].Effectiveness*0.8 + effectiveness*0.2
		}
	}

	logger.Debug("更新AI记忆效果: 玩家=%s, 获胜=%v, 新效果=%f", playerID, won, effectiveness)
}
