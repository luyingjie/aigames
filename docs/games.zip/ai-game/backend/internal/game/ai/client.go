package ai

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"time"

	"ai-game/pkg/logger"
)

// AIClient AI API客户端
type AIClient struct {
	httpClient *http.Client
	timeout    time.Duration
}

// NewAIClient 创建AI客户端
func NewAIClient(timeout time.Duration) *AIClient {
	return &AIClient{
		httpClient: &http.Client{
			Timeout: timeout,
		},
		timeout: timeout,
	}
}

// AIRequest AI请求
type AIRequest struct {
	Model       string  `json:"model"`       // AI模型
	Prompt      string  `json:"prompt"`      // 提示词
	Temperature float64 `json:"temperature"` // 创造性参数
	MaxTokens   int     `json:"max_tokens"`  // 最大token数
	APIKey      string  `json:"-"`           // API密钥(不序列化)
}

// AIResponse AI响应
type AIResponse struct {
	Choices []AIChoice `json:"choices"`
	Usage   AIUsage    `json:"usage"`
	Error   *AIError   `json:"error,omitempty"`
}

// AIChoice AI选择
type AIChoice struct {
	Text         string    `json:"text"`
	Message      AIMessage `json:"message"`
	FinishReason string    `json:"finish_reason"`
}

// AIMessage AI消息
type AIMessage struct {
	Role    string `json:"role"`
	Content string `json:"content"`
}

// AIUsage AI使用情况
type AIUsage struct {
	PromptTokens     int `json:"prompt_tokens"`
	CompletionTokens int `json:"completion_tokens"`
	TotalTokens      int `json:"total_tokens"`
}

// AIError AI错误
type AIError struct {
	Message string `json:"message"`
	Type    string `json:"type"`
	Code    string `json:"code"`
}

// GenerateResponse 生成AI响应
func (client *AIClient) GenerateResponse(req *AIRequest) (string, error) {
	logger.Debug("发送AI请求: model=%s, prompt长度=%d", req.Model, len(req.Prompt))

	// 根据模型选择API端点
	switch {
	case req.Model == "gpt-3.5-turbo" || req.Model == "gpt-4":
		return client.callOpenAI(req)
	case req.Model == "claude-3-sonnet" || req.Model == "claude-3-haiku":
		return client.callClaude(req)
	default:
		// 默认使用OpenAI兼容的API
		return client.callOpenAI(req)
	}
}

// callOpenAI 调用OpenAI API
func (client *AIClient) callOpenAI(req *AIRequest) (string, error) {
	// 构建请求体
	requestBody := map[string]interface{}{
		"model": req.Model,
		"messages": []map[string]string{
			{
				"role":    "user",
				"content": req.Prompt,
			},
		},
		"temperature": req.Temperature,
		"max_tokens":  req.MaxTokens,
	}

	// 序列化请求
	jsonData, err := json.Marshal(requestBody)
	if err != nil {
		return "", fmt.Errorf("序列化请求失败: %w", err)
	}

	// 创建HTTP请求
	httpReq, err := http.NewRequest("POST", "https://api.openai.com/v1/chat/completions", bytes.NewBuffer(jsonData))
	if err != nil {
		return "", fmt.Errorf("创建请求失败: %w", err)
	}

	// 设置请求头
	httpReq.Header.Set("Content-Type", "application/json")
	httpReq.Header.Set("Authorization", "Bearer "+req.APIKey)

	// 发送请求
	resp, err := client.httpClient.Do(httpReq)
	if err != nil {
		return "", fmt.Errorf("发送请求失败: %w", err)
	}
	defer resp.Body.Close()

	// 读取响应
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return "", fmt.Errorf("读取响应失败: %w", err)
	}

	// 检查HTTP状态码
	if resp.StatusCode != 200 {
		return "", fmt.Errorf("API请求失败, 状态码: %d, 响应: %s", resp.StatusCode, string(body))
	}

	// 解析响应
	var aiResp AIResponse
	if err := json.Unmarshal(body, &aiResp); err != nil {
		return "", fmt.Errorf("解析响应失败: %w", err)
	}

	// 检查API错误
	if aiResp.Error != nil {
		return "", fmt.Errorf("API错误: %s", aiResp.Error.Message)
	}

	// 提取响应内容
	if len(aiResp.Choices) == 0 {
		return "", fmt.Errorf("AI响应为空")
	}

	content := aiResp.Choices[0].Message.Content
	logger.Debug("AI响应成功: 长度=%d, tokens=%d", len(content), aiResp.Usage.TotalTokens)

	return content, nil
}

// callClaude 调用Claude API
func (client *AIClient) callClaude(req *AIRequest) (string, error) {
	// 构建请求体
	requestBody := map[string]interface{}{
		"model":      req.Model,
		"max_tokens": req.MaxTokens,
		"messages": []map[string]string{
			{
				"role":    "user",
				"content": req.Prompt,
			},
		},
		"temperature": req.Temperature,
	}

	// 序列化请求
	jsonData, err := json.Marshal(requestBody)
	if err != nil {
		return "", fmt.Errorf("序列化请求失败: %w", err)
	}

	// 创建HTTP请求
	httpReq, err := http.NewRequest("POST", "https://api.anthropic.com/v1/messages", bytes.NewBuffer(jsonData))
	if err != nil {
		return "", fmt.Errorf("创建请求失败: %w", err)
	}

	// 设置请求头
	httpReq.Header.Set("Content-Type", "application/json")
	httpReq.Header.Set("x-api-key", req.APIKey)
	httpReq.Header.Set("anthropic-version", "2023-06-01")

	// 发送请求
	resp, err := client.httpClient.Do(httpReq)
	if err != nil {
		return "", fmt.Errorf("发送请求失败: %w", err)
	}
	defer resp.Body.Close()

	// 读取响应
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return "", fmt.Errorf("读取响应失败: %w", err)
	}

	// 检查HTTP状态码
	if resp.StatusCode != 200 {
		return "", fmt.Errorf("API请求失败, 状态码: %d, 响应: %s", resp.StatusCode, string(body))
	}

	// 解析Claude响应(格式可能与OpenAI不同)
	var claudeResp map[string]interface{}
	if err := json.Unmarshal(body, &claudeResp); err != nil {
		return "", fmt.Errorf("解析响应失败: %w", err)
	}

	// 提取响应内容(根据Claude API格式调整)
	if content, ok := claudeResp["content"].([]interface{}); ok && len(content) > 0 {
		if textObj, ok := content[0].(map[string]interface{}); ok {
			if text, ok := textObj["text"].(string); ok {
				logger.Debug("Claude响应成功: 长度=%d", len(text))
				return text, nil
			}
		}
	}

	return "", fmt.Errorf("Claude响应格式错误")
}

// TestConnection 测试AI连接
func (client *AIClient) TestConnection(apiKey, model string) error {
	testReq := &AIRequest{
		Model:       model,
		Prompt:      "Hello, this is a test message. Please respond with 'OK'.",
		Temperature: 0.1,
		MaxTokens:   10,
		APIKey:      apiKey,
	}

	response, err := client.GenerateResponse(testReq)
	if err != nil {
		return fmt.Errorf("AI连接测试失败: %w", err)
	}

	logger.Info("AI连接测试成功: %s", response)
	return nil
}

// MockAIClient 模拟AI客户端(用于测试)
type MockAIClient struct {
	responses map[string]string
}

// NewMockAIClient 创建模拟AI客户端
func NewMockAIClient() *MockAIClient {
	return &MockAIClient{
		responses: map[string]string{
			"bidding": "1",
			"playing": "pass",
			"chat":    "good game!",
		},
	}
}

// GenerateResponse 生成模拟响应
func (mock *MockAIClient) GenerateResponse(req *AIRequest) (string, error) {
	// 简单的关键词匹配
	if req.Prompt == "" {
		return "", fmt.Errorf("空提示词")
	}

	// 根据提示词内容返回不同响应
	prompt := req.Prompt
	switch {
	case contains(prompt, "叫地主") || contains(prompt, "bidding"):
		return mock.responses["bidding"], nil
	case contains(prompt, "出牌") || contains(prompt, "playing"):
		return mock.responses["playing"], nil
	case contains(prompt, "聊天") || contains(prompt, "chat"):
		return mock.responses["chat"], nil
	default:
		return "我明白了", nil
	}
}

// SetResponse 设置模拟响应
func (mock *MockAIClient) SetResponse(key, response string) {
	mock.responses[key] = response
}

// TestConnection 测试连接(模拟)
func (mock *MockAIClient) TestConnection(apiKey, model string) error {
	return nil // 模拟客户端总是连接成功
}

// contains 检查字符串是否包含子字符串(不区分大小写)
func contains(s, substr string) bool {
	return len(s) >= len(substr) &&
		(s == substr ||
			(len(s) > len(substr) &&
				(s[:len(substr)] == substr ||
					s[len(s)-len(substr):] == substr ||
					findSubstring(s, substr))))
}

// findSubstring 查找子字符串
func findSubstring(s, substr string) bool {
	for i := 0; i <= len(s)-len(substr); i++ {
		if s[i:i+len(substr)] == substr {
			return true
		}
	}
	return false
}
