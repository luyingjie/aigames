package landlord

import (
	"math/rand"
	"sort"
	"time"

	"ai-game/internal/models"
)

// CardSet 牌组工具类
type CardSet struct {
	Cards []models.Card
}

// NewCardSet 创建新的牌组
func NewCardSet(cards []models.Card) *CardSet {
	return &CardSet{Cards: cards}
}

// NewFullDeck 创建一副完整的扑克牌(54张)
func NewFullDeck() *CardSet {
	cards := make([]models.Card, 0, 54)

	// 添加普通牌 3-A
	for suit := 1; suit <= 4; suit++ {
		for rank := 3; rank <= 14; rank++ {
			cards = append(cards, models.Card{Suit: suit, Rank: rank})
		}
	}

	// 添加2
	for suit := 1; suit <= 4; suit++ {
		cards = append(cards, models.Card{Suit: suit, Rank: 15})
	}

	// 添加大小王
	cards = append(cards, models.Card{Suit: 0, Rank: 16}) // 小王
	cards = append(cards, models.Card{Suit: 0, Rank: 17}) // 大王

	return &CardSet{Cards: cards}
}

// Shuffle 洗牌
func (cs *CardSet) Shuffle() {
	rand.Seed(time.Now().UnixNano())
	rand.Shuffle(len(cs.Cards), func(i, j int) {
		cs.Cards[i], cs.Cards[j] = cs.Cards[j], cs.Cards[i]
	})
}

// Sort 排序（按点数从小到大）
func (cs *CardSet) Sort() {
	sort.Slice(cs.Cards, func(i, j int) bool {
		return cs.Cards[i].Rank < cs.Cards[j].Rank
	})
}

// SortDesc 排序（按点数从大到小）
func (cs *CardSet) SortDesc() {
	sort.Slice(cs.Cards, func(i, j int) bool {
		return cs.Cards[i].Rank > cs.Cards[j].Rank
	})
}

// Count 获取牌数
func (cs *CardSet) Count() int {
	return len(cs.Cards)
}

// Contains 检查是否包含指定牌
func (cs *CardSet) Contains(card models.Card) bool {
	for _, c := range cs.Cards {
		if c.Suit == card.Suit && c.Rank == card.Rank {
			return true
		}
	}
	return false
}

// Remove 移除指定的牌
func (cs *CardSet) Remove(cards []models.Card) bool {
	for _, card := range cards {
		found := false
		for i, c := range cs.Cards {
			if c.Suit == card.Suit && c.Rank == card.Rank {
				cs.Cards = append(cs.Cards[:i], cs.Cards[i+1:]...)
				found = true
				break
			}
		}
		if !found {
			return false // 没有找到要移除的牌
		}
	}
	return true
}

// Add 添加牌
func (cs *CardSet) Add(cards []models.Card) {
	cs.Cards = append(cs.Cards, cards...)
}

// GetRankCount 获取各点数的牌数统计
func (cs *CardSet) GetRankCount() map[int]int {
	counts := make(map[int]int)
	for _, card := range cs.Cards {
		counts[card.Rank]++
	}
	return counts
}

// GetSuitCount 获取各花色的牌数统计
func (cs *CardSet) GetSuitCount() map[int]int {
	counts := make(map[int]int)
	for _, card := range cs.Cards {
		if card.Rank < 16 { // 不包括大小王
			counts[card.Suit]++
		}
	}
	return counts
}

// HasJokers 检查是否有王牌
func (cs *CardSet) HasJokers() (bool, bool) {
	hasLittleJoker := false
	hasBigJoker := false

	for _, card := range cs.Cards {
		if card.Rank == 16 {
			hasLittleJoker = true
		} else if card.Rank == 17 {
			hasBigJoker = true
		}
	}

	return hasLittleJoker, hasBigJoker
}

// IsJokerBomb 检查是否为王炸
func (cs *CardSet) IsJokerBomb() bool {
	if len(cs.Cards) != 2 {
		return false
	}

	little, big := cs.HasJokers()
	return little && big
}

// Clone 克隆牌组
func (cs *CardSet) Clone() *CardSet {
	newCards := make([]models.Card, len(cs.Cards))
	copy(newCards, cs.Cards)
	return &CardSet{Cards: newCards}
}

// String 获取牌组的字符串表示
func (cs *CardSet) String() string {
	if len(cs.Cards) == 0 {
		return "空手牌"
	}

	result := ""
	for i, card := range cs.Cards {
		if i > 0 {
			result += " "
		}
		result += card.String()
	}
	return result
}

// Deal 发牌（从牌组中取出指定数量的牌）
func (cs *CardSet) Deal(count int) []models.Card {
	if count > len(cs.Cards) {
		count = len(cs.Cards)
	}

	dealt := make([]models.Card, count)
	copy(dealt, cs.Cards[:count])
	cs.Cards = cs.Cards[count:]

	return dealt
}

// AnalyzeHand 分析手牌结构（用于AI决策）
func (cs *CardSet) AnalyzeHand() *HandAnalysis {
	analysis := &HandAnalysis{
		TotalCards: len(cs.Cards),
		RankCounts: cs.GetRankCount(),
		Singles:    make([]int, 0),
		Pairs:      make([]int, 0),
		Triples:    make([]int, 0),
		Bombs:      make([]int, 0),
	}

	// 分析各点数的数量
	for rank, count := range analysis.RankCounts {
		switch count {
		case 1:
			analysis.Singles = append(analysis.Singles, rank)
		case 2:
			analysis.Pairs = append(analysis.Pairs, rank)
		case 3:
			analysis.Triples = append(analysis.Triples, rank)
		case 4:
			analysis.Bombs = append(analysis.Bombs, rank)
		}
	}

	// 检查王炸
	little, big := cs.HasJokers()
	if little && big {
		analysis.HasJokerBomb = true
	}

	// 分析连续性（顺子可能）
	analysis.analyzeSequences()

	return analysis
}

// HandAnalysis 手牌分析结果
type HandAnalysis struct {
	TotalCards      int         // 总牌数
	RankCounts      map[int]int // 各点数数量
	Singles         []int       // 单张
	Pairs           []int       // 对子
	Triples         []int       // 三张
	Bombs           []int       // 炸弹
	HasJokerBomb    bool        // 是否有王炸
	Sequences       []Sequence  // 可能的顺子
	PairSequences   []Sequence  // 可能的连对
	TripleSequences []Sequence  // 可能的飞机
}

// Sequence 连续牌型
type Sequence struct {
	StartRank int // 起始点数
	Length    int // 长度
	Count     int // 每个点数的数量（1=顺子，2=连对，3=飞机）
}

// analyzeSequences 分析连续牌型
func (ha *HandAnalysis) analyzeSequences() {
	// 分析单张顺子
	ha.findSequences(ha.Singles, 1, 5) // 最少5张

	// 分析连对
	ha.findSequences(ha.Pairs, 2, 3) // 最少3对

	// 分析飞机
	ha.findSequences(ha.Triples, 3, 2) // 最少2个三张
}

// findSequences 查找连续序列
func (ha *HandAnalysis) findSequences(ranks []int, count, minLength int) {
	if len(ranks) < minLength {
		return
	}

	// 排序
	sort.Ints(ranks)

	// 查找连续序列
	start := 0
	for start < len(ranks) {
		length := 1

		// 找连续的牌
		for i := start + 1; i < len(ranks); i++ {
			if ranks[i] == ranks[i-1]+1 && ranks[i] < 15 { // 2不能参与顺子
				length++
			} else {
				break
			}
		}

		// 如果长度满足要求，添加到序列
		if length >= minLength {
			seq := Sequence{
				StartRank: ranks[start],
				Length:    length,
				Count:     count,
			}

			switch count {
			case 1:
				ha.Sequences = append(ha.Sequences, seq)
			case 2:
				ha.PairSequences = append(ha.PairSequences, seq)
			case 3:
				ha.TripleSequences = append(ha.TripleSequences, seq)
			}
		}

		start += length
	}
}
