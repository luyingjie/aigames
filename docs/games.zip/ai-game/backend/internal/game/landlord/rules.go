package landlord

import (
	"fmt"
	"sort"

	"ai-game/internal/models"
	"ai-game/pkg/constants"
)

// RuleEngine 斗地主规则引擎
type RuleEngine struct{}

// NewRuleEngine 创建规则引擎
func NewRuleEngine() *RuleEngine {
	return &RuleEngine{}
}

// ValidatePlay 验证出牌是否合法
func (re *RuleEngine) ValidatePlay(cards []models.Card, lastPlay *models.PlayCards) (*models.PlayCards, error) {
	if len(cards) == 0 {
		return nil, fmt.Errorf("不能出空牌")
	}

	// 分析出牌类型
	playType, mainRank, length, err := re.AnalyzePlayType(cards)
	if err != nil {
		return nil, err
	}

	play := &models.PlayCards{
		Cards:    cards,
		Type:     playType,
		MainRank: mainRank,
		Length:   length,
	}

	// 如果是首次出牌，任何合法牌型都可以
	if lastPlay == nil || lastPlay.IsEmpty() {
		return play, nil
	}

	// 检查是否能压过上一手牌
	if !re.CanBeat(play, lastPlay) {
		return nil, fmt.Errorf("无法压过上一手牌")
	}

	return play, nil
}

// AnalyzePlayType 分析出牌类型
func (re *RuleEngine) AnalyzePlayType(cards []models.Card) (playType, mainRank, length int, err error) {
	cardCount := len(cards)
	if cardCount == 0 {
		return 0, 0, 0, fmt.Errorf("空牌")
	}

	// 统计各点数的数量
	rankCounts := make(map[int]int)
	for _, card := range cards {
		rankCounts[card.Rank]++
	}

	switch cardCount {
	case 1:
		return re.analyzeSingle(cards, rankCounts)
	case 2:
		return re.analyzePair(cards, rankCounts)
	case 3:
		return re.analyzeTriple(cards, rankCounts)
	case 4:
		return re.analyzeFour(cards, rankCounts)
	case 5:
		return re.analyzeFive(cards, rankCounts)
	default:
		if cardCount >= 6 {
			return re.analyzeComplex(cards, rankCounts)
		}
	}

	return 0, 0, 0, fmt.Errorf("无效的牌型")
}

// analyzeSingle 分析单张
func (re *RuleEngine) analyzeSingle(cards []models.Card, rankCounts map[int]int) (int, int, int, error) {
	if len(rankCounts) != 1 {
		return 0, 0, 0, fmt.Errorf("不是单张")
	}

	for rank := range rankCounts {
		return constants.PlayTypeSingle, rank, 1, nil
	}

	return 0, 0, 0, fmt.Errorf("分析单张失败")
}

// analyzePair 分析对子
func (re *RuleEngine) analyzePair(cards []models.Card, rankCounts map[int]int) (int, int, int, error) {
	// 对子
	if len(rankCounts) == 1 {
		for rank, count := range rankCounts {
			if count == 2 {
				return constants.PlayTypePair, rank, 1, nil
			}
		}
	}

	// 王炸
	if re.isJokerBomb(cards) {
		return constants.PlayTypeJokerBomb, 17, 1, nil // 大王的点数作为主点数
	}

	return 0, 0, 0, fmt.Errorf("不是对子或王炸")
}

// analyzeTriple 分析三张
func (re *RuleEngine) analyzeTriple(cards []models.Card, rankCounts map[int]int) (int, int, int, error) {
	if len(rankCounts) != 1 {
		return 0, 0, 0, fmt.Errorf("不是三张")
	}

	for rank, count := range rankCounts {
		if count == 3 {
			return constants.PlayTypeTriple, rank, 1, nil
		}
	}

	return 0, 0, 0, fmt.Errorf("不是三张")
}

// analyzeFour 分析四张牌型
func (re *RuleEngine) analyzeFour(cards []models.Card, rankCounts map[int]int) (int, int, int, error) {
	// 炸弹
	if len(rankCounts) == 1 {
		for rank, count := range rankCounts {
			if count == 4 {
				return constants.PlayTypeBomb, rank, 1, nil
			}
		}
	}

	// 三带一
	if len(rankCounts) == 2 {
		var tripleRank int
		hasTriple := false
		hasSingle := false

		for rank, count := range rankCounts {
			if count == 3 {
				tripleRank = rank
				hasTriple = true
			} else if count == 1 {
				hasSingle = true
			}
		}

		if hasTriple && hasSingle {
			return constants.PlayTypeTripleSingle, tripleRank, 1, nil
		}
	}

	return 0, 0, 0, fmt.Errorf("无效的四张牌型")
}

// analyzeFive 分析五张牌型
func (re *RuleEngine) analyzeFive(cards []models.Card, rankCounts map[int]int) (int, int, int, error) {
	// 三带一对
	if len(rankCounts) == 2 {
		var tripleRank int
		hasTriple := false
		hasPair := false

		for rank, count := range rankCounts {
			if count == 3 {
				tripleRank = rank
				hasTriple = true
			} else if count == 2 {
				hasPair = true
			}
		}

		if hasTriple && hasPair {
			return constants.PlayTypeTriplePair, tripleRank, 1, nil
		}
	}

	// 顺子
	if re.isStraight(cards, 1) {
		minRank := re.getMinRank(cards)
		return constants.PlayTypeStraight, minRank, 5, nil
	}

	return 0, 0, 0, fmt.Errorf("无效的五张牌型")
}

// analyzeComplex 分析复杂牌型
func (re *RuleEngine) analyzeComplex(cards []models.Card, rankCounts map[int]int) (int, int, int, error) {
	cardCount := len(cards)

	// 顺子（6张以上）
	if re.isStraight(cards, 1) {
		minRank := re.getMinRank(cards)
		return constants.PlayTypeStraight, minRank, cardCount, nil
	}

	// 连对（6张以上，必须是偶数）
	if cardCount%2 == 0 && re.isPairStraight(cards) {
		minRank := re.getMinRank(cards)
		return constants.PlayTypePairStraight, minRank, cardCount / 2, nil
	}

	// 飞机（6张以上，必须是3的倍数）
	if cardCount%3 == 0 && re.isTripleStraight(cards) {
		minRank := re.getMinRank(re.getTripleCards(cards))
		return constants.PlayTypeTripleStraight, minRank, cardCount / 3, nil
	}

	// 飞机带单张
	if re.isTripleStraightWithSingles(cards, rankCounts) {
		tripleCards := re.getTripleCards(cards)
		minRank := re.getMinRank(tripleCards)
		return constants.PlayTypeTripleSinglePlane, minRank, len(tripleCards) / 3, nil
	}

	// 飞机带对子
	if re.isTripleStraightWithPairs(cards, rankCounts) {
		tripleCards := re.getTripleCards(cards)
		minRank := re.getMinRank(tripleCards)
		return constants.PlayTypeTriplePairPlane, minRank, len(tripleCards) / 3, nil
	}

	// 四带两单
	if re.isFourWithTwoSingles(cards, rankCounts) {
		bombRank := re.getBombRank(rankCounts)
		return constants.PlayTypeFourDualSingle, bombRank, 1, nil
	}

	// 四带两对
	if re.isFourWithTwoPairs(cards, rankCounts) {
		bombRank := re.getBombRank(rankCounts)
		return constants.PlayTypeFourDualPair, bombRank, 1, nil
	}

	return 0, 0, 0, fmt.Errorf("无效的牌型")
}

// CanBeat 判断是否能压过另一手牌
func (re *RuleEngine) CanBeat(play, lastPlay *models.PlayCards) bool {
	// 王炸可以压过任何牌
	if play.Type == constants.PlayTypeJokerBomb {
		return true
	}

	// 炸弹可以压过非炸弹
	if play.Type == constants.PlayTypeBomb && lastPlay.Type != constants.PlayTypeBomb && lastPlay.Type != constants.PlayTypeJokerBomb {
		return true
	}

	// 同类型牌型才能比较
	if play.Type != lastPlay.Type {
		return false
	}

	// 长度必须相同（对于连续牌型）
	if play.Length != lastPlay.Length {
		return false
	}

	// 比较主要点数
	return play.MainRank > lastPlay.MainRank
}

// 辅助函数

// isJokerBomb 判断是否为王炸
func (re *RuleEngine) isJokerBomb(cards []models.Card) bool {
	if len(cards) != 2 {
		return false
	}

	hasLittleJoker := false
	hasBigJoker := false

	for _, card := range cards {
		if card.Rank == 16 {
			hasLittleJoker = true
		} else if card.Rank == 17 {
			hasBigJoker = true
		}
	}

	return hasLittleJoker && hasBigJoker
}

// isStraight 判断是否为顺子
func (re *RuleEngine) isStraight(cards []models.Card, count int) bool {
	if len(cards) < 5*count {
		return false
	}

	// 统计各点数的数量
	rankCounts := make(map[int]int)
	for _, card := range cards {
		if card.Rank >= 15 { // 2和大小王不能参与顺子
			return false
		}
		rankCounts[card.Rank]++
	}

	// 检查每个点数都有指定数量的牌
	for _, cardCount := range rankCounts {
		if cardCount != count {
			return false
		}
	}

	// 检查是否连续
	ranks := make([]int, 0, len(rankCounts))
	for rank := range rankCounts {
		ranks = append(ranks, rank)
	}
	sort.Ints(ranks)

	for i := 1; i < len(ranks); i++ {
		if ranks[i] != ranks[i-1]+1 {
			return false
		}
	}

	return true
}

// isPairStraight 判断是否为连对
func (re *RuleEngine) isPairStraight(cards []models.Card) bool {
	return re.isStraight(cards, 2)
}

// isTripleStraight 判断是否为飞机
func (re *RuleEngine) isTripleStraight(cards []models.Card) bool {
	return re.isStraight(cards, 3)
}

// isTripleStraightWithSingles 判断是否为飞机带单张
func (re *RuleEngine) isTripleStraightWithSingles(cards []models.Card, rankCounts map[int]int) bool {
	tripleCount := 0
	singleCount := 0

	for _, count := range rankCounts {
		if count == 3 {
			tripleCount++
		} else if count == 1 {
			singleCount++
		} else {
			return false
		}
	}

	if tripleCount < 2 || singleCount != tripleCount {
		return false
	}

	// 检查三张是否连续
	return re.isTripleStraight(re.getTripleCards(cards))
}

// isTripleStraightWithPairs 判断是否为飞机带对子
func (re *RuleEngine) isTripleStraightWithPairs(cards []models.Card, rankCounts map[int]int) bool {
	tripleCount := 0
	pairCount := 0

	for _, count := range rankCounts {
		if count == 3 {
			tripleCount++
		} else if count == 2 {
			pairCount++
		} else {
			return false
		}
	}

	if tripleCount < 2 || pairCount != tripleCount {
		return false
	}

	// 检查三张是否连续
	return re.isTripleStraight(re.getTripleCards(cards))
}

// isFourWithTwoSingles 判断是否为四带两单
func (re *RuleEngine) isFourWithTwoSingles(cards []models.Card, rankCounts map[int]int) bool {
	if len(cards) != 6 {
		return false
	}

	bombCount := 0
	singleCount := 0

	for _, count := range rankCounts {
		if count == 4 {
			bombCount++
		} else if count == 1 {
			singleCount++
		} else {
			return false
		}
	}

	return bombCount == 1 && singleCount == 2
}

// isFourWithTwoPairs 判断是否为四带两对
func (re *RuleEngine) isFourWithTwoPairs(cards []models.Card, rankCounts map[int]int) bool {
	if len(cards) != 8 {
		return false
	}

	bombCount := 0
	pairCount := 0

	for _, count := range rankCounts {
		if count == 4 {
			bombCount++
		} else if count == 2 {
			pairCount++
		} else {
			return false
		}
	}

	return bombCount == 1 && pairCount == 2
}

// getMinRank 获取最小点数
func (re *RuleEngine) getMinRank(cards []models.Card) int {
	if len(cards) == 0 {
		return 0
	}

	minRank := cards[0].Rank
	for _, card := range cards {
		if card.Rank < minRank {
			minRank = card.Rank
		}
	}
	return minRank
}

// getTripleCards 获取三张牌的cards
func (re *RuleEngine) getTripleCards(cards []models.Card) []models.Card {
	rankCounts := make(map[int]int)
	for _, card := range cards {
		rankCounts[card.Rank]++
	}

	var tripleCards []models.Card
	for _, card := range cards {
		if rankCounts[card.Rank] == 3 {
			tripleCards = append(tripleCards, card)
		}
	}

	return tripleCards
}

// getBombRank 获取炸弹的点数
func (re *RuleEngine) getBombRank(rankCounts map[int]int) int {
	for rank, count := range rankCounts {
		if count == 4 {
			return rank
		}
	}
	return 0
}

// GetValidPlays 获取可以出的牌型
func (re *RuleEngine) GetValidPlays(handCards []models.Card, lastPlay *models.PlayCards) [][]models.Card {
	// var validPlays [][]models.Card

	// 如果没有上一手牌，可以出任意合法牌型
	if lastPlay == nil || lastPlay.IsEmpty() {
		return re.getAllPossiblePlays(handCards)
	}

	// 寻找能够压过上一手牌的牌型
	return re.getBeatingPlays(handCards, lastPlay)
}

// getAllPossiblePlays 获取所有可能的牌型
func (re *RuleEngine) getAllPossiblePlays(handCards []models.Card) [][]models.Card {
	// 这里可以实现获取所有可能牌型的逻辑
	// 为了简化，先返回一些基本的牌型
	var plays [][]models.Card

	// 添加单张
	for _, card := range handCards {
		plays = append(plays, []models.Card{card})
	}

	// 可以添加更多复杂的牌型分析
	// ...

	return plays
}

// getBeatingPlays 获取能够压过指定牌型的牌
func (re *RuleEngine) getBeatingPlays(handCards []models.Card, lastPlay *models.PlayCards) [][]models.Card {
	// 这里可以实现寻找压牌的逻辑
	// 为了简化，先返回空切片
	return [][]models.Card{}
}
