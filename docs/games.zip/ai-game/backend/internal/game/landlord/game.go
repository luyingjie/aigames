package landlord

import (
	"fmt"
	"time"

	"ai-game/internal/models"
	"ai-game/internal/utils"
	"ai-game/pkg/constants"
	"ai-game/pkg/logger"
)

// Game 斗地主游戏
type Game struct {
	*models.Game
	dealer      *Dealer
	rules       *RuleEngine
	scorer      *Scorer
	biddingTurn int // 当前叫地主的玩家位置
}

// NewGame 创建新游戏
func NewGame(roomID string, players []models.Player) *Game {
	game := &Game{
		Game: &models.Game{
			ID:          utils.GenerateGameID(),
			RoomID:      roomID,
			Players:     players,
			Phase:       constants.GamePhaseWaiting,
			CurrentTurn: 0,
			LandlordPos: -1,
			HoleCards:   []models.Card{},
			LastPlay:    models.PlayCards{},
			LastPlayer:  -1,
			PlayHistory: []models.GamePlay{},
			Winner:      0,
			StartAt:     time.Now(),
			Status:      0,
		},
		dealer:      NewDealer(),
		rules:       NewRuleEngine(),
		scorer:      NewScorer(),
		biddingTurn: 0,
	}

	// 设置玩家位置
	for i := range game.Players {
		game.Players[i].Position = i
		game.Players[i].Role = constants.RoleNone
		game.Players[i].IsReady = true
		game.Players[i].IsCurrent = false
	}

	logger.Info("创建新游戏：%s，房间：%s", game.ID, roomID)
	return game
}

// Start 开始游戏
func (g *Game) Start() error {
	if g.Phase != constants.GamePhaseWaiting {
		return fmt.Errorf("游戏已经开始")
	}

	if len(g.Players) != 3 {
		return fmt.Errorf("斗地主需要3个玩家")
	}

	// 发牌
	playerPtrs := make([]*models.Player, len(g.Players))
	for i := range g.Players {
		playerPtrs[i] = &g.Players[i]
	}

	if err := g.dealer.DealCards(playerPtrs); err != nil {
		return fmt.Errorf("发牌失败: %v", err)
	}

	// 保存底牌
	g.HoleCards = g.dealer.GetHoleCards()

	// 开始叫地主阶段
	g.Phase = constants.GamePhaseBidding
	g.Status = 1
	g.biddingTurn = 0
	g.Players[0].IsCurrent = true

	logger.Info("游戏开始：%s，进入叫地主阶段", g.ID)
	return nil
}

// BidLandlord 叫地主
func (g *Game) BidLandlord(playerPos int, bid bool) error {
	if g.Phase != constants.GamePhaseBidding {
		return fmt.Errorf("当前不是叫地主阶段")
	}

	if playerPos != g.biddingTurn {
		return fmt.Errorf("不是您的叫地主回合")
	}

	player := &g.Players[playerPos]
	logger.Info("玩家%s(%d) 叫地主: %v", player.Nickname, playerPos, bid)

	// 记录叫地主历史
	g.AddPlayHistory(playerPos, []models.Card{}, 0, !bid)

	if bid {
		// 成为地主
		g.LandlordPos = playerPos
		player.Role = constants.RoleLandlord

		// 其他玩家成为农民
		for i := range g.Players {
			if i != playerPos {
				g.Players[i].Role = constants.RoleFarmer
			}
		}

		// 地主获得底牌
		g.dealer.GiveHoleCardsToLandlord(player)

		// 进入出牌阶段，地主先出
		g.Phase = constants.GamePhasePlaying
		g.CurrentTurn = playerPos
		g.updateCurrentPlayer()

		logger.Info("玩家%s成为地主，游戏进入出牌阶段", player.Nickname)
		return nil
	}

	// 不叫地主，轮到下一个玩家
	g.nextBiddingTurn()

	// 如果所有人都不叫地主，重新开始或结束游戏
	if g.biddingTurn == 0 && g.LandlordPos == -1 {
		// 所有人都不叫，游戏结束，重新开始
		logger.Info("所有玩家都不叫地主，游戏重新开始")
		return g.Restart()
	}

	return nil
}

// PlayCards 出牌
func (g *Game) PlayCards(playerPos int, cards []models.Card) error {
	if g.Phase != constants.GamePhasePlaying {
		return fmt.Errorf("当前不是出牌阶段")
	}

	if playerPos != g.CurrentTurn {
		return fmt.Errorf("不是您的出牌回合")
	}

	player := &g.Players[playerPos]

	// 验证玩家是否有这些牌
	if !g.hasCards(player, cards) {
		return fmt.Errorf("您没有这些牌")
	}

	// 验证出牌是否合法
	play, err := g.rules.ValidatePlay(cards, &g.LastPlay)
	if err != nil {
		return fmt.Errorf("出牌不合法: %v", err)
	}

	// 从玩家手牌中移除这些牌
	if !player.RemoveCards(cards) {
		return fmt.Errorf("移除手牌失败")
	}

	// 更新游戏状态
	g.LastPlay = *play
	g.LastPlayer = playerPos
	player.LastPlay = *play

	// 记录出牌历史
	g.AddPlayHistory(playerPos, cards, play.Type, false)

	logger.Info("玩家%s出牌：%s（%s）", player.Nickname, NewCardSet(cards).String(), g.getPlayTypeName(play.Type))

	// 检查是否获胜
	if player.IsWinner() {
		return g.endGame(playerPos)
	}

	// 切换到下一个玩家
	g.nextTurn()

	return nil
}

// Pass 过牌
func (g *Game) Pass(playerPos int) error {
	if g.Phase != constants.GamePhasePlaying {
		return fmt.Errorf("当前不是出牌阶段")
	}

	if playerPos != g.CurrentTurn {
		return fmt.Errorf("不是您的出牌回合")
	}

	// 如果是最后出牌的玩家，不能过牌
	if playerPos == g.LastPlayer {
		return fmt.Errorf("您是最后出牌的玩家，不能过牌")
	}

	player := &g.Players[playerPos]
	logger.Info("玩家%s过牌", player.Nickname)

	// 记录过牌历史
	g.AddPlayHistory(playerPos, []models.Card{}, 0, true)

	// 切换到下一个玩家
	g.nextTurn()

	// 检查是否一轮都过牌了（除了最后出牌的玩家）
	if g.allOtherPlayersPassed() {
		// 清空最后出牌，最后出牌的玩家重新出牌
		g.LastPlay = models.PlayCards{}
		g.LastPlayer = -1
		g.CurrentTurn = g.getLastActivePlayer()
		g.updateCurrentPlayer()
		logger.Info("所有其他玩家都过牌，重新开始新一轮")
	}

	return nil
}

// Restart 重新开始游戏
func (g *Game) Restart() error {
	// 重置游戏状态
	g.dealer.Reset()
	g.Phase = constants.GamePhaseWaiting
	g.CurrentTurn = 0
	g.LandlordPos = -1
	g.LastPlay = models.PlayCards{}
	g.LastPlayer = -1
	g.PlayHistory = []models.GamePlay{}
	g.Winner = 0
	g.biddingTurn = 0

	// 重置玩家状态
	for i := range g.Players {
		g.Players[i].Role = constants.RoleNone
		g.Players[i].HandCards = []models.Card{}
		g.Players[i].IsCurrent = false
		g.Players[i].LastPlay = models.PlayCards{}
	}

	logger.Info("游戏重新开始：%s", g.ID)
	return g.Start()
}

// GetGameState 获取游戏状态（用于前端显示）
func (g *Game) GetGameState() map[string]interface{} {
	return map[string]interface{}{
		"id":           g.ID,
		"phase":        g.Phase,
		"current_turn": g.CurrentTurn,
		"landlord_pos": g.LandlordPos,
		"last_play":    g.LastPlay,
		"last_player":  g.LastPlayer,
		"players":      g.getPlayersInfo(),
		"winner":       g.Winner,
		"status":       g.Status,
	}
}

// 私有方法

// nextBiddingTurn 下一个叫地主回合
func (g *Game) nextBiddingTurn() {
	g.Players[g.biddingTurn].IsCurrent = false
	g.biddingTurn = (g.biddingTurn + 1) % 3
	g.Players[g.biddingTurn].IsCurrent = true
}

// nextTurn 下一个出牌回合
func (g *Game) nextTurn() {
	g.Players[g.CurrentTurn].IsCurrent = false
	g.CurrentTurn = (g.CurrentTurn + 1) % 3
	g.updateCurrentPlayer()
}

// updateCurrentPlayer 更新当前玩家状态
func (g *Game) updateCurrentPlayer() {
	for i := range g.Players {
		g.Players[i].IsCurrent = (i == g.CurrentTurn)
	}
}

// hasCards 检查玩家是否有指定的牌
func (g *Game) hasCards(player *models.Player, cards []models.Card) bool {
	handSet := NewCardSet(player.HandCards)
	for _, card := range cards {
		if !handSet.Contains(card) {
			return false
		}
	}
	return true
}

// endGame 结束游戏
func (g *Game) endGame(winnerPos int) error {
	g.Phase = constants.GamePhaseFinished
	g.Status = 2
	g.EndAt = time.Now()

	winner := &g.Players[winnerPos]
	if winner.Role == constants.RoleLandlord {
		g.Winner = 1 // 地主胜
	} else {
		g.Winner = 2 // 农民胜
	}

	// 计算得分
	scores := g.scorer.CalculateScores(g.Game)

	logger.Info("游戏结束：%s，获胜方：%d，获胜玩家：%s", g.ID, g.Winner, winner.Nickname)
	for userID, score := range scores {
		logger.Info("玩家%s得分：%d", userID, score)
	}

	return nil
}

// allOtherPlayersPassed 检查是否所有其他玩家都过牌了
func (g *Game) allOtherPlayersPassed() bool {
	if g.LastPlayer == -1 {
		return false
	}

	passCount := 0
	recentPlays := g.PlayHistory
	if len(recentPlays) < 2 {
		return false
	}

	// 检查最近的出牌记录
	for i := len(recentPlays) - 1; i >= 0 && passCount < 2; i-- {
		play := recentPlays[i]
		if play.PlayerPos == g.LastPlayer {
			break
		}
		if play.IsPass {
			passCount++
		} else {
			return false
		}
	}

	return passCount == 2
}

// getLastActivePlayer 获取最后出牌的玩家
func (g *Game) getLastActivePlayer() int {
	for i := len(g.PlayHistory) - 1; i >= 0; i-- {
		play := g.PlayHistory[i]
		if !play.IsPass {
			return play.PlayerPos
		}
	}
	return g.CurrentTurn
}

// getPlayersInfo 获取玩家信息（隐藏手牌）
func (g *Game) getPlayersInfo() []map[string]interface{} {
	players := make([]map[string]interface{}, len(g.Players))
	for i, player := range g.Players {
		players[i] = map[string]interface{}{
			"user_id":    player.UserID,
			"nickname":   player.Nickname,
			"avatar":     player.Avatar,
			"position":   player.Position,
			"role":       player.Role,
			"card_count": len(player.HandCards),
			"is_current": player.IsCurrent,
			"last_play":  player.LastPlay,
		}
	}
	return players
}

// getPlayTypeName 获取出牌类型名称
func (g *Game) getPlayTypeName(playType int) string {
	names := map[int]string{
		constants.PlayTypeSingle:            "单张",
		constants.PlayTypePair:              "对子",
		constants.PlayTypeTriple:            "三张",
		constants.PlayTypeTriplePair:        "三带一对",
		constants.PlayTypeTripleSingle:      "三带一",
		constants.PlayTypeStraight:          "顺子",
		constants.PlayTypePairStraight:      "连对",
		constants.PlayTypeTripleStraight:    "飞机",
		constants.PlayTypeTriplePairPlane:   "飞机带对子",
		constants.PlayTypeTripleSinglePlane: "飞机带单张",
		constants.PlayTypeFourDualPair:      "四带两对",
		constants.PlayTypeFourDualSingle:    "四带两单",
		constants.PlayTypeBomb:              "炸弹",
		constants.PlayTypeJokerBomb:         "王炸",
	}

	if name, exists := names[playType]; exists {
		return name
	}
	return "未知牌型"
}
