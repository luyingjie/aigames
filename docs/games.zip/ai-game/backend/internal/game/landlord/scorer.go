package landlord

import (
	"fmt"

	"ai-game/internal/models"
	"ai-game/pkg/constants"
	"ai-game/pkg/logger"
)

// Scorer 计分器
type Scorer struct {
	baseScore int // 基础分数
}

// NewScorer 创建计分器
func NewScorer() *Scorer {
	return &Scorer{
		baseScore: 100, // 基础分数100分
	}
}

// CalculateScores 计算游戏得分
func (s *Scorer) CalculateScores(game *models.Game) map[string]int {
	scores := make(map[string]int)

	if game.Winner == 0 {
		// 游戏未结束，所有人得分为0
		for _, player := range game.Players {
			scores[player.UserID] = 0
		}
		return scores
	}

	// 计算倍数
	multiplier := s.calculateMultiplier(game)
	finalScore := s.baseScore * multiplier

	logger.Info("计分：基础分数=%d，倍数=%d，最终分数=%d", s.baseScore, multiplier, finalScore)

	// 分配得分
	if game.Winner == 1 {
		// 地主获胜
		s.distributeLandlordWin(game, finalScore, scores)
	} else {
		// 农民获胜
		s.distributeFarmersWin(game, finalScore, scores)
	}

	return scores
}

// calculateMultiplier 计算倍数
func (s *Scorer) calculateMultiplier(game *models.Game) int {
	multiplier := 1

	// 基础倍数规则

	// 1. 炸弹倍数
	bombCount := s.countBombs(game)
	multiplier *= (1 << bombCount) // 每个炸弹翻倍

	// 2. 王炸倍数
	if s.hasJokerBomb(game) {
		multiplier *= 2
	}

	// 3. 春天/反春天
	if s.isSpring(game) {
		multiplier *= 2
		logger.Info("春天/反春天，倍数翻倍")
	}

	// 4. 地主牌型强度
	landlordPos := game.LandlordPos
	if landlordPos >= 0 && landlordPos < len(game.Players) {
		strengthMultiplier := s.calculateStrengthMultiplier(&game.Players[landlordPos])
		multiplier += strengthMultiplier
	}

	// 限制最大倍数
	if multiplier > 32 {
		multiplier = 32
	}

	return multiplier
}

// distributeLandlordWin 地主获胜时的分数分配
func (s *Scorer) distributeLandlordWin(game *models.Game, finalScore int, scores map[string]int) {
	landlordPos := game.LandlordPos

	for i, player := range game.Players {
		if i == landlordPos {
			// 地主得分 = 基础分数 * 倍数 * 农民数量
			scores[player.UserID] = finalScore * 2
		} else {
			// 农民失分
			scores[player.UserID] = -finalScore
		}
	}

	logger.Info("地主获胜：地主+%d分，农民各-%d分", finalScore*2, finalScore)
}

// distributeFarmersWin 农民获胜时的分数分配
func (s *Scorer) distributeFarmersWin(game *models.Game, finalScore int, scores map[string]int) {
	landlordPos := game.LandlordPos

	for i, player := range game.Players {
		if i == landlordPos {
			// 地主失分
			scores[player.UserID] = -finalScore * 2
		} else {
			// 农民得分
			scores[player.UserID] = finalScore
		}
	}

	logger.Info("农民获胜：农民各+%d分，地主-%d分", finalScore, finalScore*2)
}

// countBombs 统计游戏中的炸弹数量
func (s *Scorer) countBombs(game *models.Game) int {
	bombCount := 0

	for _, play := range game.PlayHistory {
		if play.Type == constants.PlayTypeBomb {
			bombCount++
		}
	}

	logger.Debug("统计炸弹数量：%d", bombCount)
	return bombCount
}

// hasJokerBomb 检查游戏中是否有王炸
func (s *Scorer) hasJokerBomb(game *models.Game) bool {
	for _, play := range game.PlayHistory {
		if play.Type == constants.PlayTypeJokerBomb {
			logger.Debug("发现王炸")
			return true
		}
	}
	return false
}

// isSpring 检查是否春天/反春天
func (s *Scorer) isSpring(game *models.Game) bool {
	if game.Winner == 0 {
		return false
	}

	// 春天：地主获胜且农民没有出过牌
	// 反春天：农民获胜且地主没有出过牌

	landlordPos := game.LandlordPos
	landlordPlayed := false
	farmersPlayed := false

	for _, play := range game.PlayHistory {
		if play.IsPass {
			continue
		}

		if play.PlayerPos == landlordPos {
			landlordPlayed = true
		} else {
			farmersPlayed = true
		}
	}

	if game.Winner == 1 && !farmersPlayed {
		logger.Info("春天：地主获胜且农民未出牌")
		return true
	}

	if game.Winner == 2 && !landlordPlayed {
		logger.Info("反春天：农民获胜且地主未出牌")
		return true
	}

	return false
}

// calculateStrengthMultiplier 根据牌型强度计算额外倍数
func (s *Scorer) calculateStrengthMultiplier(player *models.Player) int {
	// 简单实现：根据剩余手牌数量
	remainingCards := len(player.HandCards)

	// 剩余牌数越少，说明打得越好，给予额外倍数
	if remainingCards <= 5 {
		return 1
	}

	return 0
}

// CalculateRoomScore 计算房间总积分变化
func (s *Scorer) CalculateRoomScore(scores map[string]int) int {
	total := 0
	for _, score := range scores {
		if score > 0 {
			total += score
		}
	}
	return total
}

// GetScoreExplanation 获取计分说明
func (s *Scorer) GetScoreExplanation(game *models.Game, scores map[string]int) map[string]interface{} {
	multiplier := s.calculateMultiplier(game)

	explanation := map[string]interface{}{
		"base_score":    s.baseScore,
		"multiplier":    multiplier,
		"final_score":   s.baseScore * multiplier,
		"winner":        game.Winner,
		"factors":       []string{},
		"player_scores": scores,
	}

	factors := []string{}

	// 记录影响倍数的因素
	bombCount := s.countBombs(game)
	if bombCount > 0 {
		factors = append(factors, fmt.Sprintf("炸弹 %d 个", bombCount))
	}

	if s.hasJokerBomb(game) {
		factors = append(factors, "王炸")
	}

	if s.isSpring(game) {
		if game.Winner == 1 {
			factors = append(factors, "春天")
		} else {
			factors = append(factors, "反春天")
		}
	}

	explanation["factors"] = factors

	return explanation
}

// SetBaseScore 设置基础分数
func (s *Scorer) SetBaseScore(score int) {
	if score > 0 {
		s.baseScore = score
		logger.Info("设置基础分数：%d", score)
	}
}

// GetBaseScore 获取基础分数
func (s *Scorer) GetBaseScore() int {
	return s.baseScore
}
