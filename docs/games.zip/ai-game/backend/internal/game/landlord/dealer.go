package landlord

import (
	"fmt"

	"ai-game/internal/models"
	"ai-game/pkg/logger"
)

// Dealer 发牌器
type Dealer struct {
	deck *CardSet
}

// NewDealer 创建发牌器
func NewDealer() *Dealer {
	return &Dealer{
		deck: NewFullDeck(),
	}
}

// DealCards 发牌给玩家
func (d *Dealer) DealCards(players []*models.Player) error {
	if len(players) != 3 {
		return fmt.Errorf("斗地主必须是3个玩家")
	}

	// 洗牌
	d.deck.Shuffle()
	logger.Info("洗牌完成，共%d张牌", d.deck.Count())

	// 给每个玩家发17张牌
	for i, player := range players {
		cards := d.deck.Deal(17)
		player.HandCards = cards

		// 排序手牌
		handSet := NewCardSet(player.HandCards)
		handSet.SortDesc() // 按点数从大到小排序
		player.HandCards = handSet.Cards

		logger.Debug("玩家%d(%s)发牌完成，手牌：%s", i, player.Nickname, handSet.String())
	}

	// 剩余3张作为底牌
	if d.deck.Count() != 3 {
		return fmt.Errorf("发牌后应该剩余3张底牌，实际剩余%d张", d.deck.Count())
	}

	logger.Info("发牌完成，每人17张，底牌3张")
	return nil
}

// GetHoleCards 获取底牌
func (d *Dealer) GetHoleCards() []models.Card {
	return d.deck.Cards
}

// GiveHoleCardsToLandlord 将底牌给地主
func (d *Dealer) GiveHoleCardsToLandlord(landlord *models.Player) {
	holeCards := d.GetHoleCards()
	landlord.HandCards = append(landlord.HandCards, holeCards...)

	// 重新排序地主手牌
	handSet := NewCardSet(landlord.HandCards)
	handSet.SortDesc()
	landlord.HandCards = handSet.Cards

	logger.Info("地主获得底牌：%s，现有手牌%d张", NewCardSet(holeCards).String(), len(landlord.HandCards))

	// 清空底牌
	d.deck.Cards = []models.Card{}
}

// Reset 重置发牌器
func (d *Dealer) Reset() {
	d.deck = NewFullDeck()
	logger.Debug("发牌器已重置")
}

// ValidateCardCount 验证牌数是否正确
func (d *Dealer) ValidateCardCount(players []*models.Player) error {
	totalCards := 0
	for i, player := range players {
		count := len(player.HandCards)
		totalCards += count
		logger.Debug("玩家%d手牌数：%d", i, count)
	}

	holeCards := len(d.deck.Cards)
	totalCards += holeCards

	if totalCards != 54 {
		return fmt.Errorf("牌数不正确：玩家手牌总数%d + 底牌%d = %d，应该是54张", totalCards-holeCards, holeCards, totalCards)
	}

	logger.Debug("牌数验证通过：总计54张牌")
	return nil
}

// AnalyzeHandStrength 分析手牌强度(用于AI决策)
func (d *Dealer) AnalyzeHandStrength(cards []models.Card) float64 {
	handSet := NewCardSet(cards)
	analysis := handSet.AnalyzeHand()

	score := 0.0

	// 基础分数：每张牌1分
	score += float64(analysis.TotalCards)

	// 大牌分数
	for rank, count := range analysis.RankCounts {
		cardValue := d.getCardValue(rank)
		score += cardValue * float64(count)
	}

	// 牌型分数
	score += float64(len(analysis.Pairs)) * 2   // 对子
	score += float64(len(analysis.Triples)) * 5 // 三张
	score += float64(len(analysis.Bombs)) * 15  // 炸弹

	if analysis.HasJokerBomb {
		score += 25 // 王炸
	}

	// 连续牌型分数
	for _, seq := range analysis.Sequences {
		score += float64(seq.Length) * 1.5 // 顺子
	}

	for _, seq := range analysis.PairSequences {
		score += float64(seq.Length) * 3 // 连对
	}

	for _, seq := range analysis.TripleSequences {
		score += float64(seq.Length) * 6 // 飞机
	}

	// 单张惩罚（单张太多不好）
	singlePenalty := float64(len(analysis.Singles)) * 0.5
	score -= singlePenalty

	return score
}

// getCardValue 获取单张牌的价值
func (d *Dealer) getCardValue(rank int) float64 {
	switch rank {
	case 17: // 大王
		return 15.0
	case 16: // 小王
		return 12.0
	case 15: // 2
		return 10.0
	case 14: // A
		return 8.0
	case 13: // K
		return 6.0
	case 12: // Q
		return 4.0
	case 11: // J
		return 3.0
	case 10: // 10
		return 2.5
	default: // 3-9
		return 1.0
	}
}

// SuggestBidding 建议是否叫地主(用于AI)
func (d *Dealer) SuggestBidding(cards []models.Card, holeCards []models.Card) bool {
	// 分析当前手牌强度
	currentStrength := d.AnalyzeHandStrength(cards)

	// 如果提供了底牌信息，分析加上底牌后的强度
	if len(holeCards) > 0 {
		allCards := append(cards, holeCards...)
		totalStrength := d.AnalyzeHandStrength(allCards)

		// 如果加上底牌后强度提升明显，更倾向于叫地主
		if totalStrength > currentStrength*1.3 {
			currentStrength = totalStrength
		}
	}

	// 强度阈值：根据17张牌的平均强度来判断
	threshold := 35.0

	logger.Debug("手牌强度分析：%.2f，阈值：%.2f", currentStrength, threshold)

	return currentStrength >= threshold
}

// GetOptimalPlay 获取最佳出牌建议(简单AI逻辑)
func (d *Dealer) GetOptimalPlay(handCards []models.Card, lastPlay *models.PlayCards) []models.Card {
	rules := NewRuleEngine()

	// 获取所有可能的出牌
	validPlays := rules.GetValidPlays(handCards, lastPlay)

	if len(validPlays) == 0 {
		return []models.Card{} // 无牌可出
	}

	// 简单策略：选择第一个有效出牌
	return validPlays[0]
}
