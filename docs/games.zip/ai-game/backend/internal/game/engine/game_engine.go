package engine

import (
	"fmt"
	"sync"
	"time"

	"ai-game/internal/game/landlord"
	"ai-game/internal/models"
	"ai-game/pkg/constants"
	"ai-game/pkg/logger"
)

// GameEngine 游戏引擎
type GameEngine struct {
	games map[string]*landlord.Game // 活跃游戏列表
	mutex sync.RWMutex              // 读写锁
}

// NewGameEngine 创建游戏引擎
func NewGameEngine() *GameEngine {
	return &GameEngine{
		games: make(map[string]*landlord.Game),
	}
}

// CreateGame 创建新游戏
func (ge *GameEngine) CreateGame(roomID string, players []models.Player) (*landlord.Game, error) {
	if len(players) != 3 {
		return nil, fmt.Errorf("斗地主需要3个玩家")
	}

	ge.mutex.Lock()
	defer ge.mutex.Unlock()

	// 检查玩家是否已经在其他游戏中
	for _, player := range players {
		if ge.isPlayerInGame(player.UserID) {
			return nil, fmt.Errorf("玩家 %s 已在其他游戏中", player.Nickname)
		}
	}

	// 创建新游戏
	game := landlord.NewGame(roomID, players)
	ge.games[game.ID] = game

	logger.Info("创建游戏成功：%s，房间：%s", game.ID, roomID)
	return game, nil
}

// GetGame 获取游戏
func (ge *GameEngine) GetGame(gameID string) (*landlord.Game, error) {
	ge.mutex.RLock()
	defer ge.mutex.RUnlock()

	game, exists := ge.games[gameID]
	if !exists {
		return nil, fmt.Errorf("游戏不存在：%s", gameID)
	}

	return game, nil
}

// StartGame 开始游戏
func (ge *GameEngine) StartGame(gameID string) error {
	game, err := ge.GetGame(gameID)
	if err != nil {
		return err
	}

	return game.Start()
}

// BidLandlord 叫地主
func (ge *GameEngine) BidLandlord(gameID string, playerPos int, bid bool) error {
	game, err := ge.GetGame(gameID)
	if err != nil {
		return err
	}

	return game.BidLandlord(playerPos, bid)
}

// PlayCards 出牌
func (ge *GameEngine) PlayCards(gameID string, playerPos int, cards []models.Card) error {
	game, err := ge.GetGame(gameID)
	if err != nil {
		return err
	}

	return game.PlayCards(playerPos, cards)
}

// Pass 过牌
func (ge *GameEngine) Pass(gameID string, playerPos int) error {
	game, err := ge.GetGame(gameID)
	if err != nil {
		return err
	}

	return game.Pass(playerPos)
}

// GetGameState 获取游戏状态
func (ge *GameEngine) GetGameState(gameID string) (map[string]interface{}, error) {
	game, err := ge.GetGame(gameID)
	if err != nil {
		return nil, err
	}

	return game.GetGameState(), nil
}

// GetPlayerHand 获取玩家手牌
func (ge *GameEngine) GetPlayerHand(gameID string, userID string) ([]models.Card, error) {
	game, err := ge.GetGame(gameID)
	if err != nil {
		return nil, err
	}

	for _, player := range game.Players {
		if player.UserID == userID {
			return player.HandCards, nil
		}
	}

	return nil, fmt.Errorf("玩家不在游戏中")
}

// RemoveGame 移除游戏
func (ge *GameEngine) RemoveGame(gameID string) {
	ge.mutex.Lock()
	defer ge.mutex.Unlock()

	if game, exists := ge.games[gameID]; exists {
		delete(ge.games, gameID)
		logger.Info("移除游戏：%s，房间：%s", gameID, game.RoomID)
	}
}

// GetActiveGames 获取活跃游戏数量
func (ge *GameEngine) GetActiveGames() int {
	ge.mutex.RLock()
	defer ge.mutex.RUnlock()

	return len(ge.games)
}

// GetGamesByRoom 根据房间ID获取游戏
func (ge *GameEngine) GetGamesByRoom(roomID string) []*landlord.Game {
	ge.mutex.RLock()
	defer ge.mutex.RUnlock()

	var games []*landlord.Game
	for _, game := range ge.games {
		if game.RoomID == roomID {
			games = append(games, game)
		}
	}

	return games
}

// CleanupFinishedGames 清理已结束的游戏
func (ge *GameEngine) CleanupFinishedGames() {
	ge.mutex.Lock()
	defer ge.mutex.Unlock()

	now := time.Now()
	toRemove := []string{}

	for gameID, game := range ge.games {
		// 清理超过1小时的已结束游戏
		if game.IsFinished() && now.Sub(game.EndAt) > time.Hour {
			toRemove = append(toRemove, gameID)
		}
		// 清理超过2小时的未完成游戏
		if !game.IsFinished() && now.Sub(game.StartAt) > 2*time.Hour {
			toRemove = append(toRemove, gameID)
		}
	}

	for _, gameID := range toRemove {
		delete(ge.games, gameID)
		logger.Info("清理过期游戏：%s", gameID)
	}

	if len(toRemove) > 0 {
		logger.Info("清理完成，移除%d个过期游戏", len(toRemove))
	}
}

// GetGameStatistics 获取游戏统计
func (ge *GameEngine) GetGameStatistics() map[string]interface{} {
	ge.mutex.RLock()
	defer ge.mutex.RUnlock()

	stats := map[string]interface{}{
		"total_games":    len(ge.games),
		"waiting_games":  0,
		"bidding_games":  0,
		"playing_games":  0,
		"finished_games": 0,
	}

	for _, game := range ge.games {
		switch game.Phase {
		case constants.GamePhaseWaiting:
			stats["waiting_games"] = stats["waiting_games"].(int) + 1
		case constants.GamePhaseBidding:
			stats["bidding_games"] = stats["bidding_games"].(int) + 1
		case constants.GamePhasePlaying:
			stats["playing_games"] = stats["playing_games"].(int) + 1
		case constants.GamePhaseFinished:
			stats["finished_games"] = stats["finished_games"].(int) + 1
		}
	}

	return stats
}

// ValidateGameAction 验证游戏操作是否合法
func (ge *GameEngine) ValidateGameAction(gameID, userID string) error {
	game, err := ge.GetGame(gameID)
	if err != nil {
		return err
	}

	// 检查用户是否在游戏中
	playerFound := false
	for _, player := range game.Players {
		if player.UserID == userID {
			playerFound = true
			break
		}
	}

	if !playerFound {
		return fmt.Errorf("用户不在游戏中")
	}

	return nil
}

// GetPlayerPosition 获取玩家在游戏中的位置
func (ge *GameEngine) GetPlayerPosition(gameID, userID string) (int, error) {
	game, err := ge.GetGame(gameID)
	if err != nil {
		return -1, err
	}

	for i, player := range game.Players {
		if player.UserID == userID {
			return i, nil
		}
	}

	return -1, fmt.Errorf("玩家不在游戏中")
}

// 私有方法

// isPlayerInGame 检查玩家是否已在其他游戏中
func (ge *GameEngine) isPlayerInGame(userID string) bool {
	for _, game := range ge.games {
		if game.IsFinished() {
			continue
		}

		for _, player := range game.Players {
			if player.UserID == userID {
				return true
			}
		}
	}
	return false
}

// StartCleanupRoutine 启动清理协程
func (ge *GameEngine) StartCleanupRoutine() {
	go func() {
		ticker := time.NewTicker(10 * time.Minute) // 每10分钟清理一次
		defer ticker.Stop()

		for {
			select {
			case <-ticker.C:
				ge.CleanupFinishedGames()
			}
		}
	}()

	logger.Info("游戏引擎清理协程已启动")
}
