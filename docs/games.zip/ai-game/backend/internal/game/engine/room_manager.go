package engine

import (
	"fmt"
	"sync"
	"time"

	"ai-game/internal/models"
	"ai-game/internal/utils"
	"ai-game/pkg/constants"
	"ai-game/pkg/logger"
)

// RoomManager 房间管理器
type RoomManager struct {
	rooms      map[string]*models.Room // 房间列表
	gameEngine *GameEngine             // 游戏引擎
	mutex      sync.RWMutex            // 读写锁
}

// NewRoomManager 创建房间管理器
func NewRoomManager(gameEngine *GameEngine) *RoomManager {
	return &RoomManager{
		rooms:      make(map[string]*models.Room),
		gameEngine: gameEngine,
	}
}

// CreateRoom 创建房间
func (rm *RoomManager) CreateRoom(ownerID string, req *models.CreateRoomRequest) (*models.Room, error) {
	rm.mutex.Lock()
	defer rm.mutex.Unlock()

	// 创建房间
	room := &models.Room{
		ID:          utils.GenerateRoomID(),
		Name:        req.Name,
		Description: req.Description,
		Capacity:    constants.DefaultRoomCapacity,
		Password:    req.Password,
		IsPrivate:   req.Password != "",
		OwnerID:     ownerID,
		Players:     []models.Player{},
		Status:      0, // 等待中
		CreateAt:    time.Now(),
		UpdateAt:    time.Now(),
		Config:      req.Config,
	}

	// 设置默认配置
	if room.Config.GameTimeout == 0 {
		room.Config = models.DefaultRoomConfig()
	}

	rm.rooms[room.ID] = room

	logger.Info("创建房间：%s (%s)，房主：%s", room.ID, room.Name, ownerID)
	return room, nil
}

// GetRoom 获取房间
func (rm *RoomManager) GetRoom(roomID string) (*models.Room, error) {
	rm.mutex.RLock()
	defer rm.mutex.RUnlock()

	room, exists := rm.rooms[roomID]
	if !exists {
		return nil, fmt.Errorf("房间不存在")
	}

	return room, nil
}

// JoinRoom 加入房间
func (rm *RoomManager) JoinRoom(roomID, userID string, player models.Player) error {
	rm.mutex.Lock()
	defer rm.mutex.Unlock()

	room, exists := rm.rooms[roomID]
	if !exists {
		return fmt.Errorf("房间不存在")
	}

	// 检查房间状态
	if room.Status != 0 {
		return fmt.Errorf("房间正在游戏中，无法加入")
	}

	// 检查房间是否已满
	if room.IsFull() {
		return fmt.Errorf("房间已满")
	}

	// 检查用户是否已在房间中
	if room.HasPlayer(userID) {
		return fmt.Errorf("您已在房间中")
	}

	// 添加玩家到房间
	if !room.AddPlayer(player) {
		return fmt.Errorf("加入房间失败")
	}

	logger.Info("玩家 %s 加入房间 %s，位置：%d", player.Nickname, roomID, player.Position)
	return nil
}

// LeaveRoom 离开房间
func (rm *RoomManager) LeaveRoom(roomID, userID string) error {
	rm.mutex.Lock()
	defer rm.mutex.Unlock()

	room, exists := rm.rooms[roomID]
	if !exists {
		return fmt.Errorf("房间不存在")
	}

	// 检查用户是否在房间中
	if !room.HasPlayer(userID) {
		return fmt.Errorf("您不在房间中")
	}

	// 如果房间正在游戏中，不允许离开
	if room.IsInGame() {
		return fmt.Errorf("游戏进行中，无法离开房间")
	}

	// 移除玩家
	player := room.GetPlayerByUserID(userID)
	if player == nil {
		return fmt.Errorf("玩家信息不存在")
	}

	room.RemovePlayer(userID)

	logger.Info("玩家 %s 离开房间 %s", player.Nickname, roomID)

	// 如果房主离开，转移房主权限或关闭房间
	if room.IsOwner(userID) {
		if room.IsEmpty() {
			// 房间为空，删除房间
			delete(rm.rooms, roomID)
			logger.Info("房间 %s 已删除（房主离开且房间为空）", roomID)
		} else {
			// 转移房主权限
			room.TransferOwnership()
			logger.Info("房间 %s 房主权限转移给 %s", roomID, room.OwnerID)
		}
	}

	return nil
}

// SetPlayerReady 设置玩家准备状态
func (rm *RoomManager) SetPlayerReady(roomID, userID string, ready bool) error {
	rm.mutex.Lock()
	defer rm.mutex.Unlock()

	room, exists := rm.rooms[roomID]
	if !exists {
		return fmt.Errorf("房间不存在")
	}

	player := room.GetPlayerByUserID(userID)
	if player == nil {
		return fmt.Errorf("您不在房间中")
	}

	player.IsReady = ready
	room.UpdateAt = time.Now()

	logger.Info("玩家 %s 在房间 %s 设置准备状态：%v", player.Nickname, roomID, ready)

	// 检查是否可以开始游戏
	if ready && room.CanStartGame() {
		return rm.startGame(room)
	}

	return nil
}

// GetRoomList 获取房间列表
func (rm *RoomManager) GetRoomList(page, size int) ([]*models.RoomListResponse, int, error) {
	rm.mutex.RLock()
	defer rm.mutex.RUnlock()

	// 过滤公开房间
	var publicRooms []*models.Room
	for _, room := range rm.rooms {
		if !room.IsPrivate {
			publicRooms = append(publicRooms, room)
		}
	}

	total := len(publicRooms)

	// 分页
	start := (page - 1) * size
	end := start + size
	if start >= total {
		return []*models.RoomListResponse{}, total, nil
	}
	if end > total {
		end = total
	}

	// 转换为响应格式
	result := make([]*models.RoomListResponse, end-start)
	for i := start; i < end; i++ {
		room := publicRooms[i]
		ownerName := rm.getOwnerName(room)
		result[i-start] = room.ToListResponse(ownerName)
	}

	return result, total, nil
}

// StartGameManually 手动开始游戏（房主操作）
func (rm *RoomManager) StartGameManually(roomID, userID string) error {
	rm.mutex.Lock()
	defer rm.mutex.Unlock()

	room, exists := rm.rooms[roomID]
	if !exists {
		return fmt.Errorf("房间不存在")
	}

	// 检查是否为房主
	if !room.IsOwner(userID) {
		return fmt.Errorf("只有房主可以开始游戏")
	}

	// 检查房间状态
	if room.Status != 0 {
		return fmt.Errorf("房间已在游戏中")
	}

	// 检查玩家数量
	if room.PlayerCount() < room.Capacity {
		return fmt.Errorf("玩家数量不足")
	}

	return rm.startGame(room)
}

// GetRoomPlayers 获取房间玩家列表
func (rm *RoomManager) GetRoomPlayers(roomID string) ([]models.Player, error) {
	room, err := rm.GetRoom(roomID)
	if err != nil {
		return nil, err
	}

	return room.Players, nil
}

// RemoveRoom 删除房间
func (rm *RoomManager) RemoveRoom(roomID string) {
	rm.mutex.Lock()
	defer rm.mutex.Unlock()

	if room, exists := rm.rooms[roomID]; exists {
		delete(rm.rooms, roomID)
		logger.Info("删除房间：%s (%s)", roomID, room.Name)
	}
}

// GetRoomStatistics 获取房间统计
func (rm *RoomManager) GetRoomStatistics() map[string]interface{} {
	rm.mutex.RLock()
	defer rm.mutex.RUnlock()

	stats := map[string]interface{}{
		"total_rooms":   len(rm.rooms),
		"waiting_rooms": 0,
		"playing_rooms": 0,
		"private_rooms": 0,
		"public_rooms":  0,
		"total_players": 0,
	}

	for _, room := range rm.rooms {
		stats["total_players"] = stats["total_players"].(int) + room.PlayerCount()

		if room.IsPrivate {
			stats["private_rooms"] = stats["private_rooms"].(int) + 1
		} else {
			stats["public_rooms"] = stats["public_rooms"].(int) + 1
		}

		if room.Status == 0 {
			stats["waiting_rooms"] = stats["waiting_rooms"].(int) + 1
		} else {
			stats["playing_rooms"] = stats["playing_rooms"].(int) + 1
		}
	}

	return stats
}

// CleanupEmptyRooms 清理空房间
func (rm *RoomManager) CleanupEmptyRooms() {
	rm.mutex.Lock()
	defer rm.mutex.Unlock()

	now := time.Now()
	toRemove := []string{}

	for roomID, room := range rm.rooms {
		// 清理超过30分钟的空房间
		if room.IsEmpty() && now.Sub(room.UpdateAt) > 30*time.Minute {
			toRemove = append(toRemove, roomID)
		}
		// 清理超过2小时的非游戏房间
		if room.Status == 0 && now.Sub(room.CreateAt) > 2*time.Hour {
			toRemove = append(toRemove, roomID)
		}
	}

	for _, roomID := range toRemove {
		delete(rm.rooms, roomID)
		logger.Info("清理空房间：%s", roomID)
	}

	if len(toRemove) > 0 {
		logger.Info("清理完成，移除%d个空房间", len(toRemove))
	}
}

// 私有方法

// startGame 开始游戏
func (rm *RoomManager) startGame(room *models.Room) error {
	// 创建游戏
	game, err := rm.gameEngine.CreateGame(room.ID, room.Players)
	if err != nil {
		return fmt.Errorf("创建游戏失败: %v", err)
	}

	// 开始游戏
	if err := rm.gameEngine.StartGame(game.ID); err != nil {
		rm.gameEngine.RemoveGame(game.ID)
		return fmt.Errorf("开始游戏失败: %v", err)
	}

	// 更新房间状态
	room.CurrentGame = game.Game
	room.Status = 1 // 游戏中
	room.UpdateAt = time.Now()

	logger.Info("房间 %s 开始游戏：%s", room.ID, game.ID)
	return nil
}

// getOwnerName 获取房主名称
func (rm *RoomManager) getOwnerName(room *models.Room) string {
	for _, player := range room.Players {
		if player.UserID == room.OwnerID {
			return player.Nickname
		}
	}
	return "未知"
}

// StartCleanupRoutine 启动清理协程
func (rm *RoomManager) StartCleanupRoutine() {
	go func() {
		ticker := time.NewTicker(15 * time.Minute) // 每15分钟清理一次
		defer ticker.Stop()

		for {
			select {
			case <-ticker.C:
				rm.CleanupEmptyRooms()
			}
		}
	}()

	logger.Info("房间管理器清理协程已启动")
}
