package handlers

import (
	"strconv"

	"ai-game/internal/models"
	"ai-game/internal/services"
	"ai-game/pkg/logger"
	"ai-game/pkg/utils"

	"github.com/gin-gonic/gin"
)

// GameHandler 游戏处理器
type GameHandler struct {
	gameService services.GameService
	userService services.UserService
}

// NewGameHandler 创建游戏处理器实例
func NewGameHandler(gameService services.GameService, userService services.UserService) *GameHandler {
	return &GameHandler{
		gameService: gameService,
		userService: userService,
	}
}

// GetRoomList 获取房间列表
func (h *GameHandler) GetRoomList(c *gin.Context) {
	logger.Debug("获取房间列表")

	// 获取分页参数
	page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
	limit, _ := strconv.Atoi(c.DefaultQuery("limit", "20"))

	if page < 1 {
		page = 1
	}
	if limit < 1 || limit > 100 {
		limit = 20
	}

	rooms, total, err := h.gameService.GetRoomList(page, limit)
	if err != nil {
		logger.Error("获取房间列表失败: %v", err)
		utils.Error(c, err)
		return
	}

	utils.Success(c, gin.H{
		"rooms": rooms,
		"total": total,
		"page":  page,
		"limit": limit,
	})
}

// CreateRoom 创建房间
func (h *GameHandler) CreateRoom(c *gin.Context) {
	logger.Debug("创建房间")

	// 获取当前用户
	userID, exists := c.Get("user_id")
	if !exists {
		logger.Error("获取用户ID失败")
		utils.Unauthorized(c, "用户未认证")
		return
	}

	var req struct {
		Name       string `json:"name" binding:"required,min=2,max=20"`
		MaxPlayers int    `json:"max_players" binding:"required,min=2,max=4"`
		Settings   struct {
			BaseScore int  `json:"base_score" binding:"required,min=1"`
			MaxScore  int  `json:"max_score"`
			TimeLimit int  `json:"time_limit"`
			AIPlayers bool `json:"ai_players"`
		} `json:"settings"`
	}

	if err := c.ShouldBindJSON(&req); err != nil {
		logger.Error("参数绑定失败: %v", err)
		utils.BadRequest(c, "参数格式错误")
		return
	}

	// 创建房间
	room := &models.Room{
		Name:      req.Name,
		Capacity:  req.MaxPlayers,
		OwnerID:   userID.(string),
		IsPrivate: false,
		Config: models.RoomConfig{
			ScoreMultiple: req.Settings.BaseScore,
			AllowAI:       req.Settings.AIPlayers,
			GameTimeout:   req.Settings.TimeLimit * 60, // 转换为秒
		},
	}

	createdRoom, err := h.gameService.CreateRoom(room)
	if err != nil {
		logger.Error("创建房间失败: %v", err)
		utils.Error(c, err)
		return
	}

	utils.SuccessWithMessage(c, "房间创建成功", createdRoom)
}

// JoinRoom 加入房间
func (h *GameHandler) JoinRoom(c *gin.Context) {
	roomID := c.Param("id")
	logger.Debug("加入房间: %s", roomID)

	// 获取当前用户
	userID, exists := c.Get("user_id")
	if !exists {
		logger.Error("获取用户ID失败")
		utils.Unauthorized(c, "用户未认证")
		return
	}

	room, err := h.gameService.JoinRoom(roomID, userID.(string))
	if err != nil {
		logger.Error("加入房间失败: %v", err)
		utils.Error(c, err)
		return
	}

	utils.SuccessWithMessage(c, "加入房间成功", room)
}

// LeaveRoom 离开房间
func (h *GameHandler) LeaveRoom(c *gin.Context) {
	roomID := c.Param("id")
	logger.Debug("离开房间: %s", roomID)

	// 获取当前用户
	userID, exists := c.Get("user_id")
	if !exists {
		logger.Error("获取用户ID失败")
		utils.Unauthorized(c, "用户未认证")
		return
	}

	err := h.gameService.LeaveRoom(roomID, userID.(string))
	if err != nil {
		logger.Error("离开房间失败: %v", err)
		utils.Error(c, err)
		return
	}

	utils.SuccessWithMessage(c, "离开房间成功", nil)
}

// GetGameState 获取游戏状态
func (h *GameHandler) GetGameState(c *gin.Context) {
	roomID := c.Param("id")
	logger.Debug("获取游戏状态: %s", roomID)

	// 获取当前用户
	userID, exists := c.Get("user_id")
	if !exists {
		logger.Error("获取用户ID失败")
		utils.Unauthorized(c, "用户未认证")
		return
	}

	gameState, err := h.gameService.GetGameState(roomID, userID.(string))
	if err != nil {
		logger.Error("获取游戏状态失败: %v", err)
		utils.Error(c, err)
		return
	}

	utils.Success(c, gameState)
}

// MakeBid 叫地主
func (h *GameHandler) MakeBid(c *gin.Context) {
	roomID := c.Param("id")
	logger.Debug("叫地主: %s", roomID)

	// 获取当前用户
	userID, exists := c.Get("user_id")
	if !exists {
		logger.Error("获取用户ID失败")
		utils.Unauthorized(c, "用户未认证")
		return
	}

	var req struct {
		Bid bool `json:"bid"`
	}

	if err := c.ShouldBindJSON(&req); err != nil {
		logger.Error("参数绑定失败: %v", err)
		utils.BadRequest(c, "参数格式错误")
		return
	}

	gameState, err := h.gameService.MakeBid(roomID, userID.(string), req.Bid)
	if err != nil {
		logger.Error("叫地主失败: %v", err)
		utils.Error(c, err)
		return
	}

	utils.Success(c, gameState)
}

// PlayCards 出牌
func (h *GameHandler) PlayCards(c *gin.Context) {
	roomID := c.Param("id")
	logger.Debug("出牌: %s", roomID)

	// 获取当前用户
	userID, exists := c.Get("user_id")
	if !exists {
		logger.Error("获取用户ID失败")
		utils.Unauthorized(c, "用户未认证")
		return
	}

	var req struct {
		Cards []int `json:"cards" binding:"required"`
	}

	if err := c.ShouldBindJSON(&req); err != nil {
		logger.Error("参数绑定失败: %v", err)
		utils.BadRequest(c, "参数格式错误")
		return
	}

	gameState, err := h.gameService.PlayCards(roomID, userID.(string), req.Cards)
	if err != nil {
		logger.Error("出牌失败: %v", err)
		utils.Error(c, err)
		return
	}

	utils.Success(c, gameState)
}

// Pass 不出牌(过)
func (h *GameHandler) Pass(c *gin.Context) {
	roomID := c.Param("id")
	logger.Debug("过牌: %s", roomID)

	// 获取当前用户
	userID, exists := c.Get("user_id")
	if !exists {
		logger.Error("获取用户ID失败")
		utils.Unauthorized(c, "用户未认证")
		return
	}

	gameState, err := h.gameService.Pass(roomID, userID.(string))
	if err != nil {
		logger.Error("过牌失败: %v", err)
		utils.Error(c, err)
		return
	}

	utils.Success(c, gameState)
}

// StartGame 开始游戏
func (h *GameHandler) StartGame(c *gin.Context) {
	roomID := c.Param("id")
	logger.Debug("开始游戏: %s", roomID)

	// 获取当前用户
	_, exists := c.Get("user_id")
	if !exists {
		logger.Error("获取用户ID失败")
		utils.Unauthorized(c, "用户未认证")
		return
	}

	gameState, err := h.gameService.StartGame(roomID)
	if err != nil {
		logger.Error("开始游戏失败: %v", err)
		utils.Error(c, err)
		return
	}

	utils.SuccessWithMessage(c, "游戏开始成功", gameState)
}

// SendChatMessage 发送聊天消息
func (h *GameHandler) SendChatMessage(c *gin.Context) {
	roomID := c.Param("id")
	logger.Debug("发送聊天消息: %s", roomID)

	// 获取当前用户
	userID, exists := c.Get("user_id")
	if !exists {
		logger.Error("获取用户ID失败")
		utils.Unauthorized(c, "用户未认证")
		return
	}

	var req struct {
		Message string `json:"message" binding:"required,min=1,max=200"`
	}

	if err := c.ShouldBindJSON(&req); err != nil {
		logger.Error("参数绑定失败: %v", err)
		utils.BadRequest(c, "参数格式错误")
		return
	}

	// TODO: 实现聊天消息存储和广播
	logger.Info("用户 %s 在房间 %s 发送消息: %s", userID, roomID, req.Message)

	utils.SuccessWithMessage(c, "消息发送成功", nil)
}

// GetChatMessages 获取聊天记录
func (h *GameHandler) GetChatMessages(c *gin.Context) {
	roomID := c.Param("id")
	logger.Debug("获取聊天记录: %s", roomID)

	// 获取当前用户
	_, exists := c.Get("user_id")
	if !exists {
		logger.Error("获取用户ID失败")
		utils.Unauthorized(c, "用户未认证")
		return
	}

	// TODO: 实现聊天记录查询
	// 暂时返回空数组
	messages := []interface{}{}

	utils.Success(c, messages)
}
