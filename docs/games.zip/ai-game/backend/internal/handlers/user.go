package handlers

import (
	"strconv"

	"ai-game/internal/models"
	"ai-game/internal/services"
	"ai-game/internal/utils"
	"ai-game/pkg/constants"
	"ai-game/pkg/logger"

	"github.com/gin-gonic/gin"
)

// UserHandler 用户处理器
type UserHandler struct {
	userService services.UserService
}

// NewUserHandler 创建用户处理器实例
func NewUserHandler(userService services.UserService) *UserHandler {
	return &UserHandler{
		userService: userService,
	}
}

// Register 用户注册
// @Summary 用户注册
// @Description 用户注册接口
// @Tags 用户管理
// @Accept json
// @Produce json
// @Param request body models.UserRegisterRequest true "注册请求"
// @Success 200 {object} utils.Response{data=models.UserResponse}
// @Failure 400 {object} utils.Response
// @Router /api/auth/register [post]
func (h *UserHandler) Register(c *gin.Context) {
	var req models.UserRegisterRequest

	// 绑定请求参数
	if err := c.ShouldBindJSON(&req); err != nil {
		logger.Warn("注册请求参数错误: %v", err)
		utils.BadRequest(c, "请求参数格式错误")
		return
	}

	// 调用服务层
	user, err := h.userService.Register(&req)
	if err != nil {
		logger.Error("用户注册失败: %v", err)
		utils.Error(c, err)
		return
	}

	utils.SuccessWithMessage(c, "注册成功", user)
}

// Login 用户登录
// @Summary 用户登录
// @Description 用户登录接口
// @Tags 用户管理
// @Accept json
// @Produce json
// @Param request body models.UserLoginRequest true "登录请求"
// @Success 200 {object} utils.Response{data=map[string]interface{}}
// @Failure 400 {object} utils.Response
// @Router /api/auth/login [post]
func (h *UserHandler) Login(c *gin.Context) {
	var req models.UserLoginRequest

	// 绑定请求参数
	if err := c.ShouldBindJSON(&req); err != nil {
		logger.Warn("登录请求参数错误: %v", err)
		utils.BadRequest(c, "请求参数格式错误")
		return
	}

	// 调用服务层
	user, token, err := h.userService.Login(&req)
	if err != nil {
		logger.Error("用户登录失败: %v", err)
		utils.Error(c, err)
		return
	}

	// 返回用户信息和令牌
	data := map[string]interface{}{
		"user":  user,
		"token": token,
	}

	utils.SuccessWithMessage(c, "登录成功", data)
}

// GetProfile 获取用户资料
// @Summary 获取用户资料
// @Description 获取当前用户的个人资料
// @Tags 用户管理
// @Produce json
// @Security ApiKeyAuth
// @Success 200 {object} utils.Response{data=models.UserResponse}
// @Failure 401 {object} utils.Response
// @Router /api/user/profile [get]
func (h *UserHandler) GetProfile(c *gin.Context) {
	userID := h.getUserID(c)
	if userID == "" {
		utils.Unauthorized(c, "未授权访问")
		return
	}

	user, err := h.userService.GetProfile(userID)
	if err != nil {
		logger.Error("获取用户资料失败: %v", err)
		utils.Error(c, err)
		return
	}

	utils.Success(c, user)
}

// UpdateProfile 更新用户资料
// @Summary 更新用户资料
// @Description 更新当前用户的个人资料
// @Tags 用户管理
// @Accept json
// @Produce json
// @Security ApiKeyAuth
// @Param request body models.UserProfileRequest true "更新请求"
// @Success 200 {object} utils.Response{data=models.UserResponse}
// @Failure 400 {object} utils.Response
// @Router /api/user/profile [put]
func (h *UserHandler) UpdateProfile(c *gin.Context) {
	userID := h.getUserID(c)
	if userID == "" {
		utils.Unauthorized(c, "未授权访问")
		return
	}

	var req models.UserProfileRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		logger.Warn("更新资料请求参数错误: %v", err)
		utils.BadRequest(c, "请求参数格式错误")
		return
	}

	user, err := h.userService.UpdateProfile(userID, &req)
	if err != nil {
		logger.Error("更新用户资料失败: %v", err)
		utils.Error(c, err)
		return
	}

	utils.SuccessWithMessage(c, "资料更新成功", user)
}

// GetUserList 获取用户列表
// @Summary 获取用户列表
// @Description 分页获取用户列表(管理员功能)
// @Tags 用户管理
// @Produce json
// @Security ApiKeyAuth
// @Param page query int false "页码" default(1)
// @Param size query int false "每页数量" default(10)
// @Success 200 {object} utils.PageResponse{data=[]models.UserResponse}
// @Failure 400 {object} utils.Response
// @Router /api/admin/users [get]
func (h *UserHandler) GetUserList(c *gin.Context) {
	// 获取分页参数
	page, size := utils.GetPaginationFromQuery(c)

	// 调用服务层
	users, total, err := h.userService.GetUserList(page, size)
	if err != nil {
		logger.Error("获取用户列表失败: %v", err)
		utils.Error(c, err)
		return
	}

	// 构造分页信息
	pageInfo := utils.NewPageInfo(page, size, total)
	utils.PageSuccess(c, users, pageInfo)
}

// GetTopPlayers 获取积分排行榜
// @Summary 获取积分排行榜
// @Description 获取积分最高的玩家排行榜
// @Tags 用户管理
// @Produce json
// @Param limit query int false "返回数量" default(10)
// @Success 200 {object} utils.Response{data=[]models.UserResponse}
// @Failure 400 {object} utils.Response
// @Router /api/users/ranking [get]
func (h *UserHandler) GetTopPlayers(c *gin.Context) {
	limitStr := c.DefaultQuery("limit", "10")
	limit, err := strconv.Atoi(limitStr)
	if err != nil || limit <= 0 || limit > 100 {
		limit = 10
	}

	users, err := h.userService.GetTopPlayers(limit)
	if err != nil {
		logger.Error("获取排行榜失败: %v", err)
		utils.Error(c, err)
		return
	}

	utils.Success(c, users)
}

// SearchUsers 搜索用户
// @Summary 搜索用户
// @Description 根据昵称搜索用户
// @Tags 用户管理
// @Produce json
// @Param nickname query string true "昵称关键词"
// @Param page query int false "页码" default(1)
// @Param size query int false "每页数量" default(10)
// @Success 200 {object} utils.PageResponse{data=[]models.UserResponse}
// @Failure 400 {object} utils.Response
// @Router /api/users/search [get]
func (h *UserHandler) SearchUsers(c *gin.Context) {
	nickname := c.Query("nickname")
	if nickname == "" {
		utils.BadRequest(c, "搜索关键词不能为空")
		return
	}

	// 获取分页参数
	page, size := utils.GetPaginationFromQuery(c)

	// 调用服务层
	users, total, err := h.userService.SearchUsers(nickname, page, size)
	if err != nil {
		logger.Error("搜索用户失败: %v", err)
		utils.Error(c, err)
		return
	}

	// 构造分页信息
	pageInfo := utils.NewPageInfo(page, size, total)
	utils.PageSuccess(c, users, pageInfo)
}

// DeleteUser 删除用户
// @Summary 删除用户
// @Description 删除指定用户(管理员功能)
// @Tags 用户管理
// @Produce json
// @Security ApiKeyAuth
// @Param id path string true "用户ID"
// @Success 200 {object} utils.Response
// @Failure 400 {object} utils.Response
// @Router /api/admin/users/{id} [delete]
func (h *UserHandler) DeleteUser(c *gin.Context) {
	userID := c.Param("id")
	if userID == "" {
		utils.BadRequest(c, "用户ID不能为空")
		return
	}

	if err := h.userService.DeleteUser(userID); err != nil {
		logger.Error("删除用户失败: %v", err)
		utils.Error(c, err)
		return
	}

	utils.SuccessWithMessage(c, "用户删除成功", nil)
}

// Logout 用户登出
// @Summary 用户登出
// @Description 用户登出接口
// @Tags 用户管理
// @Produce json
// @Security ApiKeyAuth
// @Success 200 {object} utils.Response
// @Router /api/auth/logout [post]
func (h *UserHandler) Logout(c *gin.Context) {
	userID := h.getUserID(c)
	if userID == "" {
		utils.Unauthorized(c, "未授权访问")
		return
	}

	// 更新用户状态为离线
	if err := h.userService.UpdateUserStatus(userID, constants.UserStatusOffline); err != nil {
		logger.Error("更新用户状态失败: %v", err)
		// 即使状态更新失败，也返回成功，因为客户端已经登出
	}

	utils.SuccessWithMessage(c, "登出成功", nil)
}

// GetUserInfo 获取指定用户信息
// @Summary 获取用户信息
// @Description 获取指定用户的公开信息
// @Tags 用户管理
// @Produce json
// @Param id path string true "用户ID"
// @Success 200 {object} utils.Response{data=models.UserResponse}
// @Failure 404 {object} utils.Response
// @Router /api/users/{id} [get]
func (h *UserHandler) GetUserInfo(c *gin.Context) {
	userID := c.Param("id")
	if userID == "" {
		utils.BadRequest(c, "用户ID不能为空")
		return
	}

	user, err := h.userService.GetProfile(userID)
	if err != nil {
		utils.Error(c, err)
		return
	}

	utils.Success(c, user)
}

// 辅助方法

// getUserID 从上下文获取用户ID
func (h *UserHandler) getUserID(c *gin.Context) string {
	if userID, exists := c.Get("user_id"); exists {
		if id, ok := userID.(string); ok {
			return id
		}
	}
	return ""
}

// getCurrentUser 从上下文获取当前用户
func (h *UserHandler) getCurrentUser(c *gin.Context) *models.User {
	if user, exists := c.Get("user"); exists {
		if u, ok := user.(*models.User); ok {
			return u
		}
	}
	return nil
}

// isAdmin 检查是否为管理员(简单实现，实际项目中应该有更完善的权限系统)
func (h *UserHandler) isAdmin(c *gin.Context) bool {
	user := h.getCurrentUser(c)
	if user == nil {
		return false
	}
	// 简单实现：用户名为admin的为管理员
	return user.Username == "admin"
}

// requireAdmin 需要管理员权限的中间件
func (h *UserHandler) requireAdmin(c *gin.Context) {
	if !h.isAdmin(c) {
		utils.ErrorWithCode(c, constants.StatusUnauthorized, "需要管理员权限")
		c.Abort()
		return
	}
	c.Next()
}
