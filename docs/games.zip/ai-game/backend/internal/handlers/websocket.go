package handlers

import (
	"encoding/json"
	"net/http"
	"strconv"
	"strings"
	"time"

	"ai-game/internal/config"
	"ai-game/internal/models"
	"ai-game/internal/services"
	"ai-game/pkg/logger"

	"github.com/gin-gonic/gin"
	"github.com/gorilla/websocket"
)

// WebSocketHandler WebSocket处理器
type WebSocketHandler struct {
	hub         *models.Hub
	chatService services.ChatService
	userService services.UserService
	upgrader    websocket.Upgrader
	cfg         *config.Config
}

// NewWebSocketHandler 创建WebSocket处理器
func NewWebSocketHandler(chatService services.ChatService, userService services.UserService, cfg *config.Config) *WebSocketHandler {
	hub := models.NewHub()

	// 配置WebSocket升级器
	upgrader := websocket.Upgrader{
		ReadBufferSize:  cfg.WebSocket.ReadBufferSize,
		WriteBufferSize: cfg.WebSocket.WriteBufferSize,
		CheckOrigin: func(r *http.Request) bool {
			// 在生产环境中应该检查Origin
			return true
		},
	}

	handler := &WebSocketHandler{
		hub:         hub,
		chatService: chatService,
		userService: userService,
		upgrader:    upgrader,
		cfg:         cfg,
	}

	// 启动Hub
	go handler.hub.Run()

	return handler
}

// HandleConnection 处理WebSocket连接
// @Summary 建立WebSocket连接
// @Description 建立实时通信WebSocket连接
// @Tags WebSocket
// @Param token query string true "JWT令牌"
// @Param room_id query string false "房间ID"
// @Router /api/v1/ws/connect [get]
func (h *WebSocketHandler) HandleConnection(c *gin.Context) {
	// 获取认证令牌
	token := c.Query("token")
	if token == "" {
		c.JSON(http.StatusUnauthorized, gin.H{"error": "需要认证令牌"})
		return
	}

	// 验证令牌
	user, err := h.userService.ValidateToken(token)
	if err != nil {
		logger.Warn("WebSocket认证失败: %v", err)
		c.JSON(http.StatusUnauthorized, gin.H{"error": "令牌无效"})
		return
	}

	// 升级HTTP连接为WebSocket连接
	conn, err := h.upgrader.Upgrade(c.Writer, c.Request, nil)
	if err != nil {
		logger.Error("WebSocket升级失败: %v", err)
		return
	}

	// 获取房间ID
	roomID := c.Query("room_id")

	// 创建客户端
	client := &models.Client{
		ID:       generateClientID(user.ID),
		UserID:   user.ID,
		RoomID:   roomID,
		Send:     make(chan []byte, 256),
		Hub:      h.hub,
		Conn:     conn,
		LastPing: time.Now(),
	}

	// 注册客户端
	h.hub.Register <- client

	// 如果指定了房间，加入房间
	if roomID != "" {
		h.hub.AddClientToRoom(roomID, client)

		// 通知房间其他成员有新用户加入
		h.broadcastRoomNotification(roomID, "user_joined", map[string]interface{}{
			"user_id": user.ID,
			"message": "用户加入房间",
		})
	}

	logger.Info("WebSocket连接建立: UserID=%s, RoomID=%s, ClientID=%s", user.ID, roomID, client.ID)

	// 启动客户端处理协程
	go h.handleClientWrite(client)
	go h.handleClientRead(client)
}

// handleClientRead 处理客户端读取
func (h *WebSocketHandler) handleClientRead(client *models.Client) {
	defer func() {
		h.hub.Unregister <- client
		if client.RoomID != "" {
			h.hub.RemoveClientFromRoom(client.RoomID, client)
			// 通知房间其他成员用户离开
			h.broadcastRoomNotification(client.RoomID, "user_left", map[string]interface{}{
				"user_id": client.UserID,
				"message": "用户离开房间",
			})
		}
		if conn, ok := client.Conn.(*websocket.Conn); ok {
			conn.Close()
		}
	}()

	// 设置读取参数
	if conn, ok := client.Conn.(*websocket.Conn); ok {
		conn.SetReadLimit(int64(h.cfg.WebSocket.MaxMessageSize))
		conn.SetReadDeadline(time.Now().Add(time.Duration(h.cfg.WebSocket.PongWait) * time.Second))
		conn.SetPongHandler(func(string) error {
			conn.SetReadDeadline(time.Now().Add(time.Duration(h.cfg.WebSocket.PongWait) * time.Second))
			client.LastPing = time.Now()
			return nil
		})

		for {
			// 读取消息
			_, message, err := conn.ReadMessage()
			if err != nil {
				if websocket.IsUnexpectedCloseError(err, websocket.CloseGoingAway, websocket.CloseAbnormalClosure) {
					logger.Error("WebSocket读取错误: %v", err)
				}
				break
			}

			// 更新最后活动时间
			client.LastPing = time.Now()

			// 处理消息
			h.handleMessage(client, message)
		}
	}
}

// handleClientWrite 处理客户端写入
func (h *WebSocketHandler) handleClientWrite(client *models.Client) {
	ticker := time.NewTicker(time.Duration(h.cfg.WebSocket.HeartbeatInterval) * time.Second)
	defer func() {
		ticker.Stop()
		if conn, ok := client.Conn.(*websocket.Conn); ok {
			conn.Close()
		}
	}()

	conn, ok := client.Conn.(*websocket.Conn)
	if !ok {
		return
	}

	for {
		select {
		case message, ok := <-client.Send:
			conn.SetWriteDeadline(time.Now().Add(time.Duration(h.cfg.WebSocket.WriteWait) * time.Second))
			if !ok {
				conn.WriteMessage(websocket.CloseMessage, []byte{})
				return
			}

			w, err := conn.NextWriter(websocket.TextMessage)
			if err != nil {
				return
			}
			w.Write(message)

			// 写入队列中的其他消息
			n := len(client.Send)
			for i := 0; i < n; i++ {
				w.Write([]byte{'\n'})
				w.Write(<-client.Send)
			}

			if err := w.Close(); err != nil {
				return
			}

		case <-ticker.C:
			conn.SetWriteDeadline(time.Now().Add(time.Duration(h.cfg.WebSocket.WriteWait) * time.Second))
			if err := conn.WriteMessage(websocket.PingMessage, nil); err != nil {
				return
			}
		}
	}
}

// handleMessage 处理收到的消息
func (h *WebSocketHandler) handleMessage(client *models.Client, data []byte) {
	var wsMsg models.WSMessage
	if err := json.Unmarshal(data, &wsMsg); err != nil {
		logger.Error("解析WebSocket消息失败: %v", err)
		h.sendError(client, "消息格式错误")
		return
	}

	switch wsMsg.Type {
	case "chat":
		h.handleChatMessage(client, &wsMsg)
	case "game":
		h.handleGameMessage(client, &wsMsg)
	case "room":
		h.handleRoomMessage(client, &wsMsg)
	case "heartbeat":
		h.handleHeartbeat(client, &wsMsg)
	default:
		logger.Warn("未知消息类型: %s", wsMsg.Type)
		h.sendError(client, "未知消息类型")
	}
}

// handleChatMessage 处理聊天消息
func (h *WebSocketHandler) handleChatMessage(client *models.Client, wsMsg *models.WSMessage) {
	switch wsMsg.Action {
	case "send":
		h.handleSendChat(client, wsMsg)
	case "typing":
		h.handleTyping(client, wsMsg)
	default:
		h.sendError(client, "未知聊天操作")
	}
}

// handleSendChat 处理发送聊天
func (h *WebSocketHandler) handleSendChat(client *models.Client, wsMsg *models.WSMessage) {
	data, ok := wsMsg.Data.(map[string]interface{})
	if !ok {
		h.sendError(client, "聊天数据格式错误")
		return
	}

	content, ok := data["content"].(string)
	if !ok || strings.TrimSpace(content) == "" {
		h.sendError(client, "聊天内容不能为空")
		return
	}

	msgType := 1 // 默认文本消息
	if t, ok := data["type"].(float64); ok {
		msgType = int(t)
	}

	// 创建聊天消息
	chatMsg := &models.ChatMessage{
		RoomID:   client.RoomID,
		UserID:   client.UserID,
		Content:  content,
		Type:     msgType,
		IsAI:     false,
		Status:   1,
		CreateAt: time.Now(),
		UpdateAt: time.Now(),
	}

	// 保存消息
	result, err := h.chatService.SendMessage(chatMsg)
	if err != nil {
		logger.Error("保存聊天消息失败: %v", err)
		h.sendError(client, "发送消息失败")
		return
	}

	// 获取用户信息以完善消息数据
	userResp, err := h.userService.GetProfile(client.UserID)
	if err != nil {
		logger.Warn("获取用户信息失败: %v", err)
	}

	// 构建广播消息
	chatData := &models.ChatMessageData{
		ID:        result.ID,
		RoomID:    result.RoomID,
		UserID:    result.UserID,
		Username:  "",
		Nickname:  "",
		Avatar:    "",
		Message:   result.Content,
		IsAI:      result.IsAI,
		Timestamp: result.CreateAt,
	}

	if userResp != nil {
		chatData.Username = userResp.Username
		chatData.Nickname = userResp.Nickname
		chatData.Avatar = userResp.Avatar
	}

	// 向房间广播消息
	broadcastMsg := models.NewWSMessage("chat", "message", chatData)
	broadcastData, _ := json.Marshal(broadcastMsg)
	h.hub.BroadcastToRoom(client.RoomID, broadcastData)

	logger.Debug("聊天消息已广播: RoomID=%s, UserID=%s", client.RoomID, client.UserID)
}

// handleTyping 处理打字状态
func (h *WebSocketHandler) handleTyping(client *models.Client, wsMsg *models.WSMessage) {
	data, ok := wsMsg.Data.(map[string]interface{})
	if !ok {
		return
	}

	isTyping, _ := data["is_typing"].(bool)

	// 向房间其他成员广播打字状态
	typingData := map[string]interface{}{
		"user_id":   client.UserID,
		"is_typing": isTyping,
	}

	broadcastMsg := models.NewWSMessage("chat", "typing", typingData)
	broadcastData, _ := json.Marshal(broadcastMsg)

	// 广播给房间其他成员(不包括发送者)
	h.broadcastToRoomExclude(client.RoomID, client.ID, broadcastData)
}

// handleGameMessage 处理游戏消息
func (h *WebSocketHandler) handleGameMessage(client *models.Client, wsMsg *models.WSMessage) {
	// 游戏相关消息处理(后续实现)
	logger.Debug("收到游戏消息: Action=%s, UserID=%s", wsMsg.Action, client.UserID)
}

// handleRoomMessage 处理房间消息
func (h *WebSocketHandler) handleRoomMessage(client *models.Client, wsMsg *models.WSMessage) {
	switch wsMsg.Action {
	case "join":
		h.handleJoinRoom(client, wsMsg)
	case "leave":
		h.handleLeaveRoom(client, wsMsg)
	default:
		h.sendError(client, "未知房间操作")
	}
}

// handleJoinRoom 处理加入房间
func (h *WebSocketHandler) handleJoinRoom(client *models.Client, wsMsg *models.WSMessage) {
	data, ok := wsMsg.Data.(map[string]interface{})
	if !ok {
		h.sendError(client, "房间数据格式错误")
		return
	}

	roomID, ok := data["room_id"].(string)
	if !ok || roomID == "" {
		h.sendError(client, "房间ID不能为空")
		return
	}

	// 离开当前房间
	if client.RoomID != "" {
		h.hub.RemoveClientFromRoom(client.RoomID, client)
		h.broadcastRoomNotification(client.RoomID, "user_left", map[string]interface{}{
			"user_id": client.UserID,
			"message": "用户离开房间",
		})
	}

	// 加入新房间
	h.hub.AddClientToRoom(roomID, client)
	h.broadcastRoomNotification(roomID, "user_joined", map[string]interface{}{
		"user_id": client.UserID,
		"message": "用户加入房间",
	})

	// 发送确认消息
	confirmMsg := models.NewWSMessage("room", "joined", map[string]interface{}{
		"room_id": roomID,
		"message": "成功加入房间",
	})
	confirmData, _ := json.Marshal(confirmMsg)
	client.Send <- confirmData

	logger.Info("用户加入房间: UserID=%s, RoomID=%s", client.UserID, roomID)
}

// handleLeaveRoom 处理离开房间
func (h *WebSocketHandler) handleLeaveRoom(client *models.Client, wsMsg *models.WSMessage) {
	if client.RoomID == "" {
		h.sendError(client, "未在任何房间中")
		return
	}

	roomID := client.RoomID
	h.hub.RemoveClientFromRoom(roomID, client)
	h.broadcastRoomNotification(roomID, "user_left", map[string]interface{}{
		"user_id": client.UserID,
		"message": "用户离开房间",
	})

	// 发送确认消息
	confirmMsg := models.NewWSMessage("room", "left", map[string]interface{}{
		"room_id": roomID,
		"message": "成功离开房间",
	})
	confirmData, _ := json.Marshal(confirmMsg)
	client.Send <- confirmData

	logger.Info("用户离开房间: UserID=%s, RoomID=%s", client.UserID, roomID)
}

// handleHeartbeat 处理心跳
func (h *WebSocketHandler) handleHeartbeat(client *models.Client, wsMsg *models.WSMessage) {
	client.LastPing = time.Now()

	// 回复心跳响应
	pongMsg := models.NewWSMessage("heartbeat", "pong", &models.HeartbeatData{
		Timestamp: time.Now().Unix(),
	})
	pongData, _ := json.Marshal(pongMsg)
	client.Send <- pongData
}

// sendError 发送错误消息
func (h *WebSocketHandler) sendError(client *models.Client, message string) {
	errorMsg := models.NewWSMessage("error", "message", &models.ErrorData{
		Code:    400,
		Message: message,
		Details: "",
	})
	errorData, _ := json.Marshal(errorMsg)

	select {
	case client.Send <- errorData:
	default:
		// 发送缓冲区满，忽略
	}
}

// broadcastRoomNotification 向房间广播通知
func (h *WebSocketHandler) broadcastRoomNotification(roomID, action string, data interface{}) {
	if roomID == "" {
		return
	}

	notificationMsg := models.NewWSMessage("notification", action, data)
	notificationData, _ := json.Marshal(notificationMsg)
	h.hub.BroadcastToRoom(roomID, notificationData)
}

// broadcastToRoomExclude 向房间广播消息(排除指定客户端)
func (h *WebSocketHandler) broadcastToRoomExclude(roomID, excludeClientID string, message []byte) {
	if clients := h.hub.GetRoomClients(roomID); clients != nil {
		for _, client := range clients {
			if client.ID != excludeClientID {
				select {
				case client.Send <- message:
				default:
					// 发送缓冲区满，关闭连接
					close(client.Send)
					delete(h.hub.Clients, client)
					h.hub.RemoveClientFromRoom(roomID, client)
				}
			}
		}
	}
}

// generateClientID 生成客户端ID
func generateClientID(userID string) string {
	return userID + "-" + strconv.FormatInt(time.Now().UnixNano(), 36)
}

// GetHub 获取Hub实例(用于其他模块)
func (h *WebSocketHandler) GetHub() *models.Hub {
	return h.hub
}

// BroadcastToRoom 向指定房间广播消息(公开方法)
func (h *WebSocketHandler) BroadcastToRoom(roomID string, msgType, action string, data interface{}) {
	msg := models.NewWSMessage(msgType, action, data)
	msgData, _ := json.Marshal(msg)
	h.hub.BroadcastToRoom(roomID, msgData)
}

// BroadcastChatMessage 广播聊天消息(公开方法)
func (h *WebSocketHandler) BroadcastChatMessage(roomID string, chatMsg *models.ChatMessage, user *models.User) {
	chatData := &models.ChatMessageData{
		ID:        chatMsg.ID,
		RoomID:    chatMsg.RoomID,
		UserID:    chatMsg.UserID,
		Username:  "",
		Nickname:  "",
		Avatar:    "",
		Message:   chatMsg.Content,
		IsAI:      chatMsg.IsAI,
		Timestamp: chatMsg.CreateAt,
	}

	if user != nil {
		chatData.Username = user.Username
		chatData.Nickname = user.Nickname
		chatData.Avatar = user.Avatar
	}

	h.BroadcastToRoom(roomID, "chat", "message", chatData)
}
