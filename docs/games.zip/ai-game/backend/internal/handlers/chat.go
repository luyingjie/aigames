package handlers

import (
	"strconv"
	"time"

	"ai-game/internal/models"
	"ai-game/internal/services"
	"ai-game/pkg/logger"
	"ai-game/pkg/utils"

	"github.com/gin-gonic/gin"
)

// ChatHandler 聊天处理器
type ChatHandler struct {
	chatService services.ChatService
	userService services.UserService
}

// NewChatHandler 创建聊天处理器
func NewChatHandler(chatService services.ChatService, userService services.UserService) *ChatHandler {
	return &ChatHandler{
		chatService: chatService,
		userService: userService,
	}
}

// SendMessage 发送聊天消息
// @Summary 发送聊天消息
// @Description 在房间内发送聊天消息
// @Tags 聊天
// @Accept json
// @Produce json
// @Param request body SendMessageRequest true "发送消息请求"
// @Success 200 {object} utils.Response{data=models.ChatMessage}
// @Failure 400 {object} utils.Response
// @Failure 401 {object} utils.Response
// @Failure 500 {object} utils.Response
// @Router /api/v1/chat/send [post]
func (h *ChatHandler) SendMessage(c *gin.Context) {
	var req SendMessageRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		utils.BadRequest(c, "请求参数错误: "+err.Error())
		return
	}

	// 获取当前用户信息
	userID, exists := c.Get("user_id")
	if !exists {
		utils.Unauthorized(c, "用户未登录")
		return
	}

	userIDStr := userID.(string)

	// 创建聊天消息
	message := &models.ChatMessage{
		RoomID:   req.RoomID,
		UserID:   userIDStr,
		Content:  req.Content,
		Type:     req.Type,
		IsAI:     false,
		AIPlayer: "",
		Status:   1, // 正常状态
		CreateAt: time.Now(),
		UpdateAt: time.Now(),
	}

	// 发送消息
	result, err := h.chatService.SendMessage(message)
	if err != nil {
		logger.Error("发送聊天消息失败: %v", err)
		utils.Error(c, err)
		return
	}

	utils.Success(c, result)
}

// GetRoomMessages 获取房间消息
// @Summary 获取房间消息
// @Description 获取指定房间的聊天消息历史
// @Tags 聊天
// @Accept json
// @Produce json
// @Param room_id path string true "房间ID"
// @Param page query int false "页码" default(1)
// @Param limit query int false "每页条数" default(20)
// @Success 200 {object} utils.Response{data=[]models.ChatMessage}
// @Failure 400 {object} utils.Response
// @Failure 401 {object} utils.Response
// @Failure 500 {object} utils.Response
// @Router /api/v1/chat/rooms/{room_id}/messages [get]
func (h *ChatHandler) GetRoomMessages(c *gin.Context) {
	roomID := c.Param("room_id")
	if roomID == "" {
		utils.BadRequest(c, "房间ID不能为空")
		return
	}

	// 获取分页参数
	page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
	limit, _ := strconv.Atoi(c.DefaultQuery("limit", "20"))

	if page < 1 {
		page = 1
	}
	if limit < 1 || limit > 100 {
		limit = 20
	}

	// 获取房间消息
	messages, total, err := h.chatService.GetRoomMessages(roomID, page, limit)
	if err != nil {
		logger.Error("获取房间消息失败: %v", err)
		utils.Error(c, err)
		return
	}

	response := map[string]interface{}{
		"messages": messages,
		"total":    total,
		"page":     page,
		"limit":    limit,
	}

	utils.Success(c, response)
}

// DeleteMessage 删除消息
// @Summary 删除消息
// @Description 删除指定的聊天消息(仅限消息发送者或管理员)
// @Tags 聊天
// @Accept json
// @Produce json
// @Param message_id path string true "消息ID"
// @Success 200 {object} utils.Response
// @Failure 400 {object} utils.Response
// @Failure 401 {object} utils.Response
// @Failure 403 {object} utils.Response
// @Failure 500 {object} utils.Response
// @Router /api/v1/chat/messages/{message_id} [delete]
func (h *ChatHandler) DeleteMessage(c *gin.Context) {
	messageID := c.Param("message_id")
	if messageID == "" {
		utils.BadRequest(c, "消息ID不能为空")
		return
	}

	// 获取当前用户信息
	userID, exists := c.Get("user_id")
	if !exists {
		utils.Unauthorized(c, "用户未登录")
		return
	}

	userIDStr := userID.(string)

	// 获取消息信息
	message, err := h.chatService.GetMessageByID(messageID)
	if err != nil {
		logger.Error("获取消息失败: %v", err)
		utils.Error(c, err)
		return
	}

	// 检查权限(只有消息发送者或管理员可以删除)
	isAdmin, _ := c.Get("is_admin")
	if message.UserID != userIDStr && (isAdmin == nil || !isAdmin.(bool)) {
		utils.Forbidden(c, "无权限删除此消息")
		return
	}

	// 删除消息
	if err := h.chatService.DeleteMessage(messageID); err != nil {
		logger.Error("删除消息失败: %v", err)
		utils.Error(c, err)
		return
	}

	utils.SuccessWithMessage(c, "消息删除成功", nil)
}

// GetUserMessages 获取用户消息
// @Summary 获取用户消息
// @Description 获取指定用户的聊天消息
// @Tags 聊天
// @Accept json
// @Produce json
// @Param user_id path string true "用户ID"
// @Param page query int false "页码" default(1)
// @Param limit query int false "每页条数" default(20)
// @Success 200 {object} utils.Response{data=[]models.ChatMessage}
// @Failure 400 {object} utils.Response
// @Failure 401 {object} utils.Response
// @Failure 500 {object} utils.Response
// @Router /api/v1/chat/users/{user_id}/messages [get]
func (h *ChatHandler) GetUserMessages(c *gin.Context) {
	targetUserID := c.Param("user_id")
	if targetUserID == "" {
		utils.BadRequest(c, "用户ID不能为空")
		return
	}

	// 获取当前用户信息
	currentUserID, exists := c.Get("user_id")
	if !exists {
		utils.Unauthorized(c, "用户未登录")
		return
	}

	// 只允许查看自己的消息，除非是管理员
	isAdmin, _ := c.Get("is_admin")
	if targetUserID != currentUserID.(string) && (isAdmin == nil || !isAdmin.(bool)) {
		utils.Forbidden(c, "无权限查看此用户消息")
		return
	}

	// 获取分页参数
	page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
	limit, _ := strconv.Atoi(c.DefaultQuery("limit", "20"))

	if page < 1 {
		page = 1
	}
	if limit < 1 || limit > 100 {
		limit = 20
	}

	// 获取用户消息
	messages, total, err := h.chatService.GetUserMessages(targetUserID, page, limit)
	if err != nil {
		logger.Error("获取用户消息失败: %v", err)
		utils.Error(c, err)
		return
	}

	response := map[string]interface{}{
		"messages": messages,
		"total":    total,
		"page":     page,
		"limit":    limit,
	}

	utils.Success(c, response)
}

// GetChatStats 获取聊天统计
// @Summary 获取聊天统计
// @Description 获取聊天相关的统计信息
// @Tags 聊天
// @Accept json
// @Produce json
// @Param room_id query string false "房间ID"
// @Param user_id query string false "用户ID"
// @Success 200 {object} utils.Response{data=ChatStatsResponse}
// @Failure 401 {object} utils.Response
// @Failure 500 {object} utils.Response
// @Router /api/v1/chat/stats [get]
func (h *ChatHandler) GetChatStats(c *gin.Context) {
	roomID := c.Query("room_id")
	userID := c.Query("user_id")

	// 如果查询特定用户，需要权限验证
	if userID != "" {
		currentUserID, exists := c.Get("user_id")
		if !exists {
			utils.Unauthorized(c, "用户未登录")
			return
		}

		isAdmin, _ := c.Get("is_admin")
		if userID != currentUserID.(string) && (isAdmin == nil || !isAdmin.(bool)) {
			utils.Forbidden(c, "无权限查看此用户统计")
			return
		}
	}

	// 获取聊天统计
	stats, err := h.chatService.GetChatStats(roomID, userID)
	if err != nil {
		logger.Error("获取聊天统计失败: %v", err)
		utils.Error(c, err)
		return
	}

	utils.Success(c, stats)
}

// TriggerAIChat 触发AI聊天
// @Summary 触发AI聊天
// @Description 触发指定AI玩家发送聊天消息
// @Tags 聊天
// @Accept json
// @Produce json
// @Param request body TriggerAIChatRequest true "触发AI聊天请求"
// @Success 200 {object} utils.Response{data=models.ChatMessage}
// @Failure 400 {object} utils.Response
// @Failure 401 {object} utils.Response
// @Failure 500 {object} utils.Response
// @Router /api/v1/chat/ai/trigger [post]
func (h *ChatHandler) TriggerAIChat(c *gin.Context) {
	var req TriggerAIChatRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		utils.BadRequest(c, "请求参数错误: "+err.Error())
		return
	}

	// 验证是否为管理员(只有管理员可以手动触发AI聊天)
	isAdmin, exists := c.Get("is_admin")
	if !exists || !isAdmin.(bool) {
		utils.Forbidden(c, "无权限执行此操作")
		return
	}

	// 触发AI聊天
	message, err := h.chatService.TriggerAIChat(req.AIPlayerID, req.RoomID, req.Context)
	if err != nil {
		logger.Error("触发AI聊天失败: %v", err)
		utils.Error(c, err)
		return
	}

	if message == nil {
		utils.SuccessWithMessage(c, "AI未生成聊天消息", nil)
	} else {
		utils.Success(c, message)
	}
}

// 请求结构体

// SendMessageRequest 发送消息请求
type SendMessageRequest struct {
	RoomID  string `json:"room_id" binding:"required"`         // 房间ID
	Content string `json:"content" binding:"required,max=500"` // 消息内容
	Type    int    `json:"type" binding:"oneof=1 2 3"`         // 消息类型：1-文本 2-表情 3-系统
}

// TriggerAIChatRequest 触发AI聊天请求
type TriggerAIChatRequest struct {
	AIPlayerID string `json:"ai_player_id" binding:"required"` // AI玩家ID
	RoomID     string `json:"room_id" binding:"required"`      // 房间ID
	Context    string `json:"context"`                         // 聊天上下文
}

// ChatStatsResponse 聊天统计响应
type ChatStatsResponse struct {
	TotalMessages int                  `json:"total_messages"` // 总消息数
	UserStats     map[string]UserStats `json:"user_stats"`     // 用户统计
	AIStats       map[string]AIStats   `json:"ai_stats"`       // AI统计
	HourlyStats   map[string]int       `json:"hourly_stats"`   // 每小时统计
	TypeStats     map[string]int       `json:"type_stats"`     // 消息类型统计
}

// UserStats 用户统计
type UserStats struct {
	MessageCount int       `json:"message_count"` // 消息数量
	LastMessage  time.Time `json:"last_message"`  // 最后消息时间
}

// AIStats AI统计
type AIStats struct {
	MessageCount int       `json:"message_count"` // 消息数量
	LastMessage  time.Time `json:"last_message"`  // 最后消息时间
	ResponseRate float64   `json:"response_rate"` // 响应率
}
