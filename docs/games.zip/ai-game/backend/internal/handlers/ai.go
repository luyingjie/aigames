package handlers

import (
	"strconv"

	"ai-game/internal/models"
	"ai-game/internal/services"
	"ai-game/internal/utils"
	"ai-game/pkg/logger"

	"github.com/gin-gonic/gin"
)

// AIHandler AI处理器
type AIHandler struct {
	aiPlayerService services.AIPlayerService
}

// NewAIHandler 创建AI处理器实例
func NewAIHandler(aiPlayerService services.AIPlayerService) *AIHandler {
	return &AIHandler{
		aiPlayerService: aiPlayerService,
	}
}

// CreateAIPlayer 创建AI玩家
// @Summary 创建AI玩家
// @Description 创建新的AI玩家
// @Tags AI管理
// @Accept json
// @Produce json
// @Param request body models.CreateAIPlayerRequest true "创建AI玩家请求"
// @Success 200 {object} utils.Response{data=models.AIPlayer}
// @Failure 400 {object} utils.Response
// @Router /api/ai/players [post]
func (h *AIHandler) CreateAIPlayer(c *gin.Context) {
	var req models.CreateAIPlayerRequest

	// 绑定请求参数
	if err := c.ShouldBindJSON(&req); err != nil {
		logger.Warn("创建AI玩家请求参数错误: %v", err)
		utils.BadRequest(c, "请求参数格式错误")
		return
	}

	// 调用服务层
	aiPlayer, err := h.aiPlayerService.CreateAIPlayer(&req)
	if err != nil {
		logger.Error("创建AI玩家失败: %v", err)
		utils.Error(c, err)
		return
	}

	utils.SuccessWithMessage(c, "AI玩家创建成功", aiPlayer)
}

// GetAIPlayer 获取AI玩家详情
// @Summary 获取AI玩家详情
// @Description 根据ID获取AI玩家详细信息
// @Tags AI管理
// @Accept json
// @Produce json
// @Param id path string true "AI玩家ID"
// @Success 200 {object} utils.Response{data=models.AIPlayer}
// @Failure 404 {object} utils.Response
// @Router /api/ai/players/{id} [get]
func (h *AIHandler) GetAIPlayer(c *gin.Context) {
	id := c.Param("id")
	if id == "" {
		utils.BadRequest(c, "AI玩家ID不能为空")
		return
	}

	// 调用服务层
	aiPlayer, err := h.aiPlayerService.GetAIPlayer(id)
	if err != nil {
		logger.Error("获取AI玩家失败: %v", err)
		utils.Error(c, err)
		return
	}

	utils.Success(c, aiPlayer)
}

// UpdateAIPlayer 更新AI玩家
// @Summary 更新AI玩家
// @Description 更新AI玩家信息
// @Tags AI管理
// @Accept json
// @Produce json
// @Param id path string true "AI玩家ID"
// @Param request body models.UpdateAIPlayerRequest true "更新AI玩家请求"
// @Success 200 {object} utils.Response{data=models.AIPlayer}
// @Failure 400 {object} utils.Response
// @Router /api/ai/players/{id} [put]
func (h *AIHandler) UpdateAIPlayer(c *gin.Context) {
	id := c.Param("id")
	if id == "" {
		utils.BadRequest(c, "AI玩家ID不能为空")
		return
	}

	var req models.UpdateAIPlayerRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		logger.Warn("更新AI玩家请求参数错误: %v", err)
		utils.BadRequest(c, "请求参数格式错误")
		return
	}

	// 调用服务层
	aiPlayer, err := h.aiPlayerService.UpdateAIPlayer(id, &req)
	if err != nil {
		logger.Error("更新AI玩家失败: %v", err)
		utils.Error(c, err)
		return
	}

	utils.SuccessWithMessage(c, "AI玩家更新成功", aiPlayer)
}

// DeleteAIPlayer 删除AI玩家
// @Summary 删除AI玩家
// @Description 删除指定的AI玩家
// @Tags AI管理
// @Accept json
// @Produce json
// @Param id path string true "AI玩家ID"
// @Success 200 {object} utils.Response
// @Failure 404 {object} utils.Response
// @Router /api/ai/players/{id} [delete]
func (h *AIHandler) DeleteAIPlayer(c *gin.Context) {
	id := c.Param("id")
	if id == "" {
		utils.BadRequest(c, "AI玩家ID不能为空")
		return
	}

	// 调用服务层
	if err := h.aiPlayerService.DeleteAIPlayer(id); err != nil {
		logger.Error("删除AI玩家失败: %v", err)
		utils.Error(c, err)
		return
	}

	utils.SuccessWithMessage(c, "AI玩家删除成功", nil)
}

// ListAIPlayers 获取AI玩家列表
// @Summary 获取AI玩家列表
// @Description 分页获取AI玩家列表
// @Tags AI管理
// @Accept json
// @Produce json
// @Param page query int false "页码" default(1)
// @Param size query int false "每页数量" default(10)
// @Success 200 {object} utils.PageResponse{data=[]models.AIPlayerListResponse}
// @Router /api/ai/players [get]
func (h *AIHandler) ListAIPlayers(c *gin.Context) {
	// 获取分页参数
	page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
	size, _ := strconv.Atoi(c.DefaultQuery("size", "10"))

	if page < 1 {
		page = 1
	}
	if size < 1 || size > 100 {
		size = 10
	}

	// 调用服务层
	aiPlayers, total, err := h.aiPlayerService.ListAIPlayers(page, size)
	if err != nil {
		logger.Error("获取AI玩家列表失败: %v", err)
		utils.Error(c, err)
		return
	}

	// 返回分页响应
	utils.PageSuccess(c, aiPlayers, utils.PageInfo{
		Current: page,
		Size:    size,
		Total:   total,
		Pages:   (total + size - 1) / size,
	})
}

// ListEnabledAIPlayers 获取启用的AI玩家列表
// @Summary 获取启用的AI玩家列表
// @Description 获取所有启用状态的AI玩家
// @Tags AI管理
// @Accept json
// @Produce json
// @Success 200 {object} utils.Response{data=[]models.AIPlayerListResponse}
// @Router /api/ai/players/enabled [get]
func (h *AIHandler) ListEnabledAIPlayers(c *gin.Context) {
	// 调用服务层
	aiPlayers, err := h.aiPlayerService.ListEnabledAIPlayers()
	if err != nil {
		logger.Error("获取启用AI玩家列表失败: %v", err)
		utils.Error(c, err)
		return
	}

	utils.Success(c, aiPlayers)
}

// GetAIPlayersByPersonality 根据性格获取AI玩家
// @Summary 根据性格获取AI玩家
// @Description 根据性格类型筛选AI玩家
// @Tags AI管理
// @Accept json
// @Produce json
// @Param personality path string true "性格类型" Enums(aggressive,conservative,balanced)
// @Success 200 {object} utils.Response{data=[]models.AIPlayerListResponse}
// @Router /api/ai/players/personality/{personality} [get]
func (h *AIHandler) GetAIPlayersByPersonality(c *gin.Context) {
	personality := c.Param("personality")
	if personality == "" {
		utils.BadRequest(c, "性格类型不能为空")
		return
	}

	// 验证性格类型
	validPersonalities := []string{"aggressive", "conservative", "balanced"}
	isValid := false
	for _, p := range validPersonalities {
		if personality == p {
			isValid = true
			break
		}
	}
	if !isValid {
		utils.BadRequest(c, "无效的性格类型")
		return
	}

	// 调用服务层
	aiPlayers, err := h.aiPlayerService.GetAIPlayersByPersonality(personality)
	if err != nil {
		logger.Error("根据性格获取AI玩家失败: %v", err)
		utils.Error(c, err)
		return
	}

	utils.Success(c, aiPlayers)
}

// TestAIConnection 测试AI连接
// @Summary 测试AI连接
// @Description 测试AI API连接是否正常
// @Tags AI管理
// @Accept json
// @Produce json
// @Param request body map[string]string true "测试请求" example({"api_key":"sk-xxx","model":"gpt-3.5-turbo"})
// @Success 200 {object} utils.Response
// @Failure 400 {object} utils.Response
// @Router /api/ai/test-connection [post]
func (h *AIHandler) TestAIConnection(c *gin.Context) {
	var req map[string]string
	if err := c.ShouldBindJSON(&req); err != nil {
		logger.Warn("测试AI连接请求参数错误: %v", err)
		utils.BadRequest(c, "请求参数格式错误")
		return
	}

	apiKey, exists := req["api_key"]
	if !exists || apiKey == "" {
		utils.BadRequest(c, "API密钥不能为空")
		return
	}

	model, exists := req["model"]
	if !exists || model == "" {
		utils.BadRequest(c, "AI模型不能为空")
		return
	}

	// 调用服务层测试连接
	if err := h.aiPlayerService.TestAIConnection(apiKey, model); err != nil {
		logger.Error("测试AI连接失败: %v", err)
		utils.Error(c, err)
		return
	}

	utils.SuccessWithMessage(c, "AI连接测试成功", nil)
}

// UpdateAIConfig 更新AI配置
// @Summary 更新AI配置
// @Description 更新指定AI玩家的配置参数
// @Tags AI管理
// @Accept json
// @Produce json
// @Param id path string true "AI玩家ID"
// @Param request body models.AIConfig true "AI配置"
// @Success 200 {object} utils.Response
// @Failure 400 {object} utils.Response
// @Router /api/ai/players/{id}/config [put]
func (h *AIHandler) UpdateAIConfig(c *gin.Context) {
	id := c.Param("id")
	if id == "" {
		utils.BadRequest(c, "AI玩家ID不能为空")
		return
	}

	var config models.AIConfig
	if err := c.ShouldBindJSON(&config); err != nil {
		logger.Warn("更新AI配置请求参数错误: %v", err)
		utils.BadRequest(c, "请求参数格式错误")
		return
	}

	// 调用服务层
	if err := h.aiPlayerService.UpdateAIConfig(id, config); err != nil {
		logger.Error("更新AI配置失败: %v", err)
		utils.Error(c, err)
		return
	}

	utils.SuccessWithMessage(c, "AI配置更新成功", nil)
}

// UpdatePrompts 更新提示词
// @Summary 更新AI提示词
// @Description 更新指定AI玩家的提示词模板
// @Tags AI管理
// @Accept json
// @Produce json
// @Param id path string true "AI玩家ID"
// @Param request body map[string]string true "提示词映射"
// @Success 200 {object} utils.Response
// @Failure 400 {object} utils.Response
// @Router /api/ai/players/{id}/prompts [put]
func (h *AIHandler) UpdatePrompts(c *gin.Context) {
	id := c.Param("id")
	if id == "" {
		utils.BadRequest(c, "AI玩家ID不能为空")
		return
	}

	var prompts map[string]string
	if err := c.ShouldBindJSON(&prompts); err != nil {
		logger.Warn("更新AI提示词请求参数错误: %v", err)
		utils.BadRequest(c, "请求参数格式错误")
		return
	}

	// 调用服务层
	if err := h.aiPlayerService.UpdatePrompts(id, prompts); err != nil {
		logger.Error("更新AI提示词失败: %v", err)
		utils.Error(c, err)
		return
	}

	utils.SuccessWithMessage(c, "AI提示词更新成功", nil)
}

// GetAIStats 获取AI统计数据
// @Summary 获取AI统计数据
// @Description 获取指定AI玩家的统计信息
// @Tags AI管理
// @Accept json
// @Produce json
// @Param id path string true "AI玩家ID"
// @Success 200 {object} utils.Response{data=models.AIStats}
// @Failure 404 {object} utils.Response
// @Router /api/ai/players/{id}/stats [get]
func (h *AIHandler) GetAIStats(c *gin.Context) {
	id := c.Param("id")
	if id == "" {
		utils.BadRequest(c, "AI玩家ID不能为空")
		return
	}

	// 调用服务层
	stats, err := h.aiPlayerService.GetAIStats(id)
	if err != nil {
		logger.Error("获取AI统计数据失败: %v", err)
		utils.Error(c, err)
		return
	}

	utils.Success(c, stats)
}

// GetDefaultPrompts 获取默认提示词模板
// @Summary 获取默认提示词模板
// @Description 获取系统默认的AI提示词模板
// @Tags AI管理
// @Accept json
// @Produce json
// @Success 200 {object} utils.Response{data=map[string]string}
// @Router /api/ai/default-prompts [get]
func (h *AIHandler) GetDefaultPrompts(c *gin.Context) {
	prompts := models.DefaultPrompts()
	utils.Success(c, prompts)
}

// GetDefaultConfig 获取默认AI配置
// @Summary 获取默认AI配置
// @Description 获取系统默认的AI配置参数
// @Tags AI管理
// @Accept json
// @Produce json
// @Success 200 {object} utils.Response{data=models.AIConfig}
// @Router /api/ai/default-config [get]
func (h *AIHandler) GetDefaultConfig(c *gin.Context) {
	config := models.DefaultAIConfig()
	utils.Success(c, config)
}

// GetPersonalityTypes 获取性格类型列表
// @Summary 获取性格类型列表
// @Description 获取所有可用的AI性格类型
// @Tags AI管理
// @Accept json
// @Produce json
// @Success 200 {object} utils.Response{data=[]map[string]string}
// @Router /api/ai/personality-types [get]
func (h *AIHandler) GetPersonalityTypes(c *gin.Context) {
	types := []map[string]string{
		{
			"value":       "aggressive",
			"label":       "激进型",
			"description": "喜欢冒险，出牌较为激进，倾向于主动出击",
		},
		{
			"value":       "conservative",
			"label":       "保守型",
			"description": "谨慎稳重，出牌较为保守，注重防守",
		},
		{
			"value":       "balanced",
			"label":       "平衡型",
			"description": "攻守兼备，根据局势灵活调整策略",
		},
	}

	utils.Success(c, types)
}
