package repositories

import (
	"encoding/json"
	"fmt"
	"time"

	"ai-game/internal/models"
	"ai-game/pkg/logger"

	bolt "go.etcd.io/bbolt"
)

// RoomRepository 房间仓储接口
type RoomRepository interface {
	CreateRoom(room *models.Room) error
	GetRoom(id string) (*models.Room, error)
	UpdateRoom(room *models.Room) error
	DeleteRoom(id string) error
	GetRoomList(page, limit int) ([]*models.Room, int, error)
}

// roomRepository 房间仓储实现
type roomRepository struct {
	db *bolt.DB
}

// NewRoomRepository 创建房间仓储实例
func NewRoomRepository(db *bolt.DB) RoomRepository {
	return &roomRepository{db: db}
}

// CreateRoom 创建房间
func (r *roomRepository) CreateRoom(room *models.Room) error {
	return r.db.Update(func(tx *bolt.Tx) error {
		bucket, err := tx.CreateBucketIfNotExists([]byte("rooms"))
		if err != nil {
			logger.Error("创建rooms bucket失败: %v", err)
			return err
		}

		// 序列化房间数据
		data, err := json.Marshal(room)
		if err != nil {
			logger.Error("序列化房间数据失败: %v", err)
			return err
		}

		// 保存房间数据
		if err := bucket.Put([]byte(room.ID), data); err != nil {
			logger.Error("保存房间数据失败: %v", err)
			return err
		}

		logger.Debug("房间数据保存成功: ID=%s", room.ID)
		return nil
	})
}

// GetRoom 获取房间
func (r *roomRepository) GetRoom(id string) (*models.Room, error) {
	var room *models.Room

	err := r.db.View(func(tx *bolt.Tx) error {
		bucket := tx.Bucket([]byte("rooms"))
		if bucket == nil {
			return fmt.Errorf("rooms bucket not found")
		}

		data := bucket.Get([]byte(id))
		if data == nil {
			return fmt.Errorf("room not found")
		}

		room = &models.Room{}
		if err := json.Unmarshal(data, room); err != nil {
			logger.Error("反序列化房间数据失败: %v", err)
			return err
		}

		return nil
	})

	if err != nil {
		return nil, err
	}

	return room, nil
}

// UpdateRoom 更新房间
func (r *roomRepository) UpdateRoom(room *models.Room) error {
	room.UpdateAt = time.Now()

	return r.db.Update(func(tx *bolt.Tx) error {
		bucket := tx.Bucket([]byte("rooms"))
		if bucket == nil {
			return fmt.Errorf("rooms bucket not found")
		}

		// 序列化房间数据
		data, err := json.Marshal(room)
		if err != nil {
			logger.Error("序列化房间数据失败: %v", err)
			return err
		}

		// 更新房间数据
		if err := bucket.Put([]byte(room.ID), data); err != nil {
			logger.Error("更新房间数据失败: %v", err)
			return err
		}

		logger.Debug("房间数据更新成功: ID=%s", room.ID)
		return nil
	})
}

// DeleteRoom 删除房间
func (r *roomRepository) DeleteRoom(id string) error {
	return r.db.Update(func(tx *bolt.Tx) error {
		bucket := tx.Bucket([]byte("rooms"))
		if bucket == nil {
			return fmt.Errorf("rooms bucket not found")
		}

		if err := bucket.Delete([]byte(id)); err != nil {
			logger.Error("删除房间失败: %v", err)
			return err
		}

		logger.Debug("房间删除成功: ID=%s", id)
		return nil
	})
}

// GetRoomList 获取房间列表
func (r *roomRepository) GetRoomList(page, limit int) ([]*models.Room, int, error) {
	var rooms []*models.Room
	var total int

	err := r.db.View(func(tx *bolt.Tx) error {
		bucket := tx.Bucket([]byte("rooms"))
		if bucket == nil {
			return nil // 没有房间数据
		}

		// 统计总数
		stats := bucket.Stats()
		total = stats.KeyN

		// 计算分页
		offset := (page - 1) * limit
		count := 0
		added := 0

		cursor := bucket.Cursor()
		for k, v := cursor.First(); k != nil && added < limit; k, v = cursor.Next() {
			// 跳过前面的记录
			if count < offset {
				count++
				continue
			}

			room := &models.Room{}
			if err := json.Unmarshal(v, room); err != nil {
				logger.Error("反序列化房间数据失败: %v", err)
				continue
			}

			rooms = append(rooms, room)
			added++
			count++
		}

		return nil
	})

	if err != nil {
		return nil, 0, err
	}

	return rooms, total, nil
}

// GameRepository 游戏仓储接口
type GameRepository interface {
	CreateGameState(gameState *models.Game) error
	GetGameState(roomID string) (*models.Game, error)
	UpdateGameState(gameState *models.Game) error
	DeleteGameState(roomID string) error
}

// gameRepository 游戏仓储实现
type gameRepository struct {
	db *bolt.DB
}

// NewGameRepository 创建游戏仓储实例
func NewGameRepository(db *bolt.DB) GameRepository {
	return &gameRepository{db: db}
}

// CreateGameState 创建游戏状态
func (r *gameRepository) CreateGameState(gameState *models.Game) error {
	return r.db.Update(func(tx *bolt.Tx) error {
		bucket, err := tx.CreateBucketIfNotExists([]byte("game_states"))
		if err != nil {
			logger.Error("创建game_states bucket失败: %v", err)
			return err
		}

		// 序列化游戏状态数据
		data, err := json.Marshal(gameState)
		if err != nil {
			logger.Error("序列化游戏状态数据失败: %v", err)
			return err
		}

		// 保存游戏状态数据
		if err := bucket.Put([]byte(gameState.RoomID), data); err != nil {
			logger.Error("保存游戏状态数据失败: %v", err)
			return err
		}

		logger.Debug("游戏状态数据保存成功: RoomID=%s", gameState.RoomID)
		return nil
	})
}

// GetGameState 获取游戏状态
func (r *gameRepository) GetGameState(roomID string) (*models.Game, error) {
	var gameState *models.Game

	err := r.db.View(func(tx *bolt.Tx) error {
		bucket := tx.Bucket([]byte("game_states"))
		if bucket == nil {
			return fmt.Errorf("game_states bucket not found")
		}

		data := bucket.Get([]byte(roomID))
		if data == nil {
			return fmt.Errorf("game state not found")
		}

		gameState = &models.Game{}
		if err := json.Unmarshal(data, gameState); err != nil {
			logger.Error("反序列化游戏状态数据失败: %v", err)
			return err
		}

		return nil
	})

	if err != nil {
		return nil, err
	}

	return gameState, nil
}

// UpdateGameState 更新游戏状态
func (r *gameRepository) UpdateGameState(gameState *models.Game) error {
	return r.db.Update(func(tx *bolt.Tx) error {
		bucket := tx.Bucket([]byte("game_states"))
		if bucket == nil {
			return fmt.Errorf("game_states bucket not found")
		}

		// 序列化游戏状态数据
		data, err := json.Marshal(gameState)
		if err != nil {
			logger.Error("序列化游戏状态数据失败: %v", err)
			return err
		}

		// 更新游戏状态数据
		if err := bucket.Put([]byte(gameState.RoomID), data); err != nil {
			logger.Error("更新游戏状态数据失败: %v", err)
			return err
		}

		logger.Debug("游戏状态数据更新成功: RoomID=%s", gameState.RoomID)
		return nil
	})
}

// DeleteGameState 删除游戏状态
func (r *gameRepository) DeleteGameState(roomID string) error {
	return r.db.Update(func(tx *bolt.Tx) error {
		bucket := tx.Bucket([]byte("game_states"))
		if bucket == nil {
			return fmt.Errorf("game_states bucket not found")
		}

		if err := bucket.Delete([]byte(roomID)); err != nil {
			logger.Error("删除游戏状态失败: %v", err)
			return err
		}

		logger.Debug("游戏状态删除成功: RoomID=%s", roomID)
		return nil
	})
}
