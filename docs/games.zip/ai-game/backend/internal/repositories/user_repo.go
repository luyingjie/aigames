package repositories

import (
	"fmt"
	"time"

	"ai-game/internal/database"
	"ai-game/internal/models"
	"ai-game/pkg/constants"
	appErrors "ai-game/pkg/errors"
)

// UserRepository 用户数据访问接口
type UserRepository interface {
	Create(user *models.User) error
	GetByID(userID string) (*models.User, error)
	GetByUsername(username string) (*models.User, error)
	Update(user *models.User) error
	Delete(userID string) error
	List(page, size int) ([]*models.User, int, error)
	ExistsByUsername(username string) bool
	UpdateStatus(userID string, status int) error
	UpdateScore(userID string, scoreChange int) error
	GetTopPlayers(limit int) ([]*models.User, error)
	SearchByNickname(nickname string, page, size int) ([]*models.User, int, error)
}

// userRepository 用户数据访问实现
type userRepository struct {
	db *database.DB
}

// NewUserRepository 创建用户数据访问实例
func NewUserRepository(db *database.DB) UserRepository {
	return &userRepository{db: db}
}

// Create 创建用户
func (r *userRepository) Create(user *models.User) error {
	// 检查用户名是否已存在
	if r.ExistsByUsername(user.Username) {
		return appErrors.ErrUserExists
	}

	// 设置创建和更新时间
	now := time.Now()
	user.CreateAt = now
	user.UpdateAt = now

	// 如果没有设置头像，生成默认头像
	if user.Avatar == "" {
		user.Avatar = generateDefaultAvatar(user.Username)
	}

	// 存储到数据库
	if err := r.db.Put(constants.BucketUsers, user.ID, user); err != nil {
		return appErrors.NewWithDetails(constants.StatusServerError, "创建用户失败", err.Error())
	}

	return nil
}

// GetByID 根据ID获取用户
func (r *userRepository) GetByID(userID string) (*models.User, error) {
	var user models.User
	if err := r.db.Get(constants.BucketUsers, userID, &user); err != nil {
		return nil, appErrors.ErrUserNotFound
	}
	return &user, nil
}

// GetByUsername 根据用户名获取用户
func (r *userRepository) GetByUsername(username string) (*models.User, error) {
	// 遍历所有用户查找匹配的用户名
	keys, err := r.db.ListKeys(constants.BucketUsers)
	if err != nil {
		return nil, appErrors.NewWithDetails(constants.StatusServerError, "查询用户失败", err.Error())
	}

	for _, key := range keys {
		var user models.User
		if err := r.db.Get(constants.BucketUsers, key, &user); err != nil {
			continue
		}
		if user.Username == username {
			return &user, nil
		}
	}

	return nil, appErrors.ErrUserNotFound
}

// Update 更新用户信息
func (r *userRepository) Update(user *models.User) error {
	// 检查用户是否存在
	if !r.db.Exists(constants.BucketUsers, user.ID) {
		return appErrors.ErrUserNotFound
	}

	// 更新时间
	user.UpdateAt = time.Now()

	// 保存到数据库
	if err := r.db.Put(constants.BucketUsers, user.ID, user); err != nil {
		return appErrors.NewWithDetails(constants.StatusServerError, "更新用户失败", err.Error())
	}

	return nil
}

// Delete 删除用户
func (r *userRepository) Delete(userID string) error {
	// 检查用户是否存在
	if !r.db.Exists(constants.BucketUsers, userID) {
		return appErrors.ErrUserNotFound
	}

	// 从数据库删除
	if err := r.db.Delete(constants.BucketUsers, userID); err != nil {
		return appErrors.NewWithDetails(constants.StatusServerError, "删除用户失败", err.Error())
	}

	return nil
}

// List 分页获取用户列表
func (r *userRepository) List(page, size int) ([]*models.User, int, error) {
	// 获取所有用户ID
	keys, err := r.db.ListKeys(constants.BucketUsers)
	if err != nil {
		return nil, 0, appErrors.NewWithDetails(constants.StatusServerError, "获取用户列表失败", err.Error())
	}

	total := len(keys)

	// 计算分页
	start := (page - 1) * size
	end := start + size
	if start >= total {
		return []*models.User{}, total, nil
	}
	if end > total {
		end = total
	}

	// 获取分页数据
	users := make([]*models.User, 0, end-start)
	for i := start; i < end; i++ {
		var user models.User
		if err := r.db.Get(constants.BucketUsers, keys[i], &user); err != nil {
			continue
		}
		users = append(users, &user)
	}

	return users, total, nil
}

// ExistsByUsername 检查用户名是否存在
func (r *userRepository) ExistsByUsername(username string) bool {
	keys, err := r.db.ListKeys(constants.BucketUsers)
	if err != nil {
		return false
	}

	for _, key := range keys {
		var user models.User
		if err := r.db.Get(constants.BucketUsers, key, &user); err != nil {
			continue
		}
		if user.Username == username {
			return true
		}
	}

	return false
}

// UpdateStatus 更新用户状态
func (r *userRepository) UpdateStatus(userID string, status int) error {
	user, err := r.GetByID(userID)
	if err != nil {
		return err
	}

	user.Status = status
	return r.Update(user)
}

// UpdateScore 更新用户积分
func (r *userRepository) UpdateScore(userID string, scoreChange int) error {
	user, err := r.GetByID(userID)
	if err != nil {
		return err
	}

	user.Score += scoreChange
	if user.Score < 0 {
		user.Score = 0
	}

	// 重新计算等级
	user.CalculateLevel()

	return r.Update(user)
}

// GetTopPlayers 获取积分排行榜
func (r *userRepository) GetTopPlayers(limit int) ([]*models.User, error) {
	// 获取所有用户
	keys, err := r.db.ListKeys(constants.BucketUsers)
	if err != nil {
		return nil, appErrors.NewWithDetails(constants.StatusServerError, "获取排行榜失败", err.Error())
	}

	users := make([]*models.User, 0, len(keys))
	for _, key := range keys {
		var user models.User
		if err := r.db.Get(constants.BucketUsers, key, &user); err != nil {
			continue
		}
		users = append(users, &user)
	}

	// 按积分排序(冒泡排序，简单实现)
	for i := 0; i < len(users)-1; i++ {
		for j := 0; j < len(users)-1-i; j++ {
			if users[j].Score < users[j+1].Score {
				users[j], users[j+1] = users[j+1], users[j]
			}
		}
	}

	// 返回前limit个用户
	if limit > len(users) {
		limit = len(users)
	}

	return users[:limit], nil
}

// SearchByNickname 根据昵称搜索用户
func (r *userRepository) SearchByNickname(nickname string, page, size int) ([]*models.User, int, error) {
	// 获取所有用户
	keys, err := r.db.ListKeys(constants.BucketUsers)
	if err != nil {
		return nil, 0, appErrors.NewWithDetails(constants.StatusServerError, "搜索用户失败", err.Error())
	}

	// 筛选匹配的用户
	matchedUsers := make([]*models.User, 0)
	for _, key := range keys {
		var user models.User
		if err := r.db.Get(constants.BucketUsers, key, &user); err != nil {
			continue
		}

		// 简单的包含匹配
		if contains(user.Nickname, nickname) {
			matchedUsers = append(matchedUsers, &user)
		}
	}

	total := len(matchedUsers)

	// 计算分页
	start := (page - 1) * size
	end := start + size
	if start >= total {
		return []*models.User{}, total, nil
	}
	if end > total {
		end = total
	}

	return matchedUsers[start:end], total, nil
}

// 辅助函数

// generateDefaultAvatar 生成默认头像
func generateDefaultAvatar(username string) string {
	// 简单实现，可以集成实际的头像服务
	return fmt.Sprintf("https://api.dicebear.com/7.x/initials/svg?seed=%s", username)
}

// contains 检查字符串是否包含子字符串(忽略大小写)
func contains(s, substr string) bool {
	// 简单实现，将所有字符转为小写比较
	sLower := toLowerCase(s)
	substrLower := toLowerCase(substr)

	if len(substr) == 0 {
		return true
	}
	if len(substr) > len(s) {
		return false
	}

	for i := 0; i <= len(s)-len(substr); i++ {
		if sLower[i:i+len(substr)] == substrLower {
			return true
		}
	}
	return false
}

// toLowerCase 将字符串转为小写
func toLowerCase(s string) string {
	result := make([]rune, len(s))
	for i, r := range s {
		if r >= 'A' && r <= 'Z' {
			result[i] = r + 32
		} else {
			result[i] = r
		}
	}
	return string(result)
}
