package repositories

import (
	"encoding/json"
	"fmt"
	"time"

	"ai-game/internal/models"
	"ai-game/internal/utils"
	"ai-game/pkg/constants"
	appErrors "ai-game/pkg/errors"
	"ai-game/pkg/logger"

	bolt "go.etcd.io/bbolt"
)

// AIPlayerRepository AI玩家数据访问层接口
type AIPlayerRepository interface {
	Create(aiPlayer *models.AIPlayer) error
	GetByID(id string) (*models.AIPlayer, error)
	Update(aiPlayer *models.AIPlayer) error
	Delete(id string) error
	List(page, size int) ([]*models.AIPlayer, int, error)
	ListEnabled() ([]*models.AIPlayer, error)
	GetByPersonality(personality string) ([]*models.AIPlayer, error)
	UpdateStats(id string, stats *models.AIStats) error
	ExistsByName(name string) (bool, error)
}

// aiPlayerRepository AI玩家数据访问层实现
type aiPlayerRepository struct {
	db *bolt.DB
}

// NewAIPlayerRepository 创建AI玩家数据访问层实例
func NewAIPlayerRepository(db *bolt.DB) AIPlayerRepository {
	return &aiPlayerRepository{db: db}
}

// Create 创建AI玩家
func (r *aiPlayerRepository) Create(aiPlayer *models.AIPlayer) error {
	logger.Info("创建AI玩家: %s", aiPlayer.Name)

	return r.db.Update(func(tx *bolt.Tx) error {
		bucket := tx.Bucket([]byte(constants.BucketAIPlayers))
		if bucket == nil {
			return appErrors.ErrDatabaseOperation
		}

		// 检查ID是否已存在
		existing := bucket.Get([]byte(aiPlayer.ID))
		if existing != nil {
			return appErrors.New(constants.StatusBadRequest, "AI玩家ID已存在")
		}

		// 设置时间戳
		now := time.Now()
		aiPlayer.CreateAt = now
		aiPlayer.UpdateAt = now

		// 如果没有设置ID，生成一个
		if aiPlayer.ID == "" {
			aiPlayer.ID = utils.GenerateAIPlayerID()
		}

		// 序列化数据
		data, err := json.Marshal(aiPlayer)
		if err != nil {
			return fmt.Errorf("序列化AI玩家数据失败: %w", err)
		}

		// 存储数据
		if err := bucket.Put([]byte(aiPlayer.ID), data); err != nil {
			return fmt.Errorf("存储AI玩家数据失败: %w", err)
		}

		logger.Info("AI玩家创建成功: ID=%s, Name=%s", aiPlayer.ID, aiPlayer.Name)
		return nil
	})
}

// GetByID 根据ID获取AI玩家
func (r *aiPlayerRepository) GetByID(id string) (*models.AIPlayer, error) {
	logger.Debug("获取AI玩家: ID=%s", id)

	var aiPlayer *models.AIPlayer

	err := r.db.View(func(tx *bolt.Tx) error {
		bucket := tx.Bucket([]byte(constants.BucketAIPlayers))
		if bucket == nil {
			return appErrors.ErrDatabaseOperation
		}

		data := bucket.Get([]byte(id))
		if data == nil {
			return appErrors.ErrAIPlayerNotFound
		}

		aiPlayer = &models.AIPlayer{}
		if err := json.Unmarshal(data, aiPlayer); err != nil {
			return fmt.Errorf("反序列化AI玩家数据失败: %w", err)
		}

		return nil
	})

	if err != nil {
		return nil, err
	}

	logger.Debug("AI玩家获取成功: ID=%s, Name=%s", aiPlayer.ID, aiPlayer.Name)
	return aiPlayer, nil
}

// Update 更新AI玩家
func (r *aiPlayerRepository) Update(aiPlayer *models.AIPlayer) error {
	logger.Info("更新AI玩家: ID=%s, Name=%s", aiPlayer.ID, aiPlayer.Name)

	return r.db.Update(func(tx *bolt.Tx) error {
		bucket := tx.Bucket([]byte(constants.BucketAIPlayers))
		if bucket == nil {
			return appErrors.ErrDatabaseOperation
		}

		// 检查AI玩家是否存在
		existing := bucket.Get([]byte(aiPlayer.ID))
		if existing == nil {
			return appErrors.ErrAIPlayerNotFound
		}

		// 更新时间戳
		aiPlayer.UpdateAt = time.Now()

		// 序列化数据
		data, err := json.Marshal(aiPlayer)
		if err != nil {
			return fmt.Errorf("序列化AI玩家数据失败: %w", err)
		}

		// 更新数据
		if err := bucket.Put([]byte(aiPlayer.ID), data); err != nil {
			return fmt.Errorf("更新AI玩家数据失败: %w", err)
		}

		logger.Info("AI玩家更新成功: ID=%s", aiPlayer.ID)
		return nil
	})
}

// Delete 删除AI玩家
func (r *aiPlayerRepository) Delete(id string) error {
	logger.Info("删除AI玩家: ID=%s", id)

	return r.db.Update(func(tx *bolt.Tx) error {
		bucket := tx.Bucket([]byte(constants.BucketAIPlayers))
		if bucket == nil {
			return appErrors.ErrDatabaseOperation
		}

		// 检查AI玩家是否存在
		existing := bucket.Get([]byte(id))
		if existing == nil {
			return appErrors.ErrAIPlayerNotFound
		}

		// 删除数据
		if err := bucket.Delete([]byte(id)); err != nil {
			return fmt.Errorf("删除AI玩家数据失败: %w", err)
		}

		logger.Info("AI玩家删除成功: ID=%s", id)
		return nil
	})
}

// List 获取AI玩家列表(分页)
func (r *aiPlayerRepository) List(page, size int) ([]*models.AIPlayer, int, error) {
	logger.Debug("获取AI玩家列表: page=%d, size=%d", page, size)

	var aiPlayers []*models.AIPlayer
	var total int

	err := r.db.View(func(tx *bolt.Tx) error {
		bucket := tx.Bucket([]byte(constants.BucketAIPlayers))
		if bucket == nil {
			return appErrors.ErrDatabaseOperation
		}

		// 统计总数
		cursor := bucket.Cursor()
		for k, _ := cursor.First(); k != nil; k, _ = cursor.Next() {
			total++
		}

		// 计算分页参数
		if page < 1 {
			page = 1
		}
		if size < 1 {
			size = 10
		}

		offset := (page - 1) * size
		count := 0

		// 获取分页数据
		for k, v := cursor.First(); k != nil && len(aiPlayers) < size; k, v = cursor.Next() {
			if count < offset {
				count++
				continue
			}

			var aiPlayer models.AIPlayer
			if err := json.Unmarshal(v, &aiPlayer); err != nil {
				logger.Warn("反序列化AI玩家数据失败: %v", err)
				continue
			}

			aiPlayers = append(aiPlayers, &aiPlayer)
			count++
		}

		return nil
	})

	if err != nil {
		return nil, 0, err
	}

	logger.Debug("AI玩家列表获取成功: 总数=%d, 返回=%d", total, len(aiPlayers))
	return aiPlayers, total, nil
}

// ListEnabled 获取启用的AI玩家列表
func (r *aiPlayerRepository) ListEnabled() ([]*models.AIPlayer, error) {
	logger.Debug("获取启用的AI玩家列表")

	var aiPlayers []*models.AIPlayer

	err := r.db.View(func(tx *bolt.Tx) error {
		bucket := tx.Bucket([]byte(constants.BucketAIPlayers))
		if bucket == nil {
			return appErrors.ErrDatabaseOperation
		}

		cursor := bucket.Cursor()
		for k, v := cursor.First(); k != nil; k, v = cursor.Next() {
			var aiPlayer models.AIPlayer
			if err := json.Unmarshal(v, &aiPlayer); err != nil {
				logger.Warn("反序列化AI玩家数据失败: %v", err)
				continue
			}

			// 只返回启用的AI玩家
			if aiPlayer.IsEnabled() {
				aiPlayers = append(aiPlayers, &aiPlayer)
			}
		}

		return nil
	})

	if err != nil {
		return nil, err
	}

	logger.Debug("启用AI玩家列表获取成功: 数量=%d", len(aiPlayers))
	return aiPlayers, nil
}

// GetByPersonality 根据性格获取AI玩家
func (r *aiPlayerRepository) GetByPersonality(personality string) ([]*models.AIPlayer, error) {
	logger.Debug("根据性格获取AI玩家: personality=%s", personality)

	var aiPlayers []*models.AIPlayer

	err := r.db.View(func(tx *bolt.Tx) error {
		bucket := tx.Bucket([]byte(constants.BucketAIPlayers))
		if bucket == nil {
			return appErrors.ErrDatabaseOperation
		}

		cursor := bucket.Cursor()
		for k, v := cursor.First(); k != nil; k, v = cursor.Next() {
			var aiPlayer models.AIPlayer
			if err := json.Unmarshal(v, &aiPlayer); err != nil {
				logger.Warn("反序列化AI玩家数据失败: %v", err)
				continue
			}

			// 筛选指定性格的AI玩家
			if aiPlayer.Personality == personality && aiPlayer.IsEnabled() {
				aiPlayers = append(aiPlayers, &aiPlayer)
			}
		}

		return nil
	})

	if err != nil {
		return nil, err
	}

	logger.Debug("性格AI玩家获取成功: personality=%s, 数量=%d", personality, len(aiPlayers))
	return aiPlayers, nil
}

// UpdateStats 更新AI统计数据
func (r *aiPlayerRepository) UpdateStats(id string, stats *models.AIStats) error {
	logger.Debug("更新AI玩家统计: ID=%s", id)

	return r.db.Update(func(tx *bolt.Tx) error {
		bucket := tx.Bucket([]byte(constants.BucketAIPlayers))
		if bucket == nil {
			return appErrors.ErrDatabaseOperation
		}

		// 获取现有数据
		data := bucket.Get([]byte(id))
		if data == nil {
			return appErrors.ErrAIPlayerNotFound
		}

		var aiPlayer models.AIPlayer
		if err := json.Unmarshal(data, &aiPlayer); err != nil {
			return fmt.Errorf("反序列化AI玩家数据失败: %w", err)
		}

		// 更新统计数据
		aiPlayer.Stats = *stats
		aiPlayer.UpdateAt = time.Now()

		// 序列化并存储
		newData, err := json.Marshal(aiPlayer)
		if err != nil {
			return fmt.Errorf("序列化AI玩家数据失败: %w", err)
		}

		if err := bucket.Put([]byte(id), newData); err != nil {
			return fmt.Errorf("更新AI玩家统计失败: %w", err)
		}

		logger.Debug("AI玩家统计更新成功: ID=%s", id)
		return nil
	})
}

// ExistsByName 检查名称是否已存在
func (r *aiPlayerRepository) ExistsByName(name string) (bool, error) {
	logger.Debug("检查AI玩家名称是否存在: name=%s", name)

	var exists bool

	err := r.db.View(func(tx *bolt.Tx) error {
		bucket := tx.Bucket([]byte(constants.BucketAIPlayers))
		if bucket == nil {
			return appErrors.ErrDatabaseOperation
		}

		cursor := bucket.Cursor()
		for k, v := cursor.First(); k != nil; k, v = cursor.Next() {
			var aiPlayer models.AIPlayer
			if err := json.Unmarshal(v, &aiPlayer); err != nil {
				continue
			}

			if aiPlayer.Name == name {
				exists = true
				break
			}
		}

		return nil
	})

	if err != nil {
		return false, err
	}

	logger.Debug("AI玩家名称检查完成: name=%s, exists=%v", name, exists)
	return exists, nil
}
