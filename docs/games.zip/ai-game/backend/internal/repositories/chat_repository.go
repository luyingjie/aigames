package repositories

import (
	"encoding/json"
	"fmt"
	"time"

	"ai-game/internal/models"
	"ai-game/internal/utils"
	"ai-game/pkg/constants"
	appErrors "ai-game/pkg/errors"
	"ai-game/pkg/logger"

	bolt "go.etcd.io/bbolt"
)

// ChatRepository 聊天数据访问层接口
type ChatRepository interface {
	// 消息管理
	CreateMessage(message *models.ChatMessage) error
	GetMessage(id string) (*models.ChatMessage, error)
	UpdateMessage(message *models.ChatMessage) error
	DeleteMessage(id string) error

	// 房间消息查询
	GetRoomMessages(roomID string, page, size int) ([]*models.ChatMessage, int, error)
	GetRoomMessagesAfter(roomID string, after time.Time, limit int) ([]*models.ChatMessage, error)
	GetLatestRoomMessages(roomID string, limit int) ([]*models.ChatMessage, error)

	// 用户消息查询
	GetUserMessages(userID string, page, size int) ([]*models.ChatMessage, int, error)
	GetConversation(userID1, userID2 string, page, size int) ([]*models.ChatMessage, int, error)

	// 统计和管理
	CountRoomMessages(roomID string) (int, error)
	CountUserMessages(userID string) (int, error)
	GetMessageStats(roomID, userID string) (map[string]interface{}, error)
	CleanOldMessages(before time.Time) error
	GetMessagesByTimeRange(roomID string, start, end time.Time) ([]*models.ChatMessage, error)
}

// ChatMessage 聊天消息模型(别名，用于与 models.ChatMessageData 区分)
type ChatMessage = models.ChatMessage

// chatRepository 聊天数据访问层实现
type chatRepository struct {
	db *bolt.DB
}

// NewChatRepository 创建聊天数据访问层实例
func NewChatRepository(db *bolt.DB) ChatRepository {
	return &chatRepository{db: db}
}

// CreateMessage 创建聊天消息
func (r *chatRepository) CreateMessage(message *models.ChatMessage) error {
	logger.Debug("创建聊天消息: RoomID=%s, UserID=%s", message.RoomID, message.UserID)

	return r.db.Update(func(tx *bolt.Tx) error {
		bucket := tx.Bucket([]byte(constants.BucketChats))
		if bucket == nil {
			return appErrors.ErrDatabaseOperation
		}

		// 检查ID是否已存在
		existing := bucket.Get([]byte(message.ID))
		if existing != nil {
			return appErrors.New(constants.StatusBadRequest, "消息ID已存在")
		}

		// 设置时间戳
		now := time.Now()
		message.CreateAt = now
		message.UpdateAt = now

		// 如果没有设置ID，生成一个
		if message.ID == "" {
			message.ID = utils.GenerateMessageID()
		}

		// 序列化数据
		data, err := json.Marshal(message)
		if err != nil {
			return fmt.Errorf("序列化消息数据失败: %w", err)
		}

		// 存储数据
		if err := bucket.Put([]byte(message.ID), data); err != nil {
			return fmt.Errorf("存储消息数据失败: %w", err)
		}

		logger.Debug("聊天消息创建成功: ID=%s", message.ID)
		return nil
	})
}

// GetMessage 根据ID获取消息
func (r *chatRepository) GetMessage(id string) (*models.ChatMessage, error) {
	logger.Debug("获取聊天消息: ID=%s", id)

	var message *models.ChatMessage

	err := r.db.View(func(tx *bolt.Tx) error {
		bucket := tx.Bucket([]byte(constants.BucketChats))
		if bucket == nil {
			return appErrors.ErrDatabaseOperation
		}

		data := bucket.Get([]byte(id))
		if data == nil {
			return appErrors.New(constants.StatusNotFound, "消息不存在")
		}

		message = &models.ChatMessage{}
		if err := json.Unmarshal(data, message); err != nil {
			return fmt.Errorf("反序列化消息数据失败: %w", err)
		}

		return nil
	})

	if err != nil {
		return nil, err
	}

	logger.Debug("聊天消息获取成功: ID=%s", message.ID)
	return message, nil
}

// UpdateMessage 更新聊天消息
func (r *chatRepository) UpdateMessage(message *models.ChatMessage) error {
	logger.Debug("更新聊天消息: ID=%s", message.ID)

	return r.db.Update(func(tx *bolt.Tx) error {
		bucket := tx.Bucket([]byte(constants.BucketChats))
		if bucket == nil {
			return appErrors.ErrDatabaseOperation
		}

		// 检查消息是否存在
		existing := bucket.Get([]byte(message.ID))
		if existing == nil {
			return appErrors.New(constants.StatusNotFound, "消息不存在")
		}

		// 更新时间戳
		message.UpdateAt = time.Now()

		// 序列化数据
		data, err := json.Marshal(message)
		if err != nil {
			return fmt.Errorf("序列化消息数据失败: %w", err)
		}

		// 更新数据
		if err := bucket.Put([]byte(message.ID), data); err != nil {
			return fmt.Errorf("更新消息数据失败: %w", err)
		}

		logger.Debug("聊天消息更新成功: ID=%s", message.ID)
		return nil
	})
}

// DeleteMessage 删除聊天消息
func (r *chatRepository) DeleteMessage(id string) error {
	logger.Debug("删除聊天消息: ID=%s", id)

	return r.db.Update(func(tx *bolt.Tx) error {
		bucket := tx.Bucket([]byte(constants.BucketChats))
		if bucket == nil {
			return appErrors.ErrDatabaseOperation
		}

		// 检查消息是否存在
		existing := bucket.Get([]byte(id))
		if existing == nil {
			return appErrors.New(constants.StatusNotFound, "消息不存在")
		}

		// 删除数据
		if err := bucket.Delete([]byte(id)); err != nil {
			return fmt.Errorf("删除消息数据失败: %w", err)
		}

		logger.Debug("聊天消息删除成功: ID=%s", id)
		return nil
	})
}

// GetRoomMessages 获取房间消息列表(分页)
func (r *chatRepository) GetRoomMessages(roomID string, page, size int) ([]*models.ChatMessage, int, error) {
	logger.Debug("获取房间消息列表: RoomID=%s, page=%d, size=%d", roomID, page, size)

	var messages []*models.ChatMessage
	var total int

	err := r.db.View(func(tx *bolt.Tx) error {
		bucket := tx.Bucket([]byte(constants.BucketChats))
		if bucket == nil {
			return appErrors.ErrDatabaseOperation
		}

		// 收集房间的所有消息
		var roomMessages []*models.ChatMessage
		cursor := bucket.Cursor()

		for k, v := cursor.First(); k != nil; k, v = cursor.Next() {
			var message models.ChatMessage
			if err := json.Unmarshal(v, &message); err != nil {
				logger.Warn("反序列化消息数据失败: %v", err)
				continue
			}

			// 筛选指定房间且状态正常的消息
			if message.RoomID == roomID && message.Status == 1 {
				roomMessages = append(roomMessages, &message)
			}
		}

		total = len(roomMessages)

		// 按时间倒序排序(最新的在前面)
		for i := 0; i < len(roomMessages)-1; i++ {
			for j := i + 1; j < len(roomMessages); j++ {
				if roomMessages[i].CreateAt.Before(roomMessages[j].CreateAt) {
					roomMessages[i], roomMessages[j] = roomMessages[j], roomMessages[i]
				}
			}
		}

		// 计算分页
		if page < 1 {
			page = 1
		}
		if size < 1 {
			size = 20
		}

		start := (page - 1) * size
		end := start + size
		if start >= total {
			messages = []*models.ChatMessage{}
			return nil
		}
		if end > total {
			end = total
		}

		messages = roomMessages[start:end]
		return nil
	})

	if err != nil {
		return nil, 0, err
	}

	logger.Debug("房间消息列表获取成功: RoomID=%s, 总数=%d, 返回=%d", roomID, total, len(messages))
	return messages, total, nil
}

// GetRoomMessagesAfter 获取指定时间之后的房间消息
func (r *chatRepository) GetRoomMessagesAfter(roomID string, after time.Time, limit int) ([]*models.ChatMessage, error) {
	logger.Debug("获取房间新消息: RoomID=%s, after=%v", roomID, after)

	var messages []*models.ChatMessage

	err := r.db.View(func(tx *bolt.Tx) error {
		bucket := tx.Bucket([]byte(constants.BucketChats))
		if bucket == nil {
			return appErrors.ErrDatabaseOperation
		}

		cursor := bucket.Cursor()
		for k, v := cursor.First(); k != nil; k, v = cursor.Next() {
			var message models.ChatMessage
			if err := json.Unmarshal(v, &message); err != nil {
				continue
			}

			// 筛选指定房间、指定时间之后且状态正常的消息
			if message.RoomID == roomID && message.Status == 1 && message.CreateAt.After(after) {
				messages = append(messages, &message)
			}

			// 限制返回数量
			if limit > 0 && len(messages) >= limit {
				break
			}
		}

		return nil
	})

	if err != nil {
		return nil, err
	}

	// 按时间正序排序
	for i := 0; i < len(messages)-1; i++ {
		for j := i + 1; j < len(messages); j++ {
			if messages[i].CreateAt.After(messages[j].CreateAt) {
				messages[i], messages[j] = messages[j], messages[i]
			}
		}
	}

	logger.Debug("房间新消息获取成功: RoomID=%s, 数量=%d", roomID, len(messages))
	return messages, nil
}

// GetLatestRoomMessages 获取房间最新消息
func (r *chatRepository) GetLatestRoomMessages(roomID string, limit int) ([]*models.ChatMessage, error) {
	logger.Debug("获取房间最新消息: RoomID=%s, limit=%d", roomID, limit)

	var messages []*models.ChatMessage

	err := r.db.View(func(tx *bolt.Tx) error {
		bucket := tx.Bucket([]byte(constants.BucketChats))
		if bucket == nil {
			return appErrors.ErrDatabaseOperation
		}

		// 收集房间的所有消息
		var roomMessages []*models.ChatMessage
		cursor := bucket.Cursor()

		for k, v := cursor.First(); k != nil; k, v = cursor.Next() {
			var message models.ChatMessage
			if err := json.Unmarshal(v, &message); err != nil {
				continue
			}

			// 筛选指定房间且状态正常的消息
			if message.RoomID == roomID && message.Status == 1 {
				roomMessages = append(roomMessages, &message)
			}
		}

		// 按时间倒序排序
		for i := 0; i < len(roomMessages)-1; i++ {
			for j := i + 1; j < len(roomMessages); j++ {
				if roomMessages[i].CreateAt.Before(roomMessages[j].CreateAt) {
					roomMessages[i], roomMessages[j] = roomMessages[j], roomMessages[i]
				}
			}
		}

		// 取前limit条
		if limit > 0 && len(roomMessages) > limit {
			roomMessages = roomMessages[:limit]
		}

		messages = roomMessages
		return nil
	})

	if err != nil {
		return nil, err
	}

	logger.Debug("房间最新消息获取成功: RoomID=%s, 数量=%d", roomID, len(messages))
	return messages, nil
}

// GetUserMessages 获取用户消息列表
func (r *chatRepository) GetUserMessages(userID string, page, size int) ([]*models.ChatMessage, int, error) {
	logger.Debug("获取用户消息列表: UserID=%s, page=%d, size=%d", userID, page, size)

	var messages []*models.ChatMessage
	var total int

	err := r.db.View(func(tx *bolt.Tx) error {
		bucket := tx.Bucket([]byte(constants.BucketChats))
		if bucket == nil {
			return appErrors.ErrDatabaseOperation
		}

		// 收集用户的所有消息
		var userMessages []*models.ChatMessage
		cursor := bucket.Cursor()

		for k, v := cursor.First(); k != nil; k, v = cursor.Next() {
			var message models.ChatMessage
			if err := json.Unmarshal(v, &message); err != nil {
				continue
			}

			// 筛选指定用户且状态正常的消息
			if message.UserID == userID && message.Status == 1 {
				userMessages = append(userMessages, &message)
			}
		}

		total = len(userMessages)

		// 按时间倒序排序
		for i := 0; i < len(userMessages)-1; i++ {
			for j := i + 1; j < len(userMessages); j++ {
				if userMessages[i].CreateAt.Before(userMessages[j].CreateAt) {
					userMessages[i], userMessages[j] = userMessages[j], userMessages[i]
				}
			}
		}

		// 计算分页
		if page < 1 {
			page = 1
		}
		if size < 1 {
			size = 20
		}

		start := (page - 1) * size
		end := start + size
		if start >= total {
			messages = []*models.ChatMessage{}
			return nil
		}
		if end > total {
			end = total
		}

		messages = userMessages[start:end]
		return nil
	})

	if err != nil {
		return nil, 0, err
	}

	logger.Debug("用户消息列表获取成功: UserID=%s, 总数=%d, 返回=%d", userID, total, len(messages))
	return messages, total, nil
}

// GetConversation 获取两个用户之间的对话
func (r *chatRepository) GetConversation(userID1, userID2 string, page, size int) ([]*models.ChatMessage, int, error) {
	logger.Debug("获取用户对话: UserID1=%s, UserID2=%s", userID1, userID2)

	var messages []*models.ChatMessage
	var total int

	err := r.db.View(func(tx *bolt.Tx) error {
		bucket := tx.Bucket([]byte(constants.BucketChats))
		if bucket == nil {
			return appErrors.ErrDatabaseOperation
		}

		// 收集两个用户之间的消息
		var conversationMessages []*models.ChatMessage
		cursor := bucket.Cursor()

		for k, v := cursor.First(); k != nil; k, v = cursor.Next() {
			var message models.ChatMessage
			if err := json.Unmarshal(v, &message); err != nil {
				continue
			}

			// 筛选两个用户之间且状态正常的消息
			if message.Status == 1 &&
				((message.UserID == userID1) || (message.UserID == userID2)) {
				conversationMessages = append(conversationMessages, &message)
			}
		}

		total = len(conversationMessages)

		// 按时间正序排序
		for i := 0; i < len(conversationMessages)-1; i++ {
			for j := i + 1; j < len(conversationMessages); j++ {
				if conversationMessages[i].CreateAt.After(conversationMessages[j].CreateAt) {
					conversationMessages[i], conversationMessages[j] = conversationMessages[j], conversationMessages[i]
				}
			}
		}

		// 计算分页
		if page < 1 {
			page = 1
		}
		if size < 1 {
			size = 20
		}

		start := (page - 1) * size
		end := start + size
		if start >= total {
			messages = []*models.ChatMessage{}
			return nil
		}
		if end > total {
			end = total
		}

		messages = conversationMessages[start:end]
		return nil
	})

	if err != nil {
		return nil, 0, err
	}

	logger.Debug("用户对话获取成功: 总数=%d, 返回=%d", total, len(messages))
	return messages, total, nil
}

// CountRoomMessages 统计房间消息数量
func (r *chatRepository) CountRoomMessages(roomID string) (int, error) {
	var count int

	err := r.db.View(func(tx *bolt.Tx) error {
		bucket := tx.Bucket([]byte(constants.BucketChats))
		if bucket == nil {
			return appErrors.ErrDatabaseOperation
		}

		cursor := bucket.Cursor()
		for k, v := cursor.First(); k != nil; k, v = cursor.Next() {
			var message models.ChatMessage
			if err := json.Unmarshal(v, &message); err != nil {
				continue
			}

			if message.RoomID == roomID && message.Status == 1 {
				count++
			}
		}

		return nil
	})

	return count, err
}

// CountUserMessages 统计用户消息数量
func (r *chatRepository) CountUserMessages(userID string) (int, error) {
	var count int

	err := r.db.View(func(tx *bolt.Tx) error {
		bucket := tx.Bucket([]byte(constants.BucketChats))
		if bucket == nil {
			return appErrors.ErrDatabaseOperation
		}

		cursor := bucket.Cursor()
		for k, v := cursor.First(); k != nil; k, v = cursor.Next() {
			var message models.ChatMessage
			if err := json.Unmarshal(v, &message); err != nil {
				continue
			}

			if message.UserID == userID && message.Status == 1 {
				count++
			}
		}

		return nil
	})

	return count, err
}

// CleanOldMessages 清理旧消息
func (r *chatRepository) CleanOldMessages(before time.Time) error {
	logger.Info("清理旧消息: before=%v", before)

	var deleteCount int

	err := r.db.Update(func(tx *bolt.Tx) error {
		bucket := tx.Bucket([]byte(constants.BucketChats))
		if bucket == nil {
			return appErrors.ErrDatabaseOperation
		}

		cursor := bucket.Cursor()
		var toDelete [][]byte

		for k, v := cursor.First(); k != nil; k, v = cursor.Next() {
			var message models.ChatMessage
			if err := json.Unmarshal(v, &message); err != nil {
				continue
			}

			if message.CreateAt.Before(before) {
				toDelete = append(toDelete, append([]byte(nil), k...))
			}
		}

		// 删除标记的消息
		for _, key := range toDelete {
			if err := bucket.Delete(key); err != nil {
				logger.Warn("删除旧消息失败: %v", err)
				continue
			}
			deleteCount++
		}

		return nil
	})

	if err != nil {
		return err
	}

	logger.Info("旧消息清理完成: 删除=%d条", deleteCount)
	return nil
}

// GetMessagesByTimeRange 获取时间范围内的消息
func (r *chatRepository) GetMessagesByTimeRange(roomID string, start, end time.Time) ([]*models.ChatMessage, error) {
	logger.Debug("获取时间范围消息: RoomID=%s, start=%v, end=%v", roomID, start, end)

	var messages []*models.ChatMessage

	err := r.db.View(func(tx *bolt.Tx) error {
		bucket := tx.Bucket([]byte(constants.BucketChats))
		if bucket == nil {
			return appErrors.ErrDatabaseOperation
		}

		cursor := bucket.Cursor()
		for k, v := cursor.First(); k != nil; k, v = cursor.Next() {
			var message models.ChatMessage
			if err := json.Unmarshal(v, &message); err != nil {
				continue
			}

			// 筛选指定房间、时间范围内且状态正常的消息
			if message.RoomID == roomID && message.Status == 1 &&
				message.CreateAt.After(start) && message.CreateAt.Before(end) {
				messages = append(messages, &message)
			}
		}

		return nil
	})

	if err != nil {
		return nil, err
	}

	// 按时间正序排序
	for i := 0; i < len(messages)-1; i++ {
		for j := i + 1; j < len(messages); j++ {
			if messages[i].CreateAt.After(messages[j].CreateAt) {
				messages[i], messages[j] = messages[j], messages[i]
			}
		}
	}

	logger.Debug("时间范围消息获取成功: 数量=%d", len(messages))
	return messages, nil
}

// GetMessageStats 获取消息统计信息
func (r *chatRepository) GetMessageStats(roomID, userID string) (map[string]interface{}, error) {
	logger.Debug("获取消息统计: RoomID=%s, UserID=%s", roomID, userID)

	stats := make(map[string]interface{})
	var totalMessages, aiMessages, userMessages int

	err := r.db.View(func(tx *bolt.Tx) error {
		bucket := tx.Bucket([]byte(constants.BucketChats))
		if bucket == nil {
			return appErrors.ErrDatabaseOperation
		}

		cursor := bucket.Cursor()
		for k, v := cursor.First(); k != nil; k, v = cursor.Next() {
			var message models.ChatMessage
			if err := json.Unmarshal(v, &message); err != nil {
				continue
			}

			// 根据筛选条件计数
			if message.Status == 1 { // 只统计正常状态的消息
				// 如果指定了roomID，只统计该房间的消息
				if roomID != "" && message.RoomID != roomID {
					continue
				}

				// 如果指定了userID，只统计该用户的消息
				if userID != "" && message.UserID != userID {
					continue
				}

				totalMessages++
				if message.IsAI {
					aiMessages++
				} else {
					userMessages++
				}
			}
		}

		return nil
	})

	if err != nil {
		return nil, err
	}

	stats["total_messages"] = totalMessages
	stats["ai_messages"] = aiMessages
	stats["user_messages"] = userMessages

	// 计算AI消息占比
	if totalMessages > 0 {
		stats["ai_message_ratio"] = float64(aiMessages) / float64(totalMessages)
	} else {
		stats["ai_message_ratio"] = 0.0
	}

	logger.Debug("消息统计获取成功: total=%d, ai=%d, user=%d", totalMessages, aiMessages, userMessages)
	return stats, nil
}
