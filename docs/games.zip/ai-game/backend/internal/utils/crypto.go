package utils

import (
	"crypto/md5"
	"crypto/rand"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"time"

	"ai-game/pkg/constants"
	appErrors "ai-game/pkg/errors"

	"github.com/golang-jwt/jwt/v4"
	"golang.org/x/crypto/bcrypt"
)

// JWTClaims JWT声明
type JWTClaims struct {
	UserID   string `json:"user_id"`
	Username string `json:"username"`
	jwt.RegisteredClaims
}

// HashPassword 使用bcrypt哈希密码
func HashPassword(password string) (string, error) {
	bytes, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
	if err != nil {
		return "", fmt.Errorf("密码哈希失败: %w", err)
	}
	return string(bytes), nil
}

// CheckPassword 验证密码
func CheckPassword(password, hash string) bool {
	err := bcrypt.CompareHashAndPassword([]byte(hash), []byte(password))
	return err == nil
}

// GenerateToken 生成JWT令牌
func GenerateToken(userID, username, secret string, expireHours int) (string, error) {
	claims := JWTClaims{
		UserID:   userID,
		Username: username,
		RegisteredClaims: jwt.RegisteredClaims{
			ExpiresAt: jwt.NewNumericDate(time.Now().Add(time.Duration(expireHours) * time.Hour)),
			IssuedAt:  jwt.NewNumericDate(time.Now()),
			NotBefore: jwt.NewNumericDate(time.Now()),
			Issuer:    "ai-game",
		},
	}

	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	tokenString, err := token.SignedString([]byte(secret))
	if err != nil {
		return "", fmt.Errorf("生成令牌失败: %w", err)
	}

	return tokenString, nil
}

// ParseToken 解析JWT令牌
func ParseToken(tokenString, secret string) (*JWTClaims, error) {
	token, err := jwt.ParseWithClaims(tokenString, &JWTClaims{}, func(token *jwt.Token) (interface{}, error) {
		if _, ok := token.Method.(*jwt.SigningMethodHMAC); !ok {
			return nil, fmt.Errorf("意外的签名方法: %v", token.Header["alg"])
		}
		return []byte(secret), nil
	})

	if err != nil {
		return nil, fmt.Errorf("解析令牌失败: %w", err)
	}

	if claims, ok := token.Claims.(*JWTClaims); ok && token.Valid {
		return claims, nil
	}

	return nil, appErrors.ErrInvalidToken
}

// GenerateRandomString 生成随机字符串
func GenerateRandomString(length int) string {
	const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
	b := make([]byte, length)
	rand.Read(b)

	for i := range b {
		b[i] = charset[b[i]%byte(len(charset))]
	}
	return string(b)
}

// GenerateUserID 生成用户ID
func GenerateUserID() string {
	return GenerateRandomString(16)
}

// GenerateRoomID 生成房间ID
func GenerateRoomID() string {
	timestamp := time.Now().Unix()
	randomStr := GenerateRandomString(8)
	return fmt.Sprintf("%d_%s", timestamp, randomStr)
}

// GenerateGameID 生成游戏ID
func GenerateGameID() string {
	timestamp := time.Now().Unix()
	randomStr := GenerateRandomString(12)
	return fmt.Sprintf("game_%d_%s", timestamp, randomStr)
}

// GenerateAIPlayerID 生成AI玩家ID
func GenerateAIPlayerID() string {
	return "ai_" + GenerateRandomString(12)
}

// GenerateMessageID 生成消息ID
func GenerateMessageID() string {
	timestamp := time.Now().UnixNano()
	randomStr := GenerateRandomString(6)
	return fmt.Sprintf("msg_%d_%s", timestamp, randomStr)
}

// MD5Hash 计算MD5哈希
func MD5Hash(text string) string {
	hash := md5.Sum([]byte(text))
	return hex.EncodeToString(hash[:])
}

// SHA256Hash 计算SHA256哈希
func SHA256Hash(text string) string {
	hash := sha256.Sum256([]byte(text))
	return hex.EncodeToString(hash[:])
}

// GenerateAvatar 生成默认头像URL(基于用户名)
func GenerateAvatar(username string) string {
	// 使用Gravatar样式的默认头像
	hash := MD5Hash(username)
	return fmt.Sprintf("https://www.gravatar.com/avatar/%s?d=identicon&s=200", hash)
}

// ValidatePassword 验证密码强度
func ValidatePassword(password string) error {
	if len(password) < 6 {
		return appErrors.New(constants.StatusBadRequest, "密码长度不能少于6位")
	}
	if len(password) > 20 {
		return appErrors.New(constants.StatusBadRequest, "密码长度不能超过20位")
	}

	// 可以添加更多密码强度验证规则
	// 如：必须包含大小写字母、数字、特殊字符等

	return nil
}

// ValidateUsername 验证用户名
func ValidateUsername(username string) error {
	if len(username) < 3 {
		return appErrors.New(constants.StatusBadRequest, "用户名长度不能少于3位")
	}
	if len(username) > 20 {
		return appErrors.New(constants.StatusBadRequest, "用户名长度不能超过20位")
	}

	// 验证用户名字符
	for _, char := range username {
		if !((char >= 'a' && char <= 'z') ||
			(char >= 'A' && char <= 'Z') ||
			(char >= '0' && char <= '9') ||
			char == '_' || char == '-') {
			return appErrors.New(constants.StatusBadRequest, "用户名只能包含字母、数字、下划线和横线")
		}
	}

	return nil
}

// ValidateNickname 验证昵称
func ValidateNickname(nickname string) error {
	if len(nickname) < 2 {
		return appErrors.New(constants.StatusBadRequest, "昵称长度不能少于2位")
	}
	if len(nickname) > 20 {
		return appErrors.New(constants.StatusBadRequest, "昵称长度不能超过20位")
	}

	return nil
}

// SanitizeString 清理字符串(移除危险字符)
func SanitizeString(s string) string {
	// 移除HTML标签和脚本等危险内容
	// 这里做简单的处理，实际项目中可以使用更专业的库
	dangerousChars := []string{"<", ">", "&", "\"", "'", "`"}
	result := s

	for _, char := range dangerousChars {
		result = replaceAll(result, char, "")
	}

	return result
}

// replaceAll 简单的字符串替换函数
func replaceAll(s, old, new string) string {
	result := ""
	oldLen := len(old)

	for i := 0; i < len(s); {
		if i+oldLen <= len(s) && s[i:i+oldLen] == old {
			result += new
			i += oldLen
		} else {
			result += string(s[i])
			i++
		}
	}

	return result
}
