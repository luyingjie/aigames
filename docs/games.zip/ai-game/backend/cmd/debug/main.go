package main

import (
	"ai-game/internal/config"
	"ai-game/internal/database"
	"ai-game/internal/models"
	"ai-game/pkg/constants"
	"ai-game/pkg/logger"
	"fmt"
)

func main() {
	// 加载配置
	if err := config.LoadConfig(""); err != nil {
		logger.Fatal("加载配置失败: %v", err)
	}

	cfg := config.GetConfig()

	// 连接数据库
	db, err := database.NewDB(cfg.Database.Path)
	if err != nil {
		logger.Fatal("数据库连接失败: %v", err)
	}
	defer db.Close()

	// 获取所有用户
	keys, err := db.ListKeys(constants.BucketUsers)
	if err != nil {
		logger.Fatal("获取用户列表失败: %v", err)
	}

	fmt.Printf("数据库中有 %d 个用户:\n", len(keys))

	for _, key := range keys {
		var user models.User
		if err := db.Get(constants.BucketUsers, key, &user); err != nil {
			fmt.Printf("获取用户 %s 失败: %v\n", key, err)
			continue
		}

		fmt.Printf("用户ID: %s\n", user.ID)
		fmt.Printf("用户名: %s\n", user.Username)
		fmt.Printf("昵称: %s\n", user.Nickname)
		fmt.Printf("密码哈希: %s\n", user.Password)
		fmt.Printf("积分: %d\n", user.Score)
		fmt.Printf("状态: %d\n", user.Status)
		fmt.Println("---")
	}
}
