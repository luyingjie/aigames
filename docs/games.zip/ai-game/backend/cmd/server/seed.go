package main

import (
	"ai-game/internal/models"
	"ai-game/internal/repositories"
	"ai-game/pkg/logger"

	bolt "go.etcd.io/bbolt"
)

// seedAIPlayers 创建预设AI玩家
func seedAIPlayers(db *bolt.DB) error {
	logger.Info("开始创建预设AI玩家...")

	aiPlayerRepo := repositories.NewAIPlayerRepository(db)

	// 检查是否已经有AI玩家
	aiPlayers, _, err := aiPlayerRepo.List(1, 1)
	if err != nil {
		return err
	}

	if len(aiPlayers) > 0 {
		logger.Info("AI玩家已存在，跳过创建")
		return nil
	}

	// 预设AI玩家数据
	presetAIPlayers := []*models.AIPlayer{
		{
			ID:          "ai_aggressive_001",
			Name:        "勇猛小虎",
			Avatar:      "https://www.gravatar.com/avatar/tiger?d=identicon&s=200",
			Personality: "aggressive",
			Level:       3,
			Description: "性格激进的AI玩家，喜欢主动出击，敢于冒险",
			Prompts:     models.DefaultPrompts(),
			Config:      models.DefaultAIConfig(),
			Stats:       models.AIStats{},
			Status:      1,
		},
		{
			ID:          "ai_conservative_001",
			Name:        "稳重老龟",
			Avatar:      "https://www.gravatar.com/avatar/turtle?d=identicon&s=200",
			Personality: "conservative",
			Level:       2,
			Description: "性格保守的AI玩家，谨慎稳重，注重防守",
			Prompts:     models.DefaultPrompts(),
			Config:      models.DefaultAIConfig(),
			Stats:       models.AIStats{},
			Status:      1,
		},
		{
			ID:          "ai_balanced_001",
			Name:        "智慧狐狸",
			Avatar:      "https://www.gravatar.com/avatar/fox?d=identicon&s=200",
			Personality: "balanced",
			Level:       4,
			Description: "性格平衡的AI玩家，攻守兼备，灵活应变",
			Prompts:     models.DefaultPrompts(),
			Config:      models.DefaultAIConfig(),
			Stats:       models.AIStats{},
			Status:      1,
		},
		{
			ID:          "ai_aggressive_002",
			Name:        "烈焰战神",
			Avatar:      "https://www.gravatar.com/avatar/fire?d=identicon&s=200",
			Personality: "aggressive",
			Level:       5,
			Description: "高级激进AI玩家，攻击性极强，常用炸弹",
			Prompts:     models.DefaultPrompts(),
			Config:      models.DefaultAIConfig(),
			Stats:       models.AIStats{},
			Status:      1,
		},
		{
			ID:          "ai_conservative_002",
			Name:        "沉稳山岳",
			Avatar:      "https://www.gravatar.com/avatar/mountain?d=identicon&s=200",
			Personality: "conservative",
			Level:       4,
			Description: "高级保守AI玩家，如山般稳重，防守严密",
			Prompts:     models.DefaultPrompts(),
			Config:      models.DefaultAIConfig(),
			Stats:       models.AIStats{},
			Status:      1,
		},
		{
			ID:          "ai_balanced_002",
			Name:        "机智神探",
			Avatar:      "https://www.gravatar.com/avatar/detective?d=identicon&s=200",
			Personality: "balanced",
			Level:       6,
			Description: "顶级平衡AI玩家，观察敏锐，策略多变",
			Prompts:     models.DefaultPrompts(),
			Config:      models.DefaultAIConfig(),
			Stats:       models.AIStats{},
			Status:      1,
		},
	}

	// 为每个AI设置个性化配置
	for _, aiPlayer := range presetAIPlayers {
		switch aiPlayer.Personality {
		case "aggressive":
			// 激进型配置
			aiPlayer.Config.Strategy.Aggression = 0.8
			aiPlayer.Config.Strategy.RiskTolerance = 0.7
			aiPlayer.Config.Strategy.BluffTendency = 0.6
			aiPlayer.Config.ChatFrequency = 0.4

		case "conservative":
			// 保守型配置
			aiPlayer.Config.Strategy.Aggression = 0.3
			aiPlayer.Config.Strategy.RiskTolerance = 0.3
			aiPlayer.Config.Strategy.BluffTendency = 0.2
			aiPlayer.Config.ChatFrequency = 0.2

		case "balanced":
			// 平衡型配置
			aiPlayer.Config.Strategy.Aggression = 0.5
			aiPlayer.Config.Strategy.RiskTolerance = 0.5
			aiPlayer.Config.Strategy.BluffTendency = 0.4
			aiPlayer.Config.ChatFrequency = 0.3
		}

		// 根据等级调整配置
		difficultyFactor := float64(aiPlayer.Level) / 10.0
		aiPlayer.Config.Strategy.Memory = 0.5 + difficultyFactor*0.4
		aiPlayer.Config.ThinkTime = 3 - aiPlayer.Level/2 // 高级AI思考更快

		// 创建AI玩家
		if err := aiPlayerRepo.Create(aiPlayer); err != nil {
			logger.Error("创建预设AI玩家失败: %s, 错误: %v", aiPlayer.Name, err)
			continue
		}

		logger.Info("创建预设AI玩家成功: %s (%s)", aiPlayer.Name, aiPlayer.Personality)
	}

	logger.Info("预设AI玩家创建完成")
	return nil
}
