package main

import (
	"context"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"ai-game/internal/config"
	"ai-game/internal/database"
	"ai-game/internal/handlers"
	"ai-game/internal/middleware"
	"ai-game/internal/repositories"
	"ai-game/internal/services"
	"ai-game/pkg/logger"

	"github.com/gin-gonic/gin"
)

func main() {
	// 加载配置
	if err := config.LoadConfig(""); err != nil {
		logger.Fatal("加载配置失败: %v", err)
	}

	cfg := config.GetConfig()

	// 确保必要的目录存在
	if err := cfg.EnsureDirs(); err != nil {
		logger.Fatal("创建目录失败: %v", err)
	}

	// 设置日志
	logger.SetLogFile(cfg.Log.FilePath)
	if cfg.IsDevelopment() {
		logger.SetLevel(logger.DEBUG)
	} else {
		logger.SetLevel(logger.INFO)
	}

	logger.Info("启动AI游戏服务器...")
	logger.Info("配置信息: 模式=%s, 端口=%d", cfg.Server.Mode, cfg.Server.Port)

	// 连接数据库
	db, err := database.NewDB(cfg.Database.Path)
	if err != nil {
		logger.Fatal("数据库连接失败: %v", err)
	}
	defer db.Close()

	// TODO: 创建预设AI玩家(稍后实现)
	// if err := seedAIPlayers(db.GetBoltDB()); err != nil {
	//     logger.Warn("创建预设AI玩家失败: %v", err)
	// }

	// 初始化仓储层
	userRepo := repositories.NewUserRepository(db)
	aiPlayerRepo := repositories.NewAIPlayerRepository(db.GetBoltDB())
	chatRepo := repositories.NewChatRepository(db.GetBoltDB())
	roomRepo := repositories.NewRoomRepository(db.GetBoltDB())
	gameRepo := repositories.NewGameRepository(db.GetBoltDB())

	// 初始化服务层
	userService := services.NewUserService(userRepo, cfg.JWT.Secret, cfg.JWT.ExpireTime)
	aiPlayerService := services.NewAIPlayerService(aiPlayerRepo)
	chatService := services.NewChatService(chatRepo, userRepo, aiPlayerRepo, aiPlayerService)
	gameService := services.NewGameService(roomRepo, gameRepo, userRepo)

	// 初始化处理器
	userHandler := handlers.NewUserHandler(userService)
	aiHandler := handlers.NewAIHandler(aiPlayerService)
	chatHandler := handlers.NewChatHandler(chatService, userService)
	websocketHandler := handlers.NewWebSocketHandler(chatService, userService, cfg)
	gameHandler := handlers.NewGameHandler(gameService, userService)

	// 设置Gin模式
	gin.SetMode(cfg.Server.Mode)

	// 创建路由器
	router := gin.New()

	// 添加中间件
	router.Use(middleware.CustomLoggerMiddleware())
	router.Use(gin.Recovery())
	router.Use(middleware.CustomCORSMiddleware())
	router.Use(middleware.DefaultRateLimit())

	// 设置路由
	setupRoutes(router, userHandler, aiHandler, chatHandler, websocketHandler, gameHandler, userService)

	// 创建HTTP服务器
	server := &http.Server{
		Addr:         cfg.GetServerAddress(),
		Handler:      router,
		ReadTimeout:  time.Duration(cfg.Server.ReadTimeout) * time.Second,
		WriteTimeout: time.Duration(cfg.Server.WriteTimeout) * time.Second,
		IdleTimeout:  time.Duration(cfg.Server.IdleTimeout) * time.Second,
	}

	// 启动服务器
	go func() {
		logger.Info("服务器启动在 http://%s", cfg.GetServerAddress())
		if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			logger.Fatal("服务器启动失败: %v", err)
		}
	}()

	// 等待中断信号
	quit := make(chan os.Signal, 1)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)
	<-quit

	logger.Info("正在关闭服务器...")

	// 优雅关闭服务器
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	if err := server.Shutdown(ctx); err != nil {
		logger.Error("服务器关闭失败: %v", err)
	}

	logger.Info("服务器已关闭")
}

// setupRoutes 设置路由
func setupRoutes(router *gin.Engine, userHandler *handlers.UserHandler, aiHandler *handlers.AIHandler, chatHandler *handlers.ChatHandler, websocketHandler *handlers.WebSocketHandler, gameHandler *handlers.GameHandler, userService services.UserService) {
	// API版本1
	v1 := router.Group("/api/v1")

	// 健康检查
	v1.GET("/health", func(c *gin.Context) {
		c.JSON(http.StatusOK, gin.H{
			"status": "ok",
			"time":   time.Now().Unix(),
		})
	})

	// 认证相关路由(无需认证)
	auth := v1.Group("/auth")
	auth.Use(middleware.AuthRateLimit())
	{
		auth.POST("/register", userHandler.Register)
		auth.POST("/login", userHandler.Login)
	}

	// 用户相关路由
	users := v1.Group("/users")
	{
		// 公开接口
		users.GET("/ranking", userHandler.GetTopPlayers)
		users.GET("/search", userHandler.SearchUsers)
		users.GET("/:id", userHandler.GetUserInfo)

		// 需要认证的接口
		authenticated := users.Group("")
		authenticated.Use(middleware.AuthMiddleware(userService))
		{
			authenticated.GET("/profile", userHandler.GetProfile)
			authenticated.PUT("/profile", userHandler.UpdateProfile)
			authenticated.POST("/logout", userHandler.Logout)
		}
	}

	// 管理员路由
	admin := v1.Group("/admin")
	admin.Use(middleware.AuthMiddleware(userService))
	admin.Use(middleware.AdminMiddleware())
	{
		admin.GET("/users", userHandler.GetUserList)
		admin.DELETE("/users/:id", userHandler.DeleteUser)
	}

	// WebSocket路由
	ws := v1.Group("/ws")
	{
		ws.GET("/connect", websocketHandler.HandleConnection)
	}

	// 聊天相关路由
	chat := v1.Group("/chat")
	chat.Use(middleware.AuthMiddleware(userService))
	{
		chat.POST("/send", chatHandler.SendMessage)
		chat.GET("/rooms/:room_id/messages", chatHandler.GetRoomMessages)
		chat.DELETE("/messages/:message_id", chatHandler.DeleteMessage)
		chat.GET("/users/:user_id/messages", chatHandler.GetUserMessages)
		chat.GET("/stats", chatHandler.GetChatStats)

		// 管理员功能
		adminChat := chat.Group("/admin")
		adminChat.Use(middleware.AdminMiddleware())
		{
			adminChat.POST("/ai/trigger", chatHandler.TriggerAIChat)
		}
	}

	// 游戏相关路由
	game := v1.Group("/game")
	game.Use(middleware.AuthMiddleware(userService))
	{
		game.GET("/rooms", gameHandler.GetRoomList)
		game.POST("/rooms", gameHandler.CreateRoom)
		game.POST("/rooms/:id/join", gameHandler.JoinRoom)
		game.POST("/rooms/:id/leave", gameHandler.LeaveRoom)
		game.GET("/rooms/:id/state", gameHandler.GetGameState)
		game.POST("/rooms/:id/start", gameHandler.StartGame)
		game.POST("/rooms/:id/bid", gameHandler.MakeBid)
		game.POST("/rooms/:id/play", gameHandler.PlayCards)
		game.POST("/rooms/:id/pass", gameHandler.Pass)
		game.POST("/rooms/:id/chat", gameHandler.SendChatMessage)
		game.GET("/rooms/:id/chat", gameHandler.GetChatMessages)
	}

	// AI相关路由
	ai := v1.Group("/ai")
	ai.Use(middleware.AuthMiddleware(userService))
	{
		// AI玩家管理
		ai.POST("/players", aiHandler.CreateAIPlayer)
		ai.GET("/players", aiHandler.ListAIPlayers)
		ai.GET("/players/enabled", aiHandler.ListEnabledAIPlayers)
		ai.GET("/players/personality/:personality", aiHandler.GetAIPlayersByPersonality)
		ai.GET("/players/:id", aiHandler.GetAIPlayer)
		ai.PUT("/players/:id", aiHandler.UpdateAIPlayer)
		ai.DELETE("/players/:id", aiHandler.DeleteAIPlayer)

		// AI配置管理
		ai.POST("/test-connection", aiHandler.TestAIConnection)
		ai.PUT("/players/:id/config", aiHandler.UpdateAIConfig)
		ai.PUT("/players/:id/prompts", aiHandler.UpdatePrompts)

		// AI统计
		ai.GET("/players/:id/stats", aiHandler.GetAIStats)

		// 默认配置和模板
		ai.GET("/default-prompts", aiHandler.GetDefaultPrompts)
		ai.GET("/default-config", aiHandler.GetDefaultConfig)
		ai.GET("/personality-types", aiHandler.GetPersonalityTypes)
	}
}
