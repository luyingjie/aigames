Set-Location C:\Code\ai-game\backend
go run cmd\server\main.go