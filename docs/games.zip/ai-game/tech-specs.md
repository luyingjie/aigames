# 斗地主AI游戏 - 技术规范文档

## 核心技术规范

### 1. 后端技术规范(Golang)

#### 1.1 开发环境要求
- Go版本: 1.21+
- Gin框架: v1.9+
- BoltDB: v1.3.7+
- WebSocket: gorilla/websocket

#### 1.2 代码规范
- 遵循Go官方代码规范
- 使用gofmt格式化代码
- 所有公共函数必须有中文注释
- 错误处理必须明确，不允许忽略错误
- 包名使用小写，文件名使用下划线命名

#### 1.3 项目结构规范
```go
// 示例：用户模型定义
type User struct {
    ID       string    `json:"id" bolt:"id"`           // 用户ID
    Username string    `json:"username" bolt:"username"` // 用户名
    Password string    `json:"-" bolt:"password"`       // 密码(不返回给前端)
    Nickname string    `json:"nickname" bolt:"nickname"` // 昵称
    Avatar   string    `json:"avatar" bolt:"avatar"`     // 头像URL
    Score    int       `json:"score" bolt:"score"`       // 游戏积分
    Level    int       `json:"level" bolt:"level"`       // 用户等级
    CreateAt time.Time `json:"create_at" bolt:"create_at"` // 创建时间
    UpdateAt time.Time `json:"update_at" bolt:"update_at"` // 更新时间
    Status   int       `json:"status" bolt:"status"`     // 用户状态: 0-离线 1-在线 2-游戏中
}
```

#### 1.4 API响应规范
```go
// 统一API响应格式
type Response struct {
    Code    int         `json:"code"`    // 响应码：200-成功，400-客户端错误，500-服务器错误
    Message string      `json:"message"` // 响应消息
    Data    interface{} `json:"data"`    // 响应数据
}

// 分页响应格式
type PageResponse struct {
    Code    int         `json:"code"`
    Message string      `json:"message"`
    Data    interface{} `json:"data"`
    Page    PageInfo    `json:"page"`
}

type PageInfo struct {
    Current  int `json:"current"`   // 当前页码
    Size     int `json:"size"`      // 每页数量
    Total    int `json:"total"`     // 总数量
    Pages    int `json:"pages"`     // 总页数
}
```

### 2. 斗地主游戏规则规范

#### 2.1 牌面定义
```go
// 牌面类型定义
type CardSuit int

const (
    Spades   CardSuit = 1 // 黑桃 ♠
    Hearts   CardSuit = 2 // 红桃 ♥  
    Diamonds CardSuit = 3 // 方片 ♦
    Clubs    CardSuit = 4 // 梅花 ♣
)

// 牌点数定义
type CardRank int

const (
    Rank3  CardRank = 3  // 3
    Rank4  CardRank = 4  // 4
    Rank5  CardRank = 5  // 5
    Rank6  CardRank = 6  // 6
    Rank7  CardRank = 7  // 7
    Rank8  CardRank = 8  // 8
    Rank9  CardRank = 9  // 9
    Rank10 CardRank = 10 // 10
    RankJ  CardRank = 11 // J
    RankQ  CardRank = 12 // Q
    RankK  CardRank = 13 // K
    RankA  CardRank = 14 // A
    Rank2  CardRank = 15 // 2
    RankLittleJoker CardRank = 16 // 小王
    RankBigJoker    CardRank = 17 // 大王
)

// 牌面结构
type Card struct {
    Suit CardSuit `json:"suit"` // 花色
    Rank CardRank `json:"rank"` // 点数
}
```

#### 2.2 出牌类型定义
```go
// 出牌类型
type PlayType int

const (
    TypeSingle     PlayType = 1  // 单张
    TypePair       PlayType = 2  // 对子
    TypeTriple     PlayType = 3  // 三张
    TypeTriplePair PlayType = 4  // 三带一对
    TypeTripleSingle PlayType = 5 // 三带一
    TypeStraight   PlayType = 6  // 顺子(5张以上连续)
    TypePairStraight PlayType = 7 // 连对(3对以上连续)
    TypeTripleStraight PlayType = 8 // 飞机不带翅膀
    TypeTripleStraightPair PlayType = 9 // 飞机带对子
    TypeTripleStraightSingle PlayType = 10 // 飞机带单张
    TypeFourDualPair PlayType = 11 // 四带两对
    TypeFourDualSingle PlayType = 12 // 四带两单
    TypeBomb       PlayType = 13 // 炸弹
    TypeJokerBomb  PlayType = 14 // 王炸
)
```

#### 2.3 游戏状态定义
```go
// 游戏阶段
type GamePhase int

const (
    PhaseWaiting    GamePhase = 0 // 等待玩家
    PhaseBidding    GamePhase = 1 // 叫地主阶段
    PhasePlaying    GamePhase = 2 // 出牌阶段
    PhaseFinished   GamePhase = 3 // 游戏结束
)

// 玩家角色
type PlayerRole int

const (
    RoleNone     PlayerRole = 0 // 未分配角色
    RoleLandlord PlayerRole = 1 // 地主
    RoleFarmer   PlayerRole = 2 // 农民
)
```

### 3. WebSocket消息协议规范

#### 3.1 消息格式
```go
// WebSocket消息结构
type WSMessage struct {
    Type      string      `json:"type"`       // 消息类型
    Action    string      `json:"action"`     // 操作动作
    Data      interface{} `json:"data"`       // 消息数据
    Timestamp int64       `json:"timestamp"`  // 时间戳
    RequestID string      `json:"request_id"` // 请求ID，用于响应匹配
}
```

#### 3.2 消息类型定义
```go
const (
    // 系统消息
    MsgTypeSystem = "system"
    ActionConnect = "connect"    // 连接建立
    ActionDisconnect = "disconnect" // 连接断开
    ActionHeartbeat = "heartbeat"   // 心跳检测
    
    // 房间相关
    MsgTypeRoom = "room"
    ActionJoinRoom = "join_room"     // 加入房间
    ActionLeaveRoom = "leave_room"   // 离开房间
    ActionRoomUpdate = "room_update" // 房间状态更新
    
    // 游戏相关
    MsgTypeGame = "game"
    ActionGameStart = "game_start"   // 游戏开始
    ActionGameEnd = "game_end"       // 游戏结束
    ActionBidLandlord = "bid_landlord" // 叫地主
    ActionPlayCards = "play_cards"   // 出牌
    ActionPass = "pass"              // 过牌
    ActionGameState = "game_state"   // 游戏状态同步
    
    // 聊天相关
    MsgTypeChat = "chat"
    ActionSendMessage = "send_message" // 发送消息
    ActionReceiveMessage = "receive_message" // 接收消息
)
```

### 4. AI Agent规范

#### 4.1 AI玩家配置
```go
// AI玩家配置
type AIPlayer struct {
    ID          string            `json:"id" bolt:"id"`
    Name        string            `json:"name" bolt:"name"`                   // AI玩家名称
    Avatar      string            `json:"avatar" bolt:"avatar"`               // 头像
    Personality string            `json:"personality" bolt:"personality"`     // 性格类型：aggressive(激进)、conservative(保守)、balanced(平衡)
    Level       int               `json:"level" bolt:"level"`                 // AI难度等级 1-10
    Prompts     map[string]string `json:"prompts" bolt:"prompts"`             // 提示词配置
    Config      AIConfig          `json:"config" bolt:"config"`               // AI配置参数
    Status      int               `json:"status" bolt:"status"`               // 状态：0-禁用 1-启用
    CreateAt    time.Time         `json:"create_at" bolt:"create_at"`
    UpdateAt    time.Time         `json:"update_at" bolt:"update_at"`
}

// AI配置参数
type AIConfig struct {
    APIKey       string  `json:"api_key"`       // AI API密钥
    Model        string  `json:"model"`         // 使用的AI模型
    Temperature  float64 `json:"temperature"`   // 创造性参数 0.0-2.0
    MaxTokens    int     `json:"max_tokens"`    // 最大token数
    ThinkTime    int     `json:"think_time"`    // 思考时间(秒)
    ChatEnabled  bool    `json:"chat_enabled"`  // 是否启用聊天
    ChatFrequency float64 `json:"chat_frequency"` // 聊天频率 0.0-1.0
}
```

#### 4.2 提示词模板规范
```go
// 提示词模板类型
const (
    PromptGameStrategy = "game_strategy" // 游戏策略提示词
    PromptBidding     = "bidding"       // 叫地主提示词  
    PromptPlaying     = "playing"       // 出牌提示词
    PromptChat        = "chat"          // 聊天提示词
    PromptPersonality = "personality"   // 性格描述提示词
)

// 提示词模板示例
var DefaultPrompts = map[string]string{
    PromptGameStrategy: `你是一个斗地主AI玩家，名字是{name}，性格是{personality}。
游戏规则：{rules}
当前手牌：{hand_cards}
已出牌历史：{play_history}
请分析当前局面并制定策略。`,
    
    PromptBidding: `当前是叫地主阶段，你需要决定是否叫地主。
底牌：{hole_cards}
你的手牌：{hand_cards}
其他玩家叫牌情况：{bid_history}
请决定：1-叫地主，0-不叫。只回答数字。`,
    
    PromptPlaying: `轮到你出牌，请选择要出的牌。
当前手牌：{hand_cards}
上家出牌：{last_play}
可选出牌：{valid_plays}
请选择出牌，格式：[牌面1,牌面2,...]，如果过牌则回答"pass"。`,
    
    PromptChat: `游戏进行中，你可以发送聊天消息。
你的性格：{personality}
当前游戏状态：{game_state}
最近聊天记录：{chat_history}
请生成一条聊天消息，体现你的性格。如果不想聊天，回答"none"。`,
}
```

### 5. 前端技术规范(Vue3)

#### 5.1 组件规范
```typescript
// Vue组件基础结构
<template>
  <!-- 模板内容 -->
</template>

<script setup lang="ts">
// 导入依赖
import { ref, reactive, computed, onMounted } from 'vue'
import type { ComponentType } from '@/types'

// 接口定义
interface Props {
  // 属性定义
}

interface Emits {
  // 事件定义
}

// 组件属性
const props = defineProps<Props>()
const emit = defineEmits<Emits>()

// 响应式数据
const state = reactive({
  // 状态数据
})

// 计算属性
const computedValue = computed(() => {
  // 计算逻辑
})

// 生命周期
onMounted(() => {
  // 初始化逻辑
})

// 方法定义
const handleAction = () => {
  // 方法实现
}
</script>

<style scoped>
/* 组件样式 */
</style>
```

#### 5.2 API服务规范
```typescript
// API响应类型定义
interface ApiResponse<T = any> {
  code: number
  message: string
  data: T
}

// API服务基类
class BaseAPI {
  private baseURL = import.meta.env.VITE_API_BASE_URL
  
  async request<T>(url: string, options?: RequestInit): Promise<ApiResponse<T>> {
    // 请求实现
  }
  
  async get<T>(url: string, params?: Record<string, any>): Promise<ApiResponse<T>> {
    // GET请求
  }
  
  async post<T>(url: string, data?: any): Promise<ApiResponse<T>> {
    // POST请求
  }
}
```

#### 5.3 状态管理规范(Pinia)
```typescript
// Store定义示例
import { defineStore } from 'pinia'

export const useGameStore = defineStore('game', {
  state: () => ({
    // 状态定义
    currentRoom: null as Room | null,
    gameState: 'waiting' as GameState,
    players: [] as Player[],
    handCards: [] as Card[],
  }),
  
  getters: {
    // 计算属性
    isPlaying: (state) => state.gameState === 'playing',
    currentPlayer: (state) => state.players.find(p => p.isCurrent),
  },
  
  actions: {
    // 异步操作
    async joinRoom(roomId: string) {
      // 加入房间逻辑
    },
    
    async playCards(cards: Card[]) {
      // 出牌逻辑
    },
    
    // 同步状态
    updateGameState(newState: GameState) {
      this.gameState = newState
    },
  },
})
```

### 6. 数据库设计规范(BoltDB)

#### 6.1 存储桶(Bucket)设计
```go
const (
    UsersBucket    = "users"     // 用户数据
    GamesBucket    = "games"     // 游戏记录
    RoomsBucket    = "rooms"     // 房间数据
    AIPlayersBucket = "ai_players" // AI玩家
    ChatsBucket    = "chats"     // 聊天记录
    ConfigsBucket  = "configs"   // 系统配置
)
```

#### 6.2 数据序列化规范
```go
// 使用JSON进行序列化存储
func (r *Repository) Save(bucket, key string, data interface{}) error {
    return r.db.Update(func(tx *bolt.Tx) error {
        b := tx.Bucket([]byte(bucket))
        if b == nil {
            return fmt.Errorf("bucket %s not found", bucket)
        }
        
        encoded, err := json.Marshal(data)
        if err != nil {
            return err
        }
        
        return b.Put([]byte(key), encoded)
    })
}

func (r *Repository) Get(bucket, key string, result interface{}) error {
    return r.db.View(func(tx *bolt.Tx) error {
        b := tx.Bucket([]byte(bucket))
        if b == nil {
            return fmt.Errorf("bucket %s not found", bucket)
        }
        
        data := b.Get([]byte(key))
        if data == nil {
            return fmt.Errorf("key %s not found", key)
        }
        
        return json.Unmarshal(data, result)
    })
}
```

### 7. 部署和运维规范

#### 7.1 Docker配置
```dockerfile
# 后端Dockerfile
FROM golang:1.21-alpine AS builder
WORKDIR /app
COPY go.mod go.sum ./
RUN go mod download
COPY . .
RUN go build -o main cmd/server/main.go

FROM alpine:latest
RUN apk --no-cache add ca-certificates
WORKDIR /root/
COPY --from=builder /app/main .
COPY --from=builder /app/configs ./configs
CMD ["./main"]
```

#### 7.2 环境配置
```yaml
# development.yaml
server:
  host: "0.0.0.0"
  port: 8080
  mode: "debug"

database:
  path: "./data/game.db"
  timeout: 5s

ai:
  default_model: "gpt-3.5-turbo"
  max_concurrent: 10
  timeout: 30s

websocket:
  read_buffer_size: 1024
  write_buffer_size: 1024
  heartbeat_interval: 30s
```

## 开发流程规范

### 1. Git工作流
- 主分支: main (生产环境)
- 开发分支: develop (开发环境)  
- 功能分支: feature/功能名称
- 修复分支: hotfix/问题描述

### 2. 代码提交规范
```
feat: 新功能
fix: 修复问题
docs: 文档更新
style: 代码格式调整
refactor: 代码重构
test: 测试相关
chore: 其他修改

示例: feat: 实现斗地主出牌逻辑
```

### 3. 测试要求
- 单元测试覆盖率 > 80%
- 所有API接口必须有集成测试
- 游戏核心逻辑必须有完整测试用例
- 前端组件需要有基础测试

### 4. 文档要求
- 所有API接口必须有文档
- 复杂业务逻辑需要有设计文档
- 部署和运维需要有操作手册
- 用户使用需要有操作指南

这套技术规范将确保整个项目的代码质量、可维护性和可扩展性。