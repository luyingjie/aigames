#!/usr/bin/env pwsh

# AI斗地主游戏部署脚本

param(
    [Parameter(Mandatory=$false)]
    [ValidateSet("dev", "prod")]
    [string]$Environment = "dev",
    
    [Parameter(Mandatory=$false)]
    [switch]$Build = $false,
    
    [Parameter(Mandatory=$false)]
    [switch]$Clean = $false
)

Write-Host "======================================" -ForegroundColor Cyan
Write-Host "AI斗地主游戏部署脚本" -ForegroundColor Cyan
Write-Host "环境: $Environment" -ForegroundColor Yellow
Write-Host "======================================" -ForegroundColor Cyan

# 项目根目录
$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ProjectRoot

# 清理函数
function Clean-Build {
    Write-Host "清理构建文件..." -ForegroundColor Yellow
    
    if (Test-Path "backend/main") {
        Remove-Item "backend/main" -Force
        Write-Host "删除后端构建文件" -ForegroundColor Green
    }
    
    if (Test-Path "frontend/dist") {
        Remove-Item "frontend/dist" -Recurse -Force
        Write-Host "删除前端构建文件" -ForegroundColor Green
    }
    
    if (Test-Path "data") {
        Remove-Item "data" -Recurse -Force
        Write-Host "删除数据目录" -ForegroundColor Green
    }
}

# 构建后端
function Build-Backend {
    Write-Host "构建后端服务..." -ForegroundColor Yellow
    
    Set-Location "backend"
    
    # 下载依赖
    go mod download
    if ($LASTEXITCODE -ne 0) {
        Write-Error "后端依赖下载失败"
        exit 1
    }
    
    # 构建
    if ($Environment -eq "prod") {
        $env:CGO_ENABLED = "1"
        $env:GOOS = "linux"
        go build -a -installsuffix cgo -o main cmd/server/main.go
    } else {
        go build -o main cmd/server/main.go
    }
    
    if ($LASTEXITCODE -ne 0) {
        Write-Error "后端构建失败"
        exit 1
    }
    
    Write-Host "后端构建成功" -ForegroundColor Green
    Set-Location $ProjectRoot
}

# 构建前端
function Build-Frontend {
    Write-Host "构建前端应用..." -ForegroundColor Yellow
    
    Set-Location "frontend"
    
    # 安装依赖
    npm install
    if ($LASTEXITCODE -ne 0) {
        Write-Error "前端依赖安装失败"
        exit 1
    }
    
    # 构建
    if ($Environment -eq "prod") {
        npm run build
    } else {
        Write-Host "开发环境跳过前端构建" -ForegroundColor Yellow
    }
    
    if ($LASTEXITCODE -ne 0) {
        Write-Error "前端构建失败"
        exit 1
    }
    
    Write-Host "前端构建成功" -ForegroundColor Green
    Set-Location $ProjectRoot
}

# 初始化环境
function Initialize-Environment {
    Write-Host "初始化环境..." -ForegroundColor Yellow
    
    # 创建必要目录
    $directories = @("data", "logs", "configs")
    foreach ($dir in $directories) {
        if (-not (Test-Path $dir)) {
            New-Item -ItemType Directory -Path $dir -Force | Out-Null
            Write-Host "创建目录: $dir" -ForegroundColor Green
        }
    }
    
    # 复制配置文件
    if (-not (Test-Path "configs/config.yaml")) {
        Copy-Item "configs/config.example.yaml" "configs/config.yaml" -Force
        Write-Host "复制配置文件" -ForegroundColor Green
    }
}

# 启动服务
function Start-Services {
    Write-Host "启动服务..." -ForegroundColor Yellow
    
    if ($Environment -eq "prod") {
        # 生产环境使用Docker
        docker-compose up -d
        if ($LASTEXITCODE -ne 0) {
            Write-Error "Docker服务启动失败"
            exit 1
        }
        Write-Host "Docker服务启动成功" -ForegroundColor Green
    } else {
        # 开发环境
        Write-Host "开发环境请手动启动服务:" -ForegroundColor Yellow
        Write-Host "后端: cd backend && go run cmd/server/main.go" -ForegroundColor Cyan
        Write-Host "前端: cd frontend && npm run dev" -ForegroundColor Cyan
    }
}

# 健康检查
function Test-Health {
    Write-Host "执行健康检查..." -ForegroundColor Yellow
    
    Start-Sleep -Seconds 5
    
    try {
        $response = Invoke-WebRequest -Uri "http://localhost:8081/api/v1/health" -TimeoutSec 10
        if ($response.StatusCode -eq 200) {
            Write-Host "后端服务健康检查通过" -ForegroundColor Green
        } else {
            Write-Warning "后端服务健康检查失败"
        }
    } catch {
        Write-Warning "无法连接到后端服务"
    }
    
    if ($Environment -eq "dev") {
        try {
            $response = Invoke-WebRequest -Uri "http://localhost:3000" -TimeoutSec 10
            if ($response.StatusCode -eq 200) {
                Write-Host "前端服务健康检查通过" -ForegroundColor Green
            } else {
                Write-Warning "前端服务健康检查失败"
            }
        } catch {
            Write-Warning "无法连接到前端服务"
        }
    }
}

# 主执行流程
try {
    if ($Clean) {
        Clean-Build
    }
    
    Initialize-Environment
    
    if ($Build) {
        Build-Backend
        Build-Frontend
    }
    
    Start-Services
    Test-Health
    
    Write-Host "======================================" -ForegroundColor Cyan
    Write-Host "部署完成!" -ForegroundColor Green
    Write-Host "======================================" -ForegroundColor Cyan
    
    if ($Environment -eq "dev") {
        Write-Host "访问地址:" -ForegroundColor Yellow
        Write-Host "前端: http://localhost:3000" -ForegroundColor Cyan
        Write-Host "后端: http://localhost:8081" -ForegroundColor Cyan
        Write-Host "API文档: http://localhost:8081/api/v1/health" -ForegroundColor Cyan
    } else {
        Write-Host "生产环境访问地址:" -ForegroundColor Yellow
        Write-Host "应用: http://localhost" -ForegroundColor Cyan
    }
    
} catch {
    Write-Error "部署失败: $_"
    exit 1
}