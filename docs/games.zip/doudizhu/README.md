code/
└── doudizhu/
    ├── cmd/
    │   └── server/
    │       └── main.go
    ├── internal/
    │   ├── game/
    │   │   ├── card.go
    │   │   ├── game.go
    │   │   └── ai.go
    │   ├── network/
    │   │   ├── connection.go
    │   │   └── manager.go
    │   ├── protocol/
    │   │   ├── codec.go
    │   │   ├── message.go
    │   │   └── router.go
    │   ├── room/
    │   │   └── room.go
    │   ├── player/
    │   │   └── player.go
    │   └── storage/
    │       ├── db.go
    │       └── models.go
    ├── pkg/
    │   └── utils/
    │       └── utils.go
    ├── go.mod
    └── README.md
