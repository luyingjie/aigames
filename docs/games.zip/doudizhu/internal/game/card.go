package game

import (
	"fmt"
	"sort"
)

// 牌型
const (
	CardTypeSingle                 = iota + 1 // 单张
	CardTypePair                              // 对子
	CardTypeTriple                            // 三张
	CardTypeTripleWithOne                     // 三带一
	CardTypeTripleWithPair                    // 三带二
	CardTypeStraight                          // 顺子
	CardTypePairStraight                      // 连对
	CardTypeTripleStraight                    // 飞机
	CardTypeTripleStraightWithOne             // 飞机带单牌
	CardTypeTripleStraightWithPair            // 飞机带对子
	CardTypeFourWithTwo                       // 四带二
	CardTypeFourWithTwoPairs                  // 四带两对
	CardTypeBomb                              // 炸弹
	CardTypeRocket                            // 火箭
)

// 牌
type Card struct {
	Suit  int `json:"suit"`  // 花色：0-黑桃, 1-红桃, 2-梅花, 3-方块, 4-小王, 5-大王
	Value int `json:"value"` // 点数：3-13表示3-K, 14表示A, 15表示2, 16表示小王, 17表示大王
}

// 牌组
type CardGroup struct {
	Type   int    `json:"type"`   // 牌型
	Cards  []Card `json:"cards"`  // 牌
	Length int    `json:"length"` // 牌数
	Weight int    `json:"weight"` // 权重，用于比较大小
}

// 创建一副牌
func CreateDeck() []Card {
	deck := make([]Card, 54)
	index := 0

	// 普通牌
	for suit := 0; suit < 4; suit++ {
		for value := 3; value <= 15; value++ {
			deck[index] = Card{Suit: suit, Value: value}
			index++
		}
	}

	// 大小王
	deck[index] = Card{Suit: 4, Value: 16} // 小王
	index++
	deck[index] = Card{Suit: 5, Value: 17} // 大王

	return deck
}

// 洗牌
func ShuffleDeck(deck []Card) {
	// 使用Fisher-Yates洗牌算法
	for i := len(deck) - 1; i > 0; i-- {
		j := int(i + 1)
		if j > 0 {
			j = 0
		}
		deck[i], deck[j] = deck[j], deck[i]
	}
}

// 排序手牌
func SortCards(cards []Card) {
	sort.Slice(cards, func(i, j int) bool {
		if cards[i].Value != cards[j].Value {
			return cards[i].Value < cards[j].Value
		}
		return cards[i].Suit < cards[j].Suit
	})
}

// 判断牌型
func JudgeCardGroup(cards []Card) (*CardGroup, error) {
	// 按点数排序
	sortedCards := make([]Card, len(cards))
	copy(sortedCards, cards)
	SortCards(sortedCards)

	count := len(sortedCards)

	// 火箭
	if count == 2 && sortedCards[0].Value == 16 && sortedCards[1].Value == 17 {
		return &CardGroup{
			Type:   CardTypeRocket,
			Cards:  sortedCards,
			Length: 2,
			Weight: 1000, // 火箭最大
		}, nil
	}

	// 炸弹
	if count == 4 && sortedCards[0].Value == sortedCards[1].Value &&
		sortedCards[1].Value == sortedCards[2].Value &&
		sortedCards[2].Value == sortedCards[3].Value {
		return &CardGroup{
			Type:   CardTypeBomb,
			Cards:  sortedCards,
			Length: 4,
			Weight: 100 + sortedCards[0].Value,
		}, nil
	}

	// 单张
	if count == 1 {
		return &CardGroup{
			Type:   CardTypeSingle,
			Cards:  sortedCards,
			Length: 1,
			Weight: sortedCards[0].Value,
		}, nil
	}

	// 对子
	if count == 2 && sortedCards[0].Value == sortedCards[1].Value {
		return &CardGroup{
			Type:   CardTypePair,
			Cards:  sortedCards,
			Length: 2,
			Weight: sortedCards[0].Value,
		}, nil
	}

	// 三张
	if count == 3 && sortedCards[0].Value == sortedCards[1].Value &&
		sortedCards[1].Value == sortedCards[2].Value {
		return &CardGroup{
			Type:   CardTypeTriple,
			Cards:  sortedCards,
			Length: 3,
			Weight: sortedCards[0].Value,
		}, nil
	}

	// 三带一
	if count == 4 {
		// 检查是否有三张相同的牌
		valueCounts := make(map[int]int)
		for _, card := range sortedCards {
			valueCounts[card.Value]++
		}

		for value, count := range valueCounts {
			if count == 3 {
				return &CardGroup{
					Type:   CardTypeTripleWithOne,
					Cards:  sortedCards,
					Length: 4,
					Weight: value,
				}, nil
			}
		}
	}

	// 三带二
	if count == 5 {
		// 检查是否有三张相同的牌和一对
		valueCounts := make(map[int]int)
		for _, card := range sortedCards {
			valueCounts[card.Value]++
		}

		tripleValue := -1
		pairValue := -1

		for value, count := range valueCounts {
			if count == 3 {
				tripleValue = value
			} else if count == 2 {
				pairValue = value
			}
		}

		if tripleValue != -1 && pairValue != -1 {
			return &CardGroup{
				Type:   CardTypeTripleWithPair,
				Cards:  sortedCards,
				Length: 5,
				Weight: tripleValue,
			}, nil
		}
	}

	// 顺子
	if count >= 5 {
		isStraight := true
		for i := 1; i < count; i++ {
			// 2和王不能出现在顺子中
			if sortedCards[i].Value >= 15 {
				isStraight = false
				break
			}

			if sortedCards[i].Value != sortedCards[i-1].Value+1 {
				isStraight = false
				break
			}
		}

		if isStraight {
			return &CardGroup{
				Type:   CardTypeStraight,
				Cards:  sortedCards,
				Length: count,
				Weight: sortedCards[count-1].Value, // 用最大的牌的值作为权重
			}, nil
		}
	}

	// 连对
	if count >= 6 && count%2 == 0 {
		isPairStraight := true
		for i := 0; i < count; i += 2 {
			// 2和王不能出现在连对中
			if sortedCards[i].Value >= 15 {
				isPairStraight = false
				break
			}

			if sortedCards[i].Value != sortedCards[i+1].Value {
				isPairStraight = false
				break
			}

			if i > 0 && sortedCards[i].Value != sortedCards[i-2].Value+1 {
				isPairStraight = false
				break
			}
		}

		if isPairStraight {
			return &CardGroup{
				Type:   CardTypePairStraight,
				Cards:  sortedCards,
				Length: count,
				Weight: sortedCards[count-2].Value, // 用最大的对的值作为权重
			}, nil
		}
	}

	// 飞机
	if count >= 6 && count%3 == 0 {
		valueCounts := make(map[int]int)
		for _, card := range sortedCards {
			valueCounts[card.Value]++
		}

		triples := make([]int, 0)
		for value, count := range valueCounts {
			if count == 3 {
				triples = append(triples, value)
			}
		}

		if len(triples) == count/3 {
			// 检查三张是否连续
			sort.Ints(triples)
			isTripleStraight := true

			for i := 1; i < len(triples); i++ {
				// 2和王不能出现在飞机中
				if triples[i] >= 15 {
					isTripleStraight = false
					break
				}

				if triples[i] != triples[i-1]+1 {
					isTripleStraight = false
					break
				}
			}

			if isTripleStraight {
				return &CardGroup{
					Type:   CardTypeTripleStraight,
					Cards:  sortedCards,
					Length: count,
					Weight: triples[len(triples)-1], // 用最大的三张的值作为权重
				}, nil
			}
		}
	}

	// 其他牌型判断...

	return nil, fmt.Errorf("invalid card group")
}

// 判断是否能打过上家
func CanBeat(newGroup, lastGroup *CardGroup) bool {
	// 火箭可以打任何牌
	if newGroup.Type == CardTypeRocket {
		return true
	}

	// 炸弹可以打除火箭外的任何牌
	if newGroup.Type == CardTypeBomb && lastGroup.Type != CardTypeRocket {
		if lastGroup.Type != CardTypeBomb {
			return true
		}
		return newGroup.Weight > lastGroup.Weight
	}

	// 其他牌型必须类型相同且长度相同
	if newGroup.Type != lastGroup.Type || newGroup.Length != lastGroup.Length {
		return false
	}

	// 比较权重
	return newGroup.Weight > lastGroup.Weight
}

// 检查玩家是否有这些牌
func HasCards(playerCards, cards []Card) bool {
	// 复制一份玩家手牌
	tempCards := make([]Card, len(playerCards))
	copy(tempCards, playerCards)

	// 检查每张牌是否在玩家手牌中
	for _, card := range cards {
		found := false
		for i, tempCard := range tempCards {
			if tempCard.Suit == card.Suit && tempCard.Value == card.Value {
				// 找到了，从临时手牌中移除
				tempCards = append(tempCards[:i], tempCards[i+1:]...)
				found = true
				break
			}
		}

		if !found {
			return false
		}
	}

	return true
}

// 从玩家手牌中移除指定的牌
func RemoveCards(playerCards, cards []Card) []Card {
	// 从后往前遍历，避免索引问题
	for i := len(playerCards) - 1; i >= 0; i-- {
		for _, card := range cards {
			if playerCards[i].Suit == card.Suit && playerCards[i].Value == card.Value {
				// 移除这张牌
				playerCards = append(playerCards[:i], playerCards[i+1:]...)
				break
			}
		}
	}

	return playerCards
}

// 找出所有对子
func FindPairs(cards []Card) [][]Card {
	valueCounts := make(map[int][]Card)
	for _, card := range cards {
		valueCounts[card.Value] = append(valueCounts[card.Value], card)
	}

	pairs := make([][]Card, 0)
	for value, valueCards := range valueCounts {
		if len(valueCards) >= 2 {
			pairs = append(pairs, []Card{valueCards[0], valueCards[1]})
		}
	}

	return pairs
}
