package game

import (
	"errors"
	"fmt"
	"math/rand"
	"sync"
	"time"

	"doudizhu/internal/player"
	"doudizhu/internal/room"
)

// 游戏状态
const (
	GameStatusWaiting  = iota // 等待中
	GameStatusDealing         // 发牌中
	GameStatusBidding         // 叫地主中
	GameStatusPlaying         // 出牌中
	GameStatusFinished        // 已结束
)

// 玩家游戏状态
type PlayerGameState struct {
	PlayerID   string `json:"player_id"`   // 玩家ID
	Cards      []Card `json:"cards"`       // 手牌
	IsLandlord bool   `json:"is_landlord"` // 是否是地主
	Score      int    `json:"score"`       // 得分
	IsReady    bool   `json:"is_ready"`    // 是否准备
	IsAI       bool   `json:"is_ai"`       // 是否是AI玩家
}

// 游戏实例
type Game struct {
	ID           string                      `json:"id"`             // 游戏ID
	RoomID       string                      `json:"room_id"`        // 房间ID
	Status       int                         `json:"status"`         // 游戏状态
	Players      map[string]*PlayerGameState `json:"players"`        // 玩家游戏状态
	CurrentTurn  string                      `json:"current_turn"`   // 当前回合玩家ID
	LandlordID   string                      `json:"landlord_id"`    // 地主ID
	LastPlay     *CardGroup                  `json:"last_play"`      // 上次出的牌
	LastPlayerID string                      `json:"last_player_id"` // 上次出牌的玩家ID
	BottomCards  []Card                      `json:"bottom_cards"`   // 底牌
	Round        int                         `json:"round"`          // 当前回合数
	Scores       map[string]int              `json:"scores"`         // 玩家得分
	BaseScore    int                         `json:"base_score"`     // 底分
	mutex        sync.RWMutex                `json:"-"`              // 读写锁
}

// 游戏管理器
type GameManager struct {
	games         map[string]*Game
	roomManager   *room.RoomManager
	playerManager *player.PlayerManager
	mutex         sync.RWMutex
}

// 创建新的游戏管理器
func NewGameManager(roomManager *room.RoomManager, playerManager *player.PlayerManager) *GameManager {
	return &GameManager{
		games:         make(map[string]*Game),
		roomManager:   roomManager,
		playerManager: playerManager,
	}
}

// 创建新游戏
func (gm *GameManager) CreateGame(roomID string, playerIDs []string, baseScore int) (*Game, error) {
	gm.mutex.Lock()
	defer gm.mutex.Unlock()

	// 检查房间是否存在
	_, err := gm.roomManager.GetRoom(roomID)
	if err != nil {
		return nil, fmt.Errorf("room not found: %v", err)
	}

	// 创建游戏实例
	game := &Game{
		ID:        generateGameID(),
		RoomID:    roomID,
		Status:    GameStatusWaiting,
		Players:   make(map[string]*PlayerGameState),
		Scores:    make(map[string]int),
		BaseScore: baseScore,
	}

	// 初始化玩家
	for _, playerID := range playerIDs {
		p, err := gm.playerManager.GetPlayer(playerID)
		if err != nil {
			return nil, fmt.Errorf("player not found: %v", err)
		}

		game.Players[playerID] = &PlayerGameState{
			PlayerID: playerID,
			Cards:    make([]Card, 0),
			IsReady:  false,
			IsAI:     false, // 默认不是AI，可以后续设置
		}
		game.Scores[playerID] = 0
	}

	// 保存游戏
	gm.games[game.ID] = game

	return game, nil
}

// 获取游戏
func (gm *GameManager) GetGame(gameID string) (*Game, error) {
	gm.mutex.RLock()
	defer gm.mutex.RUnlock()

	game, ok := gm.games[gameID]
	if !ok {
		return nil, errors.New("game not found")
	}

	return game, nil
}

// 开始游戏
func (gm *GameManager) StartGame(gameID string) error {
	gm.mutex.Lock()
	defer gm.mutex.Unlock()

	game, ok := gm.games[gameID]
	if !ok {
		return errors.New("game not found")
	}

	return game.Start()
}

// 叫地主
func (gm *GameManager) Bid(gameID, playerID string, bid bool) error {
	gm.mutex.RLock()
	game, ok := gm.games[gameID]
	gm.mutex.RUnlock()

	if !ok {
		return errors.New("game not found")
	}

	return game.Bid(playerID, bid)
}

// 出牌
func (gm *GameManager) PlayCards(gameID, playerID string, cards []Card) error {
	gm.mutex.RLock()
	game, ok := gm.games[gameID]
	gm.mutex.RUnlock()

	if !ok {
		return errors.New("game not found")
	}

	return game.PlayCards(playerID, cards)
}

// 不出
func (gm *GameManager) Pass(gameID, playerID string) error {
	gm.mutex.RLock()
	game, ok := gm.games[gameID]
	gm.mutex.RUnlock()

	if !ok {
		return errors.New("game not found")
	}

	return game.Pass(playerID)
}

// 删除游戏
func (gm *GameManager) DeleteGame(gameID string) error {
	gm.mutex.Lock()
	defer gm.mutex.Unlock()

	if _, ok := gm.games[gameID]; !ok {
		return errors.New("game not found")
	}

	delete(gm.games, gameID)
	return nil
}

// 开始游戏
func (g *Game) Start() error {
	g.mutex.Lock()
	defer g.mutex.Unlock()

	if g.Status != GameStatusWaiting {
		return errors.New("game is already started or finished")
	}

	// 检查是否所有玩家都准备好了
	for _, player := range g.Players {
		if !player.IsReady {
			return errors.New("not all players are ready")
		}
	}

	// 设置游戏状态为发牌中
	g.Status = GameStatusDealing

	// 洗牌和发牌
	g.dealCards()

	// 设置游戏状态为叫地主中
	g.Status = GameStatusBidding

	// 随机选择一个玩家开始叫地主
	playerIDs := make([]string, 0, len(g.Players))
	for id := range g.Players {
		playerIDs = append(playerIDs, id)
	}
	rand.Seed(time.Now().UnixNano())
	firstBidder := playerIDs[rand.Intn(len(playerIDs))]
	g.CurrentTurn = firstBidder

	// 通知玩家游戏开始
	g.notifyGameStart()

	return nil
}

// 洗牌和发牌
func (g *Game) dealCards() {
	// 创建一副牌
	deck := CreateDeck()

	// 洗牌
	ShuffleDeck(deck)

	// 发牌，每人17张，留3张底牌
	playerIDs := make([]string, 0, len(g.Players))
	for id := range g.Players {
		playerIDs = append(playerIDs, id)
	}

	for i := 0; i < 51; i++ {
		playerID := playerIDs[i%3]
		g.Players[playerID].Cards = append(g.Players[playerID].Cards, deck[i])
	}

	// 底牌
	g.BottomCards = deck[51:54]

	// 排序每个玩家的手牌
	for _, player := range g.Players {
		SortCards(player.Cards)
	}
}

// 叫地主
func (g *Game) Bid(playerID string, bid bool) error {
	g.mutex.Lock()
	defer g.mutex.Unlock()

	if g.Status != GameStatusBidding {
		return errors.New("not in bidding phase")
	}

	if playerID != g.CurrentTurn {
		return errors.New("not your turn")
	}

	if bid {
		// 玩家叫地主
		g.LandlordID = playerID
		g.Players[playerID].IsLandlord = true

		// 地主获得底牌
		g.Players[playerID].Cards = append(g.Players[playerID].Cards, g.BottomCards...)
		SortCards(g.Players[playerID].Cards)

		// 清空底牌
		g.BottomCards = make([]Card, 0)

		// 设置游戏状态为出牌中
		g.Status = GameStatusPlaying

		// 地主先出牌
		g.CurrentTurn = playerID

		// 通知所有玩家地主是谁
		g.notifyLandlord(playerID)
	} else {
		// 玩家不叫，轮到下一个玩家
		playerIDs := make([]string, 0, len(g.Players))
		for id := range g.Players {
			playerIDs = append(playerIDs, id)
		}

		// 找到当前玩家的索引
		currentIndex := -1
		for i, id := range playerIDs {
			if id == playerID {
				currentIndex = i
				break
			}
		}

		if currentIndex == -1 {
			return errors.New("player not found")
		}

		// 轮到下一个玩家
		nextIndex := (currentIndex + 1) % len(playerIDs)
		g.CurrentTurn = playerIDs[nextIndex]

		// 如果所有玩家都不叫，重新发牌
		if g.CurrentTurn == playerID {
			g.Status = GameStatusWaiting
			for _, player := range g.Players {
				player.IsReady = false
				player.Cards = make([]Card, 0)
			}
			g.notifyRestart()
			return nil
		}
	}

	// 通知玩家轮到谁叫地主
	g.notifyBidTurn(g.CurrentTurn)

	return nil
}

// 出牌
func (g *Game) PlayCards(playerID string, cards []Card) error {
	g.mutex.Lock()
	defer g.mutex.Unlock()

	if g.Status != GameStatusPlaying {
		return errors.New("not in playing phase")
	}

	if playerID != g.CurrentTurn {
		return errors.New("not your turn")
	}

	// 验证玩家是否有这些牌
	player := g.Players[playerID]
	if !HasCards(player.Cards, cards) {
		return errors.New("you don't have these cards")
	}

	// 判断牌型
	cardGroup, err := JudgeCardGroup(cards)
	if err != nil {
		return err
	}

	// 如果不是第一次出牌，需要比较大小
	if g.LastPlay != nil {
		if !CanBeat(cardGroup, g.LastPlay) {
			return errors.New("your cards cannot beat the last play")
		}
	}

	// 出牌成功，从玩家手牌中移除
	player.Cards = RemoveCards(player.Cards, cards)

	// 更新上次出牌信息
	g.LastPlay = cardGroup
	g.LastPlayerID = playerID

	// 检查玩家是否出完牌
	if len(player.Cards) == 0 {
		// 游戏结束
		g.Status = GameStatusFinished
		g.calculateScore(playerID)
		g.notifyGameEnd(playerID)
		return nil
	}

	// 轮到下一个玩家
	playerIDs := make([]string, 0, len(g.Players))
	for id := range g.Players {
		playerIDs = append(playerIDs, id)
	}

	// 找到当前玩家的索引
	currentIndex := -1
	for i, id := range playerIDs {
		if id == playerID {
			currentIndex = i
			break
		}
	}

	if currentIndex == -1 {
		return errors.New("player not found")
	}

	// 轮到下一个玩家
	nextIndex := (currentIndex + 1) % len(playerIDs)
	g.CurrentTurn = playerIDs[nextIndex]

	// 如果上次出牌是自己，或者没人要，清空上次出牌
	if g.LastPlayerID == g.CurrentTurn {
		g.LastPlay = nil
		g.LastPlayerID = ""
	}

	// 通知玩家出牌结果和轮到谁
	g.notifyPlayCards(playerID, cards)
	g.notifyTurn(g.CurrentTurn)

	// 如果下一个玩家是AI，自动出牌
	if g.Players[g.CurrentTurn].IsAI {
		go g.aiPlay(g.CurrentTurn)
	}

	return nil
}

// 不出
func (g *Game) Pass(playerID string) error {
	g.mutex.Lock()
	defer g.mutex.Unlock()

	if g.Status != GameStatusPlaying {
		return errors.New("not in playing phase")
	}

	if playerID != g.CurrentTurn {
		return errors.New("not your turn")
	}

	// 如果是第一次出牌，不能不出
	if g.LastPlay == nil {
		return errors.New("you must play cards")
	}

	// 如果上次出牌是自己，不能不出
	if g.LastPlayerID == playerID {
		return errors.New("you must play cards")
	}

	// 轮到下一个玩家
	playerIDs := make([]string, 0, len(g.Players))
	for id := range g.Players {
		playerIDs = append(playerIDs, id)
	}

	// 找到当前玩家的索引
	currentIndex := -1
	for i, id := range playerIDs {
		if id == playerID {
			currentIndex = i
			break
		}
	}

	if currentIndex == -1 {
		return errors.New("player not found")
	}

	// 轮到下一个玩家
	nextIndex := (currentIndex + 1) % len(playerIDs)
	g.CurrentTurn = playerIDs[nextIndex]

	// 如果轮到上次出牌的玩家，清空上次出牌
	if g.CurrentTurn == g.LastPlayerID {
		g.LastPlay = nil
		g.LastPlayerID = ""
	}

	// 通知玩家不出和轮到谁
	g.notifyPass(playerID)
	g.notifyTurn(g.CurrentTurn)

	// 如果下一个玩家是AI，自动出牌
	if g.Players[g.CurrentTurn].IsAI {
		go g.aiPlay(g.CurrentTurn)
	}

	return nil
}

// AI出牌
func (g *Game) aiPlay(playerID string) {
	// 简单的AI逻辑
	player := g.Players[playerID]

	// 如果没有上次出牌，或者上次出牌是自己，出最小的单张
	if g.LastPlay == nil || g.LastPlayerID == playerID {
		// 找最小的牌
		minCard := player.Cards[0]
		g.PlayCards(playerID, []Card{minCard})
		return
	}

	// 尝试找到能打过上家的牌
	switch g.LastPlay.Type {
	case CardTypeSingle:
		// 找比上次出牌大的单张
		for _, card := range player.Cards {
			if card.Value > g.LastPlay.Cards[0].Value {
				g.PlayCards(playerID, []Card{card})
				return
			}
		}
	case CardTypePair:
		// 找对子
		pairs := FindPairs(player.Cards)
		for _, pair := range pairs {
			if pair[0].Value > g.LastPlay.Cards[0].Value {
				g.PlayCards(playerID, pair)
				return
			}
		}
		// ... 其他牌型处理
	}

	// 如果找不到合适的牌，不出
	g.Pass(playerID)
}

// 计算得分
func (g *Game) calculateScore(winnerID string) {
	// 地主获胜
	if g.Players[winnerID].IsLandlord {
		g.Scores[winnerID] += 2 * g.BaseScore
		for playerID, player := range g.Players {
			if !player.IsLandlord {
				g.Scores[playerID] -= g.BaseScore
			}
		}
	} else {
		// 农民获胜
		for playerID, player := range g.Players {
			if player.IsLandlord {
				g.Scores[playerID] -= 2 * g.BaseScore
			} else {
				g.Scores[playerID] += g.BaseScore
			}
		}
	}
}

// 通知游戏开始
func (g *Game) notifyGameStart() {
	// 实现通知逻辑
}

// 通知地主
func (g *Game) notifyLandlord(landlordID string) {
	// 实现通知逻辑
}

// 通知叫地主轮到谁
func (g *Game) notifyBidTurn(playerID string) {
	// 实现通知逻辑
}

// 通知出牌
func (g *Game) notifyPlayCards(playerID string, cards []Card) {
	// 实现通知逻辑
}

// 通知不出
func (g *Game) notifyPass(playerID string) {
	// 实现通知逻辑
}

// 通知轮到谁
func (g *Game) notifyTurn(playerID string) {
	// 实现通知逻辑
}

// 通知游戏结束
func (g *Game) notifyGameEnd(winnerID string) {
	// 实现通知逻辑
}

// 通知重新开始
func (g *Game) notifyRestart() {
	// 实现通知逻辑
}

// 生成游戏ID
func generateGameID() string {
	return "game_" + randomString(8)
}
