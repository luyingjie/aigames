package game

import (
	"math/rand"
	"sort"
	"time"
)

// AI策略接口
type AIStrategy interface {
	// 选择要出的牌
	SelectCards(game *Game, playerID string) ([]Card, bool)
}

// 随机AI策略
type RandomAIStrategy struct{}

func (s *RandomAIStrategy) SelectCards(game *Game, playerID string) ([]Card, bool) {
	player := game.Players[playerID]

	// 如果没有上次出牌，或者上次出牌是自己，出最小的单张
	if game.LastPlay == nil || game.LastPlayerID == playerID {
		// 找最小的牌
		minCard := player.Cards[0]
		return []Card{minCard}, true
	}

	// 尝试找到能打过上家的牌
	switch game.LastPlay.Type {
	case CardTypeSingle:
		// 找比上次出牌大的单张
		for _, card := range player.Cards {
			if card.Value > game.LastPlay.Cards[0].Value {
				return []Card{card}, true
			}
		}
	case CardTypePair:
		// 找对子
		pairs := FindPairs(player.Cards)
		for _, pair := range pairs {
			if pair[0].Value > game.LastPlay.Cards[0].Value {
				return pair, true
			}
		}
		// ... 其他牌型处理
	}

	// 如果找不到合适的牌，不出
	return nil, false
}

// 简单AI策略
type SimpleAIStrategy struct{}

func (s *SimpleAIStrategy) SelectCards(game *Game, playerID string) ([]Card, bool) {
	player := game.Players[playerID]

	// 如果没有上次出牌，或者上次出牌是自己，出最小的单张
	if game.LastPlay == nil || game.LastPlayerID == playerID {
		// 找最小的牌
		minCard := player.Cards[0]
		return []Card{minCard}, true
	}

	// 尝试找到能打过上家的牌
	switch game.LastPlay.Type {
	case CardTypeSingle:
		// 找比上次出牌大的单张，但尽量小
		var candidateCards []Card
		for _, card := range player.Cards {
			if card.Value > game.LastPlay.Cards[0].Value {
				candidateCards = append(candidateCards, card)
			}
		}

		if len(candidateCards) > 0 {
			// 选择最小的能打过的牌
			sort.Slice(candidateCards, func(i, j int) bool {
				return candidateCards[i].Value < candidateCards[j].Value
			})
			return []Card{candidateCards[0]}, true
		}

	case CardTypePair:
		// 找对子
		pairs := FindPairs(player.Cards)
		var candidatePairs [][]Card
		for _, pair := range pairs {
			if pair[0].Value > game.LastPlay.Cards[0].Value {
				candidatePairs = append(candidatePairs, pair)
			}
		}

		if len(candidatePairs) > 0 {
			// 选择最小的能打过的对子
			sort.Slice(candidatePairs, func(i, j int) bool {
				return candidatePairs[i][0].Value < candidatePairs[j][0].Value
			})
			return candidatePairs[0], true
		}

		// ... 其他牌型处理
	}

	// 如果找不到合适的牌，不出
	return nil, false
}

// 高级AI策略
type AdvancedAIStrategy struct{}

func (s *AdvancedAIStrategy) SelectCards(game *Game, playerID string) ([]Card, bool) {
	player := game.Players[playerID]

	// 如果没有上次出牌，或者上次出牌是自己，选择出牌策略
	if game.LastPlay == nil || game.LastPlayerID == playerID {
		// 分析手牌，决定出牌策略
		return s.selectOpeningCards(player)
	}

	// 尝试找到能打过上家的牌
	cards := s.findBeatingCards(player.Cards, game.LastPlay)
	if len(cards) > 0 {
		return cards, true
	}

	// 如果找不到合适的牌，不出
	return nil, false
}

// 选择开局出牌
func (s *AdvancedAIStrategy) selectOpeningCards(player *PlayerGameState) ([]Card, bool) {
	// 分析手牌，决定出牌策略

	// 1. 如果有炸弹，先不出炸弹，除非手牌很差
	// 2. 优先出单张，尤其是大牌
	// 3. 如果有火箭，先不出

	// 简单实现：出最小的单张
	minCard := player.Cards[0]
	return []Card{minCard}, true
}

// 找出能打过上家的牌
func (s *AdvancedAIStrategy) findBeatingCards(cards []Card, lastPlay *CardGroup) []Card {
	switch lastPlay.Type {
	case CardTypeSingle:
		// 找比上次出牌大的单张，但尽量小
		var candidateCards []Card
		for _, card := range cards {
			if card.Value > lastPlay.Cards[0].Value {
				candidateCards = append(candidateCards, card)
			}
		}

		if len(candidateCards) > 0 {
			// 选择最小的能打过的牌
			sort.Slice(candidateCards, func(i, j int) bool {
				return candidateCards[i].Value < candidateCards[j].Value
			})
			return []Card{candidateCards[0]}
		}

	case CardTypePair:
		// 找对子
		pairs := FindPairs(cards)
		var candidatePairs [][]Card
		for _, pair := range pairs {
			if pair[0].Value > lastPlay.Cards[0].Value {
				candidatePairs = append(candidatePairs, pair)
			}
		}

		if len(candidatePairs) > 0 {
			// 选择最小的能打过的对子
			sort.Slice(candidatePairs, func(i, j int) bool {
				return candidatePairs[i][0].Value < candidatePairs[j][0].Value
			})
			return candidatePairs[0]
		}

		// ... 其他牌型处理
	}

	return nil
}

// AI玩家
type AIPlayer struct {
	ID       string
	Strategy AIStrategy
}

// 创建AI玩家
func NewAIPlayer(id string, strategyType string) *AIPlayer {
	var strategy AIStrategy

	switch strategyType {
	case "random":
		strategy = &RandomAIStrategy{}
	case "simple":
		strategy = &SimpleAIStrategy{}
	case "advanced":
		strategy = &AdvancedAIStrategy{}
	default:
		strategy = &SimpleAIStrategy{} // 默认使用简单策略
	}

	return &AIPlayer{
		ID:       id,
		Strategy: strategy,
	}
}

// AI出牌
func (ai *AIPlayer) Play(game *Game) {
	// 添加随机延迟，模拟思考时间
	rand.Seed(time.Now().UnixNano())
	delay := time.Duration(1000+rand.Intn(2000)) * time.Millisecond
	time.Sleep(delay)

	// 使用策略选择要出的牌
	cards, shouldPlay := ai.Strategy.SelectCards(game, ai.ID)

	if shouldPlay {
		// 出牌
		game.PlayCards(ai.ID, cards)
	} else {
		// 不出
		game.Pass(ai.ID)
	}
}
