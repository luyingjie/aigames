package network

import (
	"errors"
	"log"
	"net/http"
	"sync"

	"doudizhu/internal/protocol"

	"github.com/gorilla/websocket"
)

// 连接管理器
type ConnectionManager struct {
	connections map[string]*Connection
	mutex       sync.RWMutex
	router      *protocol.Router
}

// 创建新的连接管理器
func NewConnectionManager() *ConnectionManager {
	return &ConnectionManager{
		connections: make(map[string]*Connection),
	}
}

// 设置路由器
func (cm *ConnectionManager) SetRouter(router *protocol.Router) {
	cm.router = router
}

// 添加连接
func (cm *ConnectionManager) Add(conn *Connection) {
	cm.mutex.Lock()
	defer cm.mutex.Unlock()

	cm.connections[conn.GetID()] = conn
	log.Printf("Connection added: %s, total connections: %d", conn.GetID(), len(cm.connections))
}

// 移除连接
func (cm *ConnectionManager) Remove(connID string) {
	cm.mutex.Lock()
	defer cm.mutex.Unlock()

	if conn, ok := cm.connections[connID]; ok {
		conn.Close()
		delete(cm.connections, connID)
		log.Printf("Connection removed: %s, total connections: %d", connID, len(cm.connections))
	}
}

// 获取连接
func (cm *ConnectionManager) Get(connID string) (*Connection, bool) {
	cm.mutex.RLock()
	defer cm.mutex.RUnlock()

	conn, ok := cm.connections[connID]
	return conn, ok
}

// 广播消息给所有连接
func (cm *ConnectionManager) Broadcast(msg interface{}) {
	cm.mutex.RLock()
	defer cm.mutex.RUnlock()

	for _, conn := range cm.connections {
		if err := conn.SendMessage(msg); err != nil {
			log.Printf("Failed to send message to connection %s: %v", conn.GetID(), err)
		}
	}
}

// 发送消息给指定连接
func (cm *ConnectionManager) SendTo(connID string, msg interface{}) error {
	cm.mutex.RLock()
	conn, ok := cm.connections[connID]
	cm.mutex.RUnlock()

	if !ok {
		return errors.New("connection not found")
	}

	return conn.SendMessage(msg)
}

// WebSocket升级器
var upgrader = websocket.Upgrader{
	CheckOrigin: func(r *http.Request) bool {
		return true // 允许所有来源，生产环境应该更严格
	},
}

// 处理WebSocket连接
func HandleWebSocket(w http.ResponseWriter, r *http.Request, connManager *ConnectionManager, router *protocol.Router) {
	// 升级HTTP连接为WebSocket连接
	wsConn, err := upgrader.Upgrade(w, r, nil)
	if err != nil {
		log.Printf("Failed to upgrade connection: %v", err)
		return
	}

	// 生成连接ID
	connID := generateConnID()

	// 创建连接对象
	conn := NewConnection(wsConn, connID)

	// 设置路由器
	connManager.SetRouter(router)

	// 添加连接到管理器
	connManager.Add(conn)

	// 启动连接
	conn.Start()

	// 连接关闭时从管理器中移除
	defer connManager.Remove(connID)

	// 等待连接关闭
	<-conn.closeChan
}

// 生成连接ID
func generateConnID() string {
	return "conn_" + randomString(16)
}
