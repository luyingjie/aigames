package network

import (
	"encoding/json"
	"errors"
	"sync"
	"time"

	"github.com/gorilla/websocket"
)

// WebSocket连接
type Connection struct {
	wsConn    *websocket.Conn
	connID    string
	closeChan chan byte
	mutex     sync.Mutex
	isClosed  bool
}

// 创建新连接
func NewConnection(wsConn *websocket.Conn, connID string) *Connection {
	return &Connection{
		wsConn:    wsConn,
		connID:    connID,
		closeChan: make(chan byte),
		isClosed:  false,
	}
}

// 获取连接ID
func (c *Connection) GetID() string {
	return c.connID
}

// 启动连接
func (c *Connection) Start() {
	// 启动读协程
	go c.readLoop()
	// 启动写协程
	go c.writeLoop()
}

// 关闭连接
func (c *Connection) Close() {
	c.mutex.Lock()
	defer c.mutex.Unlock()

	if c.isClosed {
		return
	}

	c.isClosed = true
	c.wsConn.Close()
	close(c.closeChan)
}

// 发送消息
func (c *Connection) SendMessage(msg interface{}) error {
	c.mutex.Lock()
	defer c.mutex.Unlock()

	if c.isClosed {
		return errors.New("connection is closed")
	}

	// 序列化消息
	data, err := json.Marshal(msg)
	if err != nil {
		return err
	}

	// 设置写超时
	c.wsConn.SetWriteDeadline(time.Now().Add(10 * time.Second))

	// 发送消息
	return c.wsConn.WriteMessage(websocket.TextMessage, data)
}

// 读取消息循环
func (c *Connection) readLoop() {
	defer c.Close()

	for {
		// 设置读超时
		c.wsConn.SetReadDeadline(time.Now().Add(60 * time.Second))

		// 读取消息
		_, message, err := c.wsConn.ReadMessage()
		if err != nil {
			// 如果是关闭错误，正常退出
			if websocket.IsUnexpectedCloseError(err, websocket.CloseGoingAway, websocket.CloseAbnormalClosure) {
				// 处理错误
			}
			break
		}

		// 处理消息
		c.handleMessage(message)
	}
}

// 写入消息循环
func (c *Connection) writeLoop() {
	ticker := time.NewTicker(30 * time.Second)
	defer func() {
		ticker.Stop()
		c.Close()
	}()

	for {
		select {
		case <-ticker.C:
			// 发送心跳
			c.wsConn.SetWriteDeadline(time.Now().Add(10 * time.Second))
			if err := c.wsConn.WriteMessage(websocket.PingMessage, nil); err != nil {
				return
			}
		case <-c.closeChan:
			return
		}
	}
}

// 处理消息
func (c *Connection) handleMessage(message []byte) {
	// 解析消息
	var msg map[string]interface{}
	if err := json.Unmarshal(message, &msg); err != nil {
		// 处理解析错误
		return
	}

	// 获取消息类型
	msgType, ok := msg["type"].(float64)
	if !ok {
		// 处理消息类型错误
		return
	}

	// 根据消息类型处理
	switch int(msgType) {
	case 1: // 心跳
		// 处理心跳消息
		c.handleHeartbeat()
	case 2: // 登录
		// 处理登录消息
		c.handleLogin(msg)
		// ... 其他消息类型
	}
}

// 处理心跳消息
func (c *Connection) handleHeartbeat() {
	// 更新连接活动时间
	// 可以在这里实现心跳响应逻辑
}

// 处理登录消息
func (c *Connection) handleLogin(msg map[string]interface{}) {
	// 解析登录信息
	username, ok := msg["username"].(string)
	if !ok {
		// 处理错误
		return
	}

	password, ok := msg["password"].(string)
	if !ok {
		// 处理错误
		return
	}

	// 处理登录逻辑
	// ...
}
