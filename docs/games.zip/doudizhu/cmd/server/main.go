package main

import (
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"

	"doudizhu/internal/game"
	"doudizhu/internal/network"
	"doudizhu/internal/player"
	"doudizhu/internal/protocol"
	"doudizhu/internal/room"
	"doudizhu/internal/storage"
)

func main() {
	// 初始化存储管理器
	dbConfig := storage.DBConfig{
		MongoDBURL:    "mongodb://localhost:27017",
		MongoDBName:   "doudizhu",
		RedisAddr:     "localhost:6379",
		RedisPassword: "",
		RedisDB:       0,
	}

	storageManager, err := storage.NewStorageManager(dbConfig)
	if err != nil {
		log.Fatalf("Failed to initialize storage manager: %v", err)
	}
	defer storageManager.Close()

	// 初始化玩家管理器
	playerManager := player.NewPlayerManager()

	// 初始化房间管理器
	roomManager := room.NewRoomManager()

	// 初始化协议路由
	router := protocol.NewRouter()

	// 注册消息处理器
	registerHandlers(router, playerManager, roomManager, storageManager)

	// 初始化网络管理器
	networkManager := network.NewConnectionManager()

	// 创建HTTP服务器，用于WebSocket连接
	server := &http.Server{
		Addr: ":8080",
		Handler: http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			// 处理WebSocket连接
			network.HandleWebSocket(w, r, networkManager, router)
		}),
	}

	// 启动服务器
	go func() {
		log.Println("Server starting on :8080")
		if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			log.Fatalf("Server error: %v", err)
		}
	}()

	// 等待中断信号
	quit := make(chan os.Signal, 1)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)
	<-quit

	log.Println("Server is shutting down...")

	// 关闭服务器
	if err := server.Close(); err != nil {
		log.Printf("Server shutdown error: %v", err)
	}

	log.Println("Server stopped")
}

// 注册消息处理器
func registerHandlers(
	router *protocol.Router,
	playerManager *player.PlayerManager,
	roomManager *room.RoomManager,
	storageManager *storage.StorageManager,
) {
	// 注册登录处理器
	router.Register(protocol.MsgTypeLogin, &protocol.LoginHandler{
		PlayerManager: playerManager,
		Storage:       storageManager,
	})

	// 注册加入房间处理器
	router.Register(protocol.MsgTypeJoinRoom, &protocol.JoinRoomHandler{
		PlayerManager: playerManager,
		RoomManager:   roomManager,
	})

	// 注册离开房间处理器
	router.Register(protocol.MsgTypeLeaveRoom, &protocol.LeaveRoomHandler{
		PlayerManager: playerManager,
		RoomManager:   roomManager,
	})

	// 注册游戏开始处理器
	router.Register(protocol.MsgTypeGameStart, &protocol.GameStartHandler{
		RoomManager: roomManager,
	})

	// 注册出牌处理器
	router.Register(protocol.MsgTypePlayCard, &protocol.PlayCardHandler{
		GameManager: game.NewGameManager(roomManager, playerManager),
	})

	// 注册不出处理器
	router.Register(protocol.MsgTypePass, &protocol.PassHandler{
		GameManager: game.NewGameManager(roomManager, playerManager),
	})

	// 注册叫地主处理器
	router.Register(protocol.MsgTypeBid, &protocol.BidHandler{
		GameManager: game.NewGameManager(roomManager, playerManager),
	})
}
