# 游戏平台服务器

基于 Nano 框架和 bbolt 数据库构建的轻量级游戏服务器，提供用户注册、登录等基础功能。

## 🚀 特性

- **轻量级架构**: 使用 Nano 框架构建高性能 WebSocket 游戏服务器
- **嵌入式数据库**: 集成 bbolt 键值数据库，无需外部依赖
- **用户系统**: 完整的用户注册、登录、认证功能
- **JWT 认证**: 基于 JWT Token 的无状态身份验证
- **WebSocket 通信**: 实时双向通信支持
- **密码安全**: 使用 bcrypt 进行密码哈希处理

## 📋 系统要求

- Go 1.18+
- Windows/Linux/macOS

## 🛠️ 安装与运行

### 1. 克隆项目

```bash
git clone <repository-url>
cd games
```

### 2. 安装依赖

```bash
go mod download
```

### 3. 启动服务器

```bash
go run cmd/server/main.go
```

服务器将启动在 `localhost:8080`，WebSocket 端点为 `/ws`

### 4. 测试功能

打开浏览器访问测试页面：
```
http://localhost:8080/static/test.html
```

## 📁 项目结构

```
games/
├── cmd/server/                 # 服务器入口
│   └── main.go                # 主程序文件
├── configs/                   # 配置文件
│   └── config.yaml           # 服务器配置
├── internal/                  # 内部包
│   ├── component/            # Nano 组件
│   │   ├── auth_component.go # JWT 认证组件
│   │   └── user_component.go # 用户管理组件
│   ├── database/             # 数据库操作
│   │   └── database.go       # bbolt 数据库封装
│   ├── model/                # 数据模型
│   │   └── models.go         # 数据结构定义
│   └── service/              # 业务逻辑
│       └── user_service.go   # 用户服务
├── web/static/               # 静态文件
│   └── test.html            # 功能测试页面
├── data/                     # 数据目录
│   └── games.db             # bbolt 数据库文件
├── go.mod                    # Go 模块文件
├── go.sum                    # 依赖校验文件
└── README.md                 # 项目说明
```

## 🔧 配置说明

### 服务器配置 (configs/config.yaml)

```yaml
server:
  host: "0.0.0.0"              # 服务器监听地址
  port: 8080                   # 服务器端口
  debug: true                  # 调试模式

database:
  path: "data/games.db"        # 数据库文件路径

jwt:
  secret: "your-secret-key"     # JWT 签名密钥 (生产环境请修改)
  expire_hours: 24             # Token 过期时间(小时)
```

## 📡 API 接口

### WebSocket 消息格式

所有 WebSocket 消息使用以下 JSON 格式：

```json
{
  "route": "组件.方法名",
  "参数名": "参数值",
  "token": "JWT令牌" // 需要认证的接口必须包含
}
```

### 用户接口

#### 1. 用户注册

**路由**: `user.Register`

**请求**:
```json
{
  "route": "user.Register",
  "username": "用户名",
  "password": "密码"
}
```

**响应**:
```json
{
  "code": 201,
  "message": "用户创建成功",
  "data": {
    "id": "用户ID",
    "username": "用户名",
    "created_at": "创建时间",
    "status": 0
  }
}
```

#### 2. 用户登录

**路由**: `user.Login`

**请求**:
```json
{
  "route": "user.Login",
  "username": "用户名",
  "password": "密码"
}
```

**响应**:
```json
{
  "code": 200,
  "message": "登录成功",
  "data": {
    "token": "JWT令牌",
    "user": {
      "id": "用户ID",
      "username": "用户名",
      "created_at": "创建时间",
      "status": 1
    }
  }
}
```

#### 3. 获取用户信息

**路由**: `user.GetUserInfo` (需要认证)

**请求**:
```json
{
  "route": "user.GetUserInfo",
  "token": "JWT令牌"
}
```

**响应**:
```json
{
  "code": 200,
  "message": "用户信息获取成功",
  "data": {
    "id": "用户ID",
    "username": "用户名",
    "created_at": "创建时间",
    "status": 1
  }
}
```

#### 4. 用户登出

**路由**: `user.Logout` (需要认证)

**请求**:
```json
{
  "route": "user.Logout",
  "token": "JWT令牌"
}
```

**响应**:
```json
{
  "code": 200,
  "message": "登出成功"
}
```

## 🧪 测试指南

### 使用内置测试页面

1. 启动服务器后，访问 `http://localhost:8080/static/test.html`
2. 页面会自动连接 WebSocket 服务器
3. 按以下顺序测试：
   - **注册**: 输入用户名(3-20字符)和密码(6-50字符)点击注册
   - **登录**: 使用注册的账号登录，成功后会自动保存 Token
   - **获取用户信息**: 点击获取用户信息按钮
   - **登出**: 点击登出按钮

### 错误处理

常见错误码：
- `400`: 请求参数无效
- `401`: 未授权访问（Token无效或缺失）
- `409`: 用户名已存在
- `500`: 服务器内部错误

## 🔐 安全注意事项

1. **生产环境配置**:
   - 修改 `configs/config.yaml` 中的 JWT 密钥
   - 设置 `debug: false`
   - 配置适当的 CORS 策略

2. **密码安全**:
   - 系统使用 bcrypt 进行密码哈希
   - 密码长度要求：6-50字符
   - 用户名长度要求：3-20字符

3. **Token 管理**:
   - JWT Token 默认24小时过期
   - Token 存储在客户端本地存储中
   - 登出时会清除本地 Token

## 🛡️ 技术栈

- **[Nano](https://github.com/lonng/nano)**: 轻量级游戏服务器框架
- **[bbolt](https://github.com/etcd-io/bbolt)**: 嵌入式键值数据库
- **[JWT](https://github.com/golang-jwt/jwt)**: JSON Web Token 认证
- **[bcrypt](https://golang.org/x/crypto/bcrypt)**: 密码哈希加密
- **WebSocket**: 实时双向通信

## 📈 扩展开发

### 添加新的游戏组件

1. 在 `internal/component/` 创建新组件文件
2. 实现 `nano` 的 `Component` 接口：
   ```go
   type YourComponent struct{}
   
   func (c *YourComponent) Init() {}
   func (c *YourComponent) AfterInit() {}
   func (c *YourComponent) BeforeShutdown() {}
   func (c *YourComponent) Shutdown() {}
   ```
3. 在 `main.go` 中注册组件

### 添加新的数据模型

1. 在 `internal/model/models.go` 中定义数据结构
2. 在 `internal/service/` 中添加对应的业务逻辑
3. 在组件中添加处理方法

## 🤝 贡献

欢迎提交 Issue 和 Pull Request 来改进这个项目！

## 📄 许可证

MIT License