package main

import (
	"fmt"
	"log"
	"net/http"
	"os"
	"os/signal"
	"path/filepath"
	"syscall"

	"games/internal/component"
	"games/internal/database"
	"games/internal/service"

	"github.com/lonng/nano"
	nanocomponent "github.com/lonng/nano/component"
	"github.com/lonng/nano/serialize/json"
	"gopkg.in/yaml.v2"
)

// Config 配置结构
type Config struct {
	Server struct {
		Host  string `yaml:"host"`
		Port  int    `yaml:"port"`
		Debug bool   `yaml:"debug"`
	} `yaml:"server"`
	Database struct {
		Path string `yaml:"path"`
	} `yaml:"database"`
	JWT struct {
		Secret      string `yaml:"secret"`
		ExpireHours int    `yaml:"expire_hours"`
	} `yaml:"jwt"`
}

// loadConfig 加载配置文件
func loadConfig(configPath string) (*Config, error) {
	data, err := os.ReadFile(configPath)
	if err != nil {
		return nil, fmt.Errorf("failed to read config file: %v", err)
	}

	var config Config
	if err := yaml.Unmarshal(data, &config); err != nil {
		return nil, fmt.Errorf("failed to parse config file: %v", err)
	}

	return &config, nil
}

func main() {
	// 加载配置
	config, err := loadConfig("configs/config.yaml")
	if err != nil {
		log.Fatalf("Failed to load config: %v", err)
	}

	// 确保数据目录存在
	dataDir := filepath.Dir(config.Database.Path)
	if err := os.MkdirAll(dataDir, 0755); err != nil {
		log.Fatalf("Failed to create data directory: %v", err)
	}

	// 初始化数据库
	db, err := database.New(config.Database.Path)
	if err != nil {
		log.Fatalf("Failed to initialize database: %v", err)
	}
	defer db.Close()

	// 初始化用户服务
	userService, err := service.NewUserService(db, config.JWT.Secret)
	if err != nil {
		log.Fatalf("Failed to create user service: %v", err)
	}

	// 初始化组件
	userComponent := component.NewUserComponent(userService)

	// 创建组件容器并注册组件
	components := &nanocomponent.Components{}
	components.Register(userComponent, nanocomponent.WithName("user"))

	// 配置和启动Nano服务器
	nano.Listen(fmt.Sprintf("%s:%d", config.Server.Host, config.Server.Port),
		nano.WithComponents(components),
		nano.WithIsWebsocket(true),
		nano.WithCheckOriginFunc(func(r *http.Request) bool {
			return true // 允许所有来源
		}),
		nano.WithWSPath("/ws"),
		nano.WithSerializer(json.NewSerializer()),
	)

	log.Printf("Game server starting on %s:%d", config.Server.Host, config.Server.Port)
	log.Printf("WebSocket endpoint: ws://%s:%d/ws", config.Server.Host, config.Server.Port)

	// 等待中断信号
	quit := make(chan os.Signal, 1)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)
	<-quit

	log.Println("Server shutting down...")
	nano.Shutdown()
	log.Println("Server shutdown complete")
}
