package component

import (
	"encoding/json"
	"fmt"
	"log"

	"games/internal/model"
	"games/internal/service"

	"github.com/lonng/nano/session"
)

// UserComponent 用户组件
type UserComponent struct {
	userService   *service.UserService
	authComponent *AuthComponent
}

// NewUserComponent 创建用户组件
func NewUserComponent(userService *service.UserService) *UserComponent {
	return &UserComponent{
		userService:   userService,
		authComponent: NewAuthComponent(userService),
	}
}

// Init 初始化组件
func (u *UserComponent) Init() {
	log.Println("UserComponent initialized")
}

// AfterInit 初始化后回调
func (u *UserComponent) AfterInit() {
	log.Println("UserComponent after init")
}

// BeforeShutdown 关闭前回调
func (u *UserComponent) BeforeShutdown() {
	log.Println("UserComponent before shutdown")
}

// Shutdown 关闭组件
func (u *UserComponent) Shutdown() {
	log.Println("UserComponent shutdown")
}

// Register 用户注册
func (u *UserComponent) Register(s *session.Session, msg []byte) error {
	var req model.RegisterRequest
	if err := json.Unmarshal(msg, &req); err != nil {
		return u.sendErrorResponse(s, 400, "invalid request format", err.Error())
	}

	user, err := u.userService.Register(&req)
	if err != nil {
		log.Printf("Register error: %v", err)
		return u.sendErrorResponse(s, 409, "registration failed", err.Error())
	}

	return u.sendSuccessResponse(s, 201, "user created successfully", user)
}

// Login 用户登录
func (u *UserComponent) Login(s *session.Session, msg []byte) error {
	var req model.LoginRequest
	if err := json.Unmarshal(msg, &req); err != nil {
		return u.sendErrorResponse(s, 400, "invalid request format", err.Error())
	}

	loginResp, err := u.userService.Login(&req)
	if err != nil {
		log.Printf("Login error: %v", err)
		return u.sendErrorResponse(s, 401, "login failed", err.Error())
	}

	// 绑定用户信息到会话
	s.Bind(1) // Nano会话需要int64类型

	return u.sendSuccessResponse(s, 200, "login successful", loginResp)
}

// GetUserInfo 获取用户信息 (需要认证)
func (u *UserComponent) GetUserInfo(s *session.Session, msg []byte) error {
	// 从消息中提取token
	token, err := u.authComponent.ExtractTokenFromMessage(msg)
	if err != nil || token == "" {
		return u.sendErrorResponse(s, 401, "unauthorized", "missing or invalid token")
	}

	// 验证JWT token
	user, err := u.userService.ValidateJWT(token)
	if err != nil {
		log.Printf("JWT validation error: %v", err)
		return u.sendErrorResponse(s, 401, "unauthorized", "invalid token")
	}

	return u.sendSuccessResponse(s, 200, "user info retrieved", user)
}

// Logout 用户登出 (需要认证)
func (u *UserComponent) Logout(s *session.Session, msg []byte) error {
	// 从消息中提取token
	token, err := u.authComponent.ExtractTokenFromMessage(msg)
	if err != nil || token == "" {
		return u.sendErrorResponse(s, 401, "unauthorized", "missing or invalid token")
	}

	// 验证JWT token
	user, err := u.userService.ValidateJWT(token)
	if err != nil {
		log.Printf("JWT validation error: %v", err)
		return u.sendErrorResponse(s, 401, "unauthorized", "invalid token")
	}

	if err := u.userService.Logout(user.Username); err != nil {
		log.Printf("Logout error: %v", err)
		return u.sendErrorResponse(s, 500, "logout failed", err.Error())
	}

	return u.sendSuccessResponse(s, 200, "logout successful", nil)
}

// sendSuccessResponse 发送成功响应
func (u *UserComponent) sendSuccessResponse(s *session.Session, code int, message string, data interface{}) error {
	response := model.APIResponse{
		Code:    code,
		Message: message,
		Data:    data,
	}

	responseData, err := json.Marshal(response)
	if err != nil {
		log.Printf("Failed to marshal response: %v", err)
		return err
	}

	return s.Response(responseData)
}

// sendErrorResponse 发送错误响应
func (u *UserComponent) sendErrorResponse(s *session.Session, code int, message string, error string) error {
	response := model.APIResponse{
		Code:    code,
		Message: message,
		Error:   error,
	}

	responseData, err := json.Marshal(response)
	if err != nil {
		log.Printf("Failed to marshal error response: %v", err)
		return fmt.Errorf("internal server error")
	}

	return s.Response(responseData)
}
