package component

import (
	"encoding/json"
	"log"
	"strings"

	"games/internal/model"
	"games/internal/service"

	"github.com/lonng/nano/session"
)

// AuthComponent JWT认证组件
type AuthComponent struct {
	userService *service.UserService
}

// NewAuthComponent 创建认证组件
func NewAuthComponent(userService *service.UserService) *AuthComponent {
	return &AuthComponent{
		userService: userService,
	}
}

// AuthMiddleware JWT认证中间件
func (a *AuthComponent) AuthMiddleware(s *session.Session, msg []byte) error {
	// 解析消息，查找token
	var requestData map[string]interface{}
	if err := json.Unmarshal(msg, &requestData); err != nil {
		return a.sendErrorResponse(s, 400, "invalid request format", err.Error())
	}

	token, ok := requestData["token"].(string)
	if !ok || token == "" {
		return a.sendErrorResponse(s, 401, "unauthorized", "missing or invalid token")
	}

	// 验证JWT token
	_, err := a.userService.ValidateJWT(token)
	if err != nil {
		log.Printf("JWT validation error: %v", err)
		return a.sendErrorResponse(s, 401, "unauthorized", "invalid token")
	}

	// 绑定用户信息到会话
	s.Bind(1) // Nano会话需要int64类型

	return nil
}

// RequireAuth 需要认证的装饰器函数
func (a *AuthComponent) RequireAuth(handler func(*session.Session, []byte) error) func(*session.Session, []byte) error {
	return func(s *session.Session, msg []byte) error {
		// 从消息中提取token
		token, err := a.ExtractTokenFromMessage(msg)
		if err != nil || token == "" {
			return a.sendErrorResponse(s, 401, "unauthorized", "missing or invalid token")
		}

		// 验证JWT token
		_, err = a.userService.ValidateJWT(token)
		if err != nil {
			log.Printf("JWT validation error: %v", err)
			return a.sendErrorResponse(s, 401, "unauthorized", "invalid token")
		}

		// 执行原始处理函数
		return handler(s, msg)
	}
}

// ExtractTokenFromMessage 从消息中提取token
func (a *AuthComponent) ExtractTokenFromMessage(msg []byte) (string, error) {
	var requestData map[string]interface{}
	if err := json.Unmarshal(msg, &requestData); err != nil {
		return "", err
	}

	token, ok := requestData["token"].(string)
	if !ok {
		return "", nil
	}

	// 如果token以"Bearer "开头，去掉前缀
	if strings.HasPrefix(token, "Bearer ") {
		token = token[7:]
	}

	return token, nil
}

// sendErrorResponse 发送错误响应
func (a *AuthComponent) sendErrorResponse(s *session.Session, code int, message string, error string) error {
	response := model.APIResponse{
		Code:    code,
		Message: message,
		Error:   error,
	}

	responseData, err := json.Marshal(response)
	if err != nil {
		log.Printf("Failed to marshal error response: %v", err)
		return err
	}

	return s.Response(responseData)
}
