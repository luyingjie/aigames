package model

import (
	"time"
)

// User 用户模型
type User struct {
	ID        string    `json:"id"`
	Username  string    `json:"username"`
	Password  string    `json:"-"` // 密码不在JSON中显示
	CreatedAt time.Time `json:"created_at"`
	UpdatedAt time.Time `json:"updated_at"`
	Status    int       `json:"status"` // 0-离线, 1-在线
}

// UserResponse 用户响应结构（不包含密码）
type UserResponse struct {
	ID        string    `json:"id"`
	Username  string    `json:"username"`
	CreatedAt time.Time `json:"created_at"`
	Status    int       `json:"status"`
}

// RegisterRequest 注册请求结构
type RegisterRequest struct {
	Username string `json:"username" binding:"required,min=3,max=20"`
	Password string `json:"password" binding:"required,min=6,max=50"`
}

// LoginRequest 登录请求结构
type LoginRequest struct {
	Username string `json:"username" binding:"required"`
	Password string `json:"password" binding:"required"`
}

// LoginResponse 登录响应结构
type LoginResponse struct {
	Token string       `json:"token"`
	User  UserResponse `json:"user"`
}

// APIResponse 统一API响应结构
type APIResponse struct {
	Code    int         `json:"code"`
	Message string      `json:"message"`
	Data    interface{} `json:"data,omitempty"`
	Error   string      `json:"error,omitempty"`
}

// Room 房间模型
type Room struct {
	ID         string    `json:"id"`
	Name       string    `json:"name"`
	CreatorID  string    `json:"creator_id"`
	Players    []string  `json:"players"`     // 玩家ID列表
	MaxPlayers int       `json:"max_players"` // 最大玩家数
	Status     string    `json:"status"`      // waiting, playing, finished
	CreatedAt  time.Time `json:"created_at"`
	UpdatedAt  time.Time `json:"updated_at"`
}

// GameSession 游戏会话模型
type GameSession struct {
	ID       string                 `json:"id"`
	RoomID   string                 `json:"room_id"`
	Players  []string               `json:"players"`
	Status   string                 `json:"status"` // started, finished
	GameData map[string]interface{} `json:"game_data"`
	StartAt  time.Time              `json:"start_at"`
	EndAt    *time.Time             `json:"end_at,omitempty"`
}
