package service

import (
	"fmt"
	"time"

	"games/internal/database"
	"games/internal/model"

	"github.com/bwmarrin/snowflake"
	"github.com/golang-jwt/jwt/v5"
	"golang.org/x/crypto/bcrypt"
)

// UserService 用户服务
type UserService struct {
	db        *database.Database
	jwtSecret []byte
	snowNode  *snowflake.Node
}

// NewUserService 创建用户服务
func NewUserService(db *database.Database, jwtSecret string) (*UserService, error) {
	// 创建雪花ID生成器
	node, err := snowflake.NewNode(1)
	if err != nil {
		return nil, fmt.Errorf("failed to create snowflake node: %v", err)
	}

	return &UserService{
		db:        db,
		jwtSecret: []byte(jwtSecret),
		snowNode:  node,
	}, nil
}

// Register 用户注册
func (s *UserService) Register(req *model.RegisterRequest) (*model.UserResponse, error) {
	// 检查用户名是否已存在
	if s.db.Exists(database.UsersBucket, req.Username) {
		return nil, fmt.Errorf("username already exists")
	}

	// 验证用户名长度
	if len(req.Username) < 3 || len(req.Username) > 20 {
		return nil, fmt.Errorf("username must be between 3 and 20 characters")
	}

	// 验证密码长度
	if len(req.Password) < 6 || len(req.Password) > 50 {
		return nil, fmt.Errorf("password must be between 6 and 50 characters")
	}

	// 加密密码
	hashedPassword, err := bcrypt.GenerateFromPassword([]byte(req.Password), bcrypt.DefaultCost)
	if err != nil {
		return nil, fmt.Errorf("failed to hash password: %v", err)
	}

	// 生成用户ID
	userID := s.snowNode.Generate().String()

	// 创建用户
	user := &model.User{
		ID:        userID,
		Username:  req.Username,
		Password:  string(hashedPassword),
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
		Status:    0, // 默认离线状态
	}

	// 保存用户到数据库
	if err := s.db.Put(database.UsersBucket, req.Username, user); err != nil {
		return nil, fmt.Errorf("failed to save user: %v", err)
	}

	// 返回用户信息（不包含密码）
	return &model.UserResponse{
		ID:        user.ID,
		Username:  user.Username,
		CreatedAt: user.CreatedAt,
		Status:    user.Status,
	}, nil
}

// Login 用户登录
func (s *UserService) Login(req *model.LoginRequest) (*model.LoginResponse, error) {
	// 从数据库获取用户
	var user model.User
	if err := s.db.Get(database.UsersBucket, req.Username, &user); err != nil {
		return nil, fmt.Errorf("invalid username or password")
	}

	// 验证密码
	if err := bcrypt.CompareHashAndPassword([]byte(user.Password), []byte(req.Password)); err != nil {
		return nil, fmt.Errorf("invalid username or password")
	}

	// 更新用户状态为在线
	user.Status = 1
	user.UpdatedAt = time.Now()
	if err := s.db.Put(database.UsersBucket, req.Username, &user); err != nil {
		return nil, fmt.Errorf("failed to update user status: %v", err)
	}

	// 生成JWT token
	token, err := s.generateJWT(user.ID, user.Username)
	if err != nil {
		return nil, fmt.Errorf("failed to generate token: %v", err)
	}

	return &model.LoginResponse{
		Token: token,
		User: model.UserResponse{
			ID:        user.ID,
			Username:  user.Username,
			CreatedAt: user.CreatedAt,
			Status:    user.Status,
		},
	}, nil
}

// GetUserByID 根据ID获取用户
func (s *UserService) GetUserByID(userID string) (*model.UserResponse, error) {
	var users []model.User
	if err := s.db.List(database.UsersBucket, &users); err != nil {
		return nil, fmt.Errorf("failed to list users: %v", err)
	}

	for _, user := range users {
		if user.ID == userID {
			return &model.UserResponse{
				ID:        user.ID,
				Username:  user.Username,
				CreatedAt: user.CreatedAt,
				Status:    user.Status,
			}, nil
		}
	}

	return nil, fmt.Errorf("user not found")
}

// GetUserByUsername 根据用户名获取用户
func (s *UserService) GetUserByUsername(username string) (*model.UserResponse, error) {
	var user model.User
	if err := s.db.Get(database.UsersBucket, username, &user); err != nil {
		return nil, fmt.Errorf("user not found")
	}

	return &model.UserResponse{
		ID:        user.ID,
		Username:  user.Username,
		CreatedAt: user.CreatedAt,
		Status:    user.Status,
	}, nil
}

// ValidateJWT 验证JWT token
func (s *UserService) ValidateJWT(tokenString string) (*model.UserResponse, error) {
	token, err := jwt.Parse(tokenString, func(token *jwt.Token) (interface{}, error) {
		if _, ok := token.Method.(*jwt.SigningMethodHMAC); !ok {
			return nil, fmt.Errorf("unexpected signing method: %v", token.Header["alg"])
		}
		return s.jwtSecret, nil
	})

	if err != nil {
		return nil, fmt.Errorf("invalid token: %v", err)
	}

	if claims, ok := token.Claims.(jwt.MapClaims); ok && token.Valid {
		userID, ok := claims["user_id"].(string)
		if !ok {
			return nil, fmt.Errorf("invalid token claims")
		}

		return s.GetUserByID(userID)
	}

	return nil, fmt.Errorf("invalid token")
}

// generateJWT 生成JWT token
func (s *UserService) generateJWT(userID, username string) (string, error) {
	claims := jwt.MapClaims{
		"user_id":  userID,
		"username": username,
		"exp":      time.Now().Add(time.Hour * 24).Unix(), // 24小时过期
		"iat":      time.Now().Unix(),
	}

	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	tokenString, err := token.SignedString(s.jwtSecret)
	if err != nil {
		return "", fmt.Errorf("failed to sign token: %v", err)
	}

	return tokenString, nil
}

// Logout 用户登出
func (s *UserService) Logout(username string) error {
	var user model.User
	if err := s.db.Get(database.UsersBucket, username, &user); err != nil {
		return fmt.Errorf("user not found")
	}

	// 更新用户状态为离线
	user.Status = 0
	user.UpdatedAt = time.Now()
	if err := s.db.Put(database.UsersBucket, username, &user); err != nil {
		return fmt.Errorf("failed to update user status: %v", err)
	}

	return nil
}
