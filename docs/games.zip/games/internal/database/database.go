package database

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"

	"go.etcd.io/bbolt"
)

// Database bbolt数据库封装
type Database struct {
	db *bbolt.DB
}

// 数据桶名称常量
const (
	UsersBucket = "users"
	GamesBucket = "games"
	RoomsBucket = "rooms"
)

// New 创建数据库连接
func New(dbPath string) (*Database, error) {
	// 确保数据库目录存在
	dir := filepath.Dir(dbPath)
	if err := os.MkdirAll(dir, 0755); err != nil {
		return nil, fmt.Errorf("failed to create database directory: %v", err)
	}

	db, err := bbolt.Open(dbPath, 0600, nil)
	if err != nil {
		return nil, fmt.Errorf("failed to open database: %v", err)
	}

	database := &Database{db: db}

	// 初始化数据桶
	if err := database.initBuckets(); err != nil {
		db.Close()
		return nil, fmt.Errorf("failed to initialize buckets: %v", err)
	}

	return database, nil
}

// initBuckets 初始化所有数据桶
func (d *Database) initBuckets() error {
	return d.db.Update(func(tx *bbolt.Tx) error {
		buckets := []string{UsersBucket, GamesBucket, RoomsBucket}
		for _, bucket := range buckets {
			if _, err := tx.CreateBucketIfNotExists([]byte(bucket)); err != nil {
				return fmt.Errorf("failed to create bucket %s: %v", bucket, err)
			}
		}
		return nil
	})
}

// Put 存储数据
func (d *Database) Put(bucket, key string, value interface{}) error {
	data, err := json.Marshal(value)
	if err != nil {
		return fmt.Errorf("failed to marshal value: %v", err)
	}

	return d.db.Update(func(tx *bbolt.Tx) error {
		b := tx.Bucket([]byte(bucket))
		if b == nil {
			return fmt.Errorf("bucket %s not found", bucket)
		}
		return b.Put([]byte(key), data)
	})
}

// Get 获取数据
func (d *Database) Get(bucket, key string, dest interface{}) error {
	return d.db.View(func(tx *bbolt.Tx) error {
		b := tx.Bucket([]byte(bucket))
		if b == nil {
			return fmt.Errorf("bucket %s not found", bucket)
		}

		data := b.Get([]byte(key))
		if data == nil {
			return fmt.Errorf("key %s not found in bucket %s", key, bucket)
		}

		return json.Unmarshal(data, dest)
	})
}

// Delete 删除数据
func (d *Database) Delete(bucket, key string) error {
	return d.db.Update(func(tx *bbolt.Tx) error {
		b := tx.Bucket([]byte(bucket))
		if b == nil {
			return fmt.Errorf("bucket %s not found", bucket)
		}
		return b.Delete([]byte(key))
	})
}

// List 列出桶中所有数据
func (d *Database) List(bucket string, dest interface{}) error {
	return d.db.View(func(tx *bbolt.Tx) error {
		b := tx.Bucket([]byte(bucket))
		if b == nil {
			return fmt.Errorf("bucket %s not found", bucket)
		}

		var items []json.RawMessage
		c := b.Cursor()
		for k, v := c.First(); k != nil; k, v = c.Next() {
			items = append(items, json.RawMessage(v))
		}

		data, err := json.Marshal(items)
		if err != nil {
			return fmt.Errorf("failed to marshal items: %v", err)
		}

		return json.Unmarshal(data, dest)
	})
}

// Exists 检查键是否存在
func (d *Database) Exists(bucket, key string) bool {
	exists := false
	d.db.View(func(tx *bbolt.Tx) error {
		b := tx.Bucket([]byte(bucket))
		if b == nil {
			return nil
		}
		exists = b.Get([]byte(key)) != nil
		return nil
	})
	return exists
}

// Close 关闭数据库连接
func (d *Database) Close() error {
	if d.db != nil {
		return d.db.Close()
	}
	return nil
}
