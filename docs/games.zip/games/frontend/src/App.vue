<template>
  <div id="app">
    <div class="container">
      <div v-if="!isLoggedIn" class="auth-section">
        <div class="tabs">
          <button 
            @click="activeTab = 'login'"
            :class="{ active: activeTab === 'login' }"
            class="tab-button"
          >
            登录
          </button>
          <button 
            @click="activeTab = 'register'"
            :class="{ active: activeTab === 'register' }"
            class="tab-button"
          >
            注册
          </button>
        </div>

        <!-- 登录表单 -->
        <div v-if="activeTab === 'login'" class="form-container">
          <h2>用户登录</h2>
          <form @submit.prevent="login">
            <div class="form-group">
              <label>用户名:</label>
              <input 
                v-model="loginForm.username" 
                type="text" 
                required 
                placeholder="请输入用户名"
              >
            </div>
            <div class="form-group">
              <label>密码:</label>
              <input 
                v-model="loginForm.password" 
                type="password" 
                required 
                placeholder="请输入密码"
              >
            </div>
            <button type="submit" :disabled="loading" class="submit-button">
              {{ loading ? '登录中...' : '登录' }}
            </button>
          </form>
        </div>

        <!-- 注册表单 -->
        <div v-if="activeTab === 'register'" class="form-container">
          <h2>用户注册</h2>
          <form @submit.prevent="register">
            <div class="form-group">
              <label>用户名:</label>
              <input 
                v-model="registerForm.username" 
                type="text" 
                required 
                placeholder="请输入用户名 (3-20字符)"
              >
            </div>
            <div class="form-group">
              <label>密码:</label>
              <input 
                v-model="registerForm.password" 
                type="password" 
                required 
                placeholder="请输入密码 (6-50字符)"
              >
            </div>
            <div class="form-group">
              <label>确认密码:</label>
              <input 
                v-model="confirmPassword" 
                type="password" 
                required 
                placeholder="请再次输入密码"
              >
            </div>
            <button type="submit" :disabled="loading" class="submit-button">
              {{ loading ? '注册中...' : '注册' }}
            </button>
          </form>
        </div>
      </div>

      <!-- 已登录状态 -->
      <div v-else class="user-section">
        <h2>欢迎, {{ user.username }}!</h2>
        <div class="user-info">
          <p><strong>用户ID:</strong> {{ user.id }}</p>
          <p><strong>注册时间:</strong> {{ formatDate(user.created_at) }}</p>
          <p><strong>状态:</strong> {{ user.status === 1 ? '在线' : '离线' }}</p>
        </div>
        <div class="actions">
          <button @click="getUserInfo" class="action-button">刷新用户信息</button>
          <button @click="logout" class="action-button logout-button">登出</button>
        </div>
      </div>

      <!-- 消息显示 -->
      <div v-if="message" :class="['message', messageType]">
        {{ message }}
      </div>

      <!-- WebSocket 连接状态 -->
      <div class="connection-status">
        <span :class="['status-indicator', wsConnected ? 'connected' : 'disconnected']"></span>
        {{ wsConnected ? '已连接' : '未连接' }}
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'App',
  data() {
    return {
      activeTab: 'login',
      isLoggedIn: false,
      loading: false,
      wsConnected: false,
      ws: null,
      token: localStorage.getItem('token') || '',
      user: {},
      message: '',
      messageType: 'info',
      loginForm: {
        username: '',
        password: ''
      },
      registerForm: {
        username: '',
        password: ''
      },
      confirmPassword: ''
    }
  },
  mounted() {
    if (this.token) {
      this.connectWebSocket()
      this.getUserInfo()
    }
  },
  methods: {
    connectWebSocket() {
      if (this.ws) {
        this.ws.close()
      }

      const wsUrl = 'ws://localhost:8080/ws'
      this.ws = new WebSocket(wsUrl)
      
      this.ws.onopen = () => {
        this.wsConnected = true
        console.log('WebSocket connected')
      }
      
      this.ws.onclose = () => {
        this.wsConnected = false
        console.log('WebSocket disconnected')
        // 重连逻辑
        if (this.isLoggedIn) {
          setTimeout(() => {
            this.connectWebSocket()
          }, 3000)
        }
      }
      
      this.ws.onerror = (error) => {
        console.error('WebSocket error:', error)
        this.showMessage('WebSocket连接错误', 'error')
      }
      
      this.ws.onmessage = (event) => {
        try {
          const response = JSON.parse(event.data)
          this.handleWebSocketResponse(response)
        } catch (error) {
          console.error('Failed to parse WebSocket message:', error)
        }
      }
    },

    sendWebSocketMessage(route, data) {
      if (this.ws && this.ws.readyState === WebSocket.OPEN) {
        const message = {
          route: route,
          ...data
        }
        this.ws.send(JSON.stringify(message))
      } else {
        this.showMessage('WebSocket未连接', 'error')
      }
    },

    handleWebSocketResponse(response) {
      if (response.code === 200 || response.code === 201) {
        this.showMessage(response.message, 'success')
        
        if (response.data) {
          // 处理不同类型的响应
          if (response.data.token) {
            // 登录响应
            this.token = response.data.token
            this.user = response.data.user
            this.isLoggedIn = true
            localStorage.setItem('token', this.token)
          } else if (response.data.username) {
            // 用户信息响应
            this.user = response.data
            this.isLoggedIn = true
          }
        }
      } else {
        this.showMessage(response.error || response.message, 'error')
      }
    },

    async register() {
      if (this.registerForm.password !== this.confirmPassword) {
        this.showMessage('两次输入的密码不一致', 'error')
        return
      }

      if (this.registerForm.username.length < 3 || this.registerForm.username.length > 20) {
        this.showMessage('用户名长度必须在3-20字符之间', 'error')
        return
      }

      if (this.registerForm.password.length < 6 || this.registerForm.password.length > 50) {
        this.showMessage('密码长度必须在6-50字符之间', 'error')
        return
      }

      this.loading = true
      
      if (!this.wsConnected) {
        this.connectWebSocket()
        // 等待连接建立
        await new Promise(resolve => {
          const checkConnection = () => {
            if (this.wsConnected) {
              resolve()
            } else {
              setTimeout(checkConnection, 100)
            }
          }
          checkConnection()
        })
      }

      this.sendWebSocketMessage('user.Register', this.registerForm)
      this.loading = false
    },

    async login() {
      this.loading = true
      
      if (!this.wsConnected) {
        this.connectWebSocket()
        // 等待连接建立
        await new Promise(resolve => {
          const checkConnection = () => {
            if (this.wsConnected) {
              resolve()
            } else {
              setTimeout(checkConnection, 100)
            }
          }
          checkConnection()
        })
      }

      this.sendWebSocketMessage('user.Login', this.loginForm)
      this.loading = false
    },

    getUserInfo() {
      if (this.token && this.wsConnected) {
        this.sendWebSocketMessage('user.GetUserInfo', { token: this.token })
      }
    },

    logout() {
      if (this.wsConnected) {
        this.sendWebSocketMessage('user.Logout', { token: this.token })
      }
      
      this.isLoggedIn = false
      this.user = {}
      this.token = ''
      localStorage.removeItem('token')
      
      if (this.ws) {
        this.ws.close()
      }
      
      this.showMessage('已成功登出', 'success')
    },

    showMessage(msg, type = 'info') {
      this.message = msg
      this.messageType = type
      setTimeout(() => {
        this.message = ''
      }, 3000)
    },

    formatDate(dateString) {
      return new Date(dateString).toLocaleString('zh-CN')
    }
  }
}
</script>

<style scoped>
.container {
  max-width: 500px;
  margin: 50px auto;
  padding: 20px;
  background: #f9f9f9;
  border-radius: 10px;
  box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}

.tabs {
  display: flex;
  margin-bottom: 20px;
}

.tab-button {
  flex: 1;
  padding: 10px;
  border: none;
  background: #e0e0e0;
  cursor: pointer;
  transition: background 0.3s;
}

.tab-button.active {
  background: #007bff;
  color: white;
}

.tab-button:hover {
  background: #d0d0d0;
}

.tab-button.active:hover {
  background: #0056b3;
}

.form-container {
  background: white;
  padding: 20px;
  border-radius: 5px;
}

.form-group {
  margin-bottom: 15px;
}

.form-group label {
  display: block;
  margin-bottom: 5px;
  font-weight: bold;
}

.form-group input {
  width: 100%;
  padding: 10px;
  border: 1px solid #ddd;
  border-radius: 4px;
  box-sizing: border-box;
}

.submit-button, .action-button {
  width: 100%;
  padding: 12px;
  background: #007bff;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 16px;
  transition: background 0.3s;
}

.submit-button:hover, .action-button:hover {
  background: #0056b3;
}

.submit-button:disabled {
  background: #ccc;
  cursor: not-allowed;
}

.user-section {
  background: white;
  padding: 20px;
  border-radius: 5px;
  text-align: center;
}

.user-info {
  margin: 20px 0;
  text-align: left;
}

.user-info p {
  margin: 10px 0;
}

.actions {
  display: flex;
  gap: 10px;
}

.logout-button {
  background: #dc3545;
}

.logout-button:hover {
  background: #c82333;
}

.message {
  margin: 20px 0;
  padding: 10px;
  border-radius: 4px;
  text-align: center;
}

.message.success {
  background: #d4edda;
  color: #155724;
  border: 1px solid #c3e6cb;
}

.message.error {
  background: #f8d7da;
  color: #721c24;
  border: 1px solid #f5c6cb;
}

.message.info {
  background: #d1ecf1;
  color: #0c5460;
  border: 1px solid #bee5eb;
}

.connection-status {
  margin-top: 20px;
  text-align: center;
  font-size: 14px;
}

.status-indicator {
  display: inline-block;
  width: 10px;
  height: 10px;
  border-radius: 50%;
  margin-right: 5px;
}

.status-indicator.connected {
  background: #28a745;
}

.status-indicator.disconnected {
  background: #dc3545;
}
</style>