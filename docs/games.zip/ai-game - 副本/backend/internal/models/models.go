package models

import (
	"time"
)

type User struct {
	ID        string    `json:"id" db:"id"`
	Username  string    `json:"username" db:"username"`
	Email     string    `json:"email" db:"email"`
	Password  string    `json:"-" db:"password"`
	Nickname  string    `json:"nickname" db:"nickname"`
	Avatar    string    `json:"avatar" db:"avatar"`
	Score     int       `json:"score" db:"score"`
	Status    int       `json:"status" db:"status"`
	CreatedAt time.Time `json:"created_at" db:"created_at"`
	UpdatedAt time.Time `json:"updated_at" db:"updated_at"`
}

type Room struct {
	ID          string    `json:"id" db:"id"`
	Name        string    `json:"name" db:"name"`
	MaxPlayers  int       `json:"max_players" db:"max_players"`
	CurrentGame string    `json:"current_game" db:"current_game"`
	Status      int       `json:"status" db:"status"`
	CreatedAt   time.Time `json:"created_at" db:"created_at"`
}

type Table struct {
	ID        string   `json:"id" db:"id"`
	RoomID    string   `json:"room_id" db:"room_id"`
	Name      string   `json:"name" db:"name"`
	Players   []string `json:"players" db:"players"`
	MaxSeat   int      `json:"max_seat" db:"max_seat"`
	Status    int      `json:"status" db:"status"`
	CreatedAt time.Time `json:"created_at" db:"created_at"`
}

type AIPlayer struct {
	ID          string    `json:"id" db:"id"`
	Name        string    `json:"name" db:"name"`
	Avatar      string    `json:"avatar" db:"avatar"`
	Personality string    `json:"personality" db:"personality"`
	Style       string    `json:"style" db:"style"`
	Prompt      string    `json:"prompt" db:"prompt"`
	Level       int       `json:"level" db:"level"`
	Status      int       `json:"status" db:"status"`
	CreatedAt   time.Time `json:"created_at" db:"created_at"`
}

type GameSession struct {
	ID        string                 `json:"id" db:"id"`
	TableID   string                 `json:"table_id" db:"table_id"`
	Players   []string               `json:"players" db:"players"`
	GameType  string                 `json:"game_type" db:"game_type"`
	GameState map[string]interface{} `json:"game_state" db:"game_state"`
	Status    int                    `json:"status" db:"status"`
	CreatedAt time.Time              `json:"created_at" db:"created_at"`
	EndedAt   *time.Time             `json:"ended_at" db:"ended_at"`
}

type GameRecord struct {
	ID        string    `json:"id" db:"id"`
	SessionID string    `json:"session_id" db:"session_id"`
	PlayerID  string    `json:"player_id" db:"player_id"`
	Score     int       `json:"score" db:"score"`
	Result    string    `json:"result" db:"result"`
	CreatedAt time.Time `json:"created_at" db:"created_at"`
}

type ChatMessage struct {
	ID        string    `json:"id" db:"id"`
	TableID   string    `json:"table_id" db:"table_id"`
	PlayerID  string    `json:"player_id" db:"player_id"`
	Content   string    `json:"content" db:"content"`
	Type      string    `json:"type" db:"type"`
	CreatedAt time.Time `json:"created_at" db:"created_at"`
}