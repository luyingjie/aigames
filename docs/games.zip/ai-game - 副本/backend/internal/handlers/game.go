package handlers

import (
	"net/http"

	"ai-game/internal/database"
	"ai-game/internal/models"
	"ai-game/pkg/utils"

	"github.com/gin-gonic/gin"
)

type GameHandler struct {
	db *database.Database
}

func NewGameHandler(db *database.Database) *GameHandler {
	return &GameHandler{db: db}
}

type CreateRoomRequest struct {
	Name       string `json:"name" binding:"required,min=1,max=50"`
	MaxPlayers int    `json:"max_players" binding:"required,min=2,max=10"`
	GameType   string `json:"game_type" binding:"required"`
}

type JoinTableRequest struct {
	TableID string `json:"table_id" binding:"required"`
	Seat    int    `json:"seat" binding:"min=0,max=3"`
}

func (h *GameHandler) GetRooms(c *gin.Context) {
	rooms, err := h.db.GetAllRooms()
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to get rooms"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"rooms": rooms})
}

func (h *GameHandler) CreateRoom(c *gin.Context) {
	var req CreateRoomRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	room := &models.Room{
		ID:          utils.GenerateID(),
		Name:        req.Name,
		MaxPlayers:  req.MaxPlayers,
		CurrentGame: req.GameType,
		Status:      1,
	}

	if err := h.db.CreateRoom(room); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to create room"})
		return
	}

	c.JSON(http.StatusCreated, room)
}

func (h *GameHandler) GetTables(c *gin.Context) {
	roomID := c.Param("roomId")
	if roomID == "" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Room ID is required"})
		return
	}

	tables, err := h.db.GetTablesByRoom(roomID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to get tables"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"tables": tables})
}

func (h *GameHandler) CreateTable(c *gin.Context) {
	roomID := c.Param("roomId")
	if roomID == "" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Room ID is required"})
		return
	}

	userID, exists := c.Get("userID")
	if !exists {
		c.JSON(http.StatusUnauthorized, gin.H{"error": "User not authorized"})
		return
	}

	table := &models.Table{
		ID:        utils.GenerateID(),
		RoomID:    roomID,
		Name:      "Table " + utils.GenerateID()[8:],
		Players:   []string{userID.(string)},
		MaxSeat:   3,
		Status:    1,
	}

	if err := h.db.CreateTable(table); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to create table"})
		return
	}

	c.JSON(http.StatusCreated, table)
}

func (h *GameHandler) JoinTable(c *gin.Context) {
	tableID := c.Param("tableId")
	if tableID == "" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Table ID is required"})
		return
	}

	userID, exists := c.Get("userID")
	if !exists {
		c.JSON(http.StatusUnauthorized, gin.H{"error": "User not authorized"})
		return
	}

	table, err := h.db.GetTableByID(tableID)
	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Table not found"})
		return
	}

	if len(table.Players) >= table.MaxSeat {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Table is full"})
		return
	}

	for _, playerID := range table.Players {
		if playerID == userID.(string) {
			c.JSON(http.StatusBadRequest, gin.H{"error": "Already joined this table"})
			return
		}
	}

	table.Players = append(table.Players, userID.(string))
	if err := h.db.UpdateTable(table); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to join table"})
		return
	}

	c.JSON(http.StatusOK, table)
}

func (h *GameHandler) LeaveTable(c *gin.Context) {
	tableID := c.Param("tableId")
	if tableID == "" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Table ID is required"})
		return
	}

	userID, exists := c.Get("userID")
	if !exists {
		c.JSON(http.StatusUnauthorized, gin.H{"error": "User not authorized"})
		return
	}

	table, err := h.db.GetTableByID(tableID)
	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Table not found"})
		return
	}

	newPlayers := []string{}
	found := false
	for _, playerID := range table.Players {
		if playerID != userID.(string) {
			newPlayers = append(newPlayers, playerID)
		} else {
			found = true
		}
	}

	if !found {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Not a member of this table"})
		return
	}

	table.Players = newPlayers
	if len(table.Players) == 0 {
		table.Status = 0
	}

	if err := h.db.UpdateTable(table); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to leave table"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Left table successfully"})
}