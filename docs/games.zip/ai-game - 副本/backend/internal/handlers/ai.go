package handlers

import (
	"net/http"

	"ai-game/internal/database"
	"ai-game/internal/models"
	"ai-game/pkg/utils"

	"github.com/gin-gonic/gin"
)

type AIHandler struct {
	db *database.Database
}

func NewAIHandler(db *database.Database) *AIHandler {
	return &AIHandler{db: db}
}

type CreateAIPlayerRequest struct {
	Name        string `json:"name" binding:"required,min=1,max=20"`
	Avatar      string `json:"avatar"`
	Personality string `json:"personality" binding:"required,min=1,max=200"`
	Style       string `json:"style" binding:"required,min=1,max=200"`
	Level       int    `json:"level" binding:"min=1,max=5"`
}

type UpdateAIPlayerRequest struct {
	Name        string `json:"name"`
	Avatar      string `json:"avatar"`
	Personality string `json:"personality"`
	Style       string `json:"style"`
	Level       int    `json:"level" binding:"min=1,max=5"`
	Status      int    `json:"status"`
}

// 获取所有AI玩家
func (h *AIHandler) GetAIPlayers(c *gin.Context) {
	players, err := h.db.GetAllAIPlayers()
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "获取AI玩家失败"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"ai_players": players})
}

// 创建AI玩家
func (h *AIHandler) CreateAIPlayer(c *gin.Context) {
	var req CreateAIPlayerRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	// 生成AI玩家的提示词模板
	prompt := generateAIPrompt(req.Name, req.Personality, req.Style, req.Level)

	aiPlayer := &models.AIPlayer{
		ID:          utils.GenerateID(),
		Name:        req.Name,
		Avatar:      req.Avatar,
		Personality: req.Personality,
		Style:       req.Style,
		Prompt:      prompt,
		Level:       req.Level,
		Status:      1, // 1: 激活, 0: 停用
	}

	if err := h.db.CreateAIPlayer(aiPlayer); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "创建AI玩家失败"})
		return
	}

	c.JSON(http.StatusCreated, aiPlayer)
}

// 获取单个AI玩家
func (h *AIHandler) GetAIPlayer(c *gin.Context) {
	playerID := c.Param("playerId")
	if playerID == "" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "AI玩家ID不能为空"})
		return
	}

	player, err := h.db.GetAIPlayerByID(playerID)
	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "AI玩家不存在"})
		return
	}

	c.JSON(http.StatusOK, player)
}

// 更新AI玩家
func (h *AIHandler) UpdateAIPlayer(c *gin.Context) {
	playerID := c.Param("playerId")
	if playerID == "" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "AI玩家ID不能为空"})
		return
	}

	var req UpdateAIPlayerRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	player, err := h.db.GetAIPlayerByID(playerID)
	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "AI玩家不存在"})
		return
	}

	// 更新字段
	if req.Name != "" {
		player.Name = req.Name
	}
	if req.Avatar != "" {
		player.Avatar = req.Avatar
	}
	if req.Personality != "" {
		player.Personality = req.Personality
	}
	if req.Style != "" {
		player.Style = req.Style
	}
	if req.Level > 0 {
		player.Level = req.Level
	}
	if req.Status >= 0 {
		player.Status = req.Status
	}

	// 重新生成提示词
	player.Prompt = generateAIPrompt(player.Name, player.Personality, player.Style, player.Level)

	if err := h.db.UpdateAIPlayer(player); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "更新AI玩家失败"})
		return
	}

	c.JSON(http.StatusOK, player)
}

// 删除AI玩家
func (h *AIHandler) DeleteAIPlayer(c *gin.Context) {
	playerID := c.Param("playerId")
	if playerID == "" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "AI玩家ID不能为空"})
		return
	}

	player, err := h.db.GetAIPlayerByID(playerID)
	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "AI玩家不存在"})
		return
	}

	// 软删除，设置状态为0
	player.Status = 0
	if err := h.db.UpdateAIPlayer(player); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "删除AI玩家失败"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "AI玩家已删除"})
}

// 生成AI玩家的提示词模板
func generateAIPrompt(name, personality, style string, level int) string {
	levelDesc := map[int]string{
		1: "新手水平，经常出错",
		2: "初级水平，基本会玩",
		3: "中等水平，有一定策略",
		4: "高级水平，策略性强",
		5: "专家水平，几乎不出错",
	}

	prompt := `你是斗地主游戏中的AI玩家，基本信息如下：
姓名：` + name + `
性格特点：` + personality + `
游戏风格：` + style + `
技术水平：` + levelDesc[level] + `

你需要根据以上设定在游戏中做出符合角色的决策和对话。
游戏决策包括：叫地主、出牌、聊天等。
请始终保持角色的一致性，体现出你的性格特点和游戏风格。`

	return prompt
}