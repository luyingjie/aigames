package ai

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"time"
)

// AI服务配置
type AIService struct {
	APIKey    string
	APIUrl    string
	Model     string
	MaxTokens int
}

// AI消息结构
type AIMessage struct {
	Role    string `json:"role"`
	Content string `json:"content"`
}

// AI请求结构
type AIRequest struct {
	Model       string      `json:"model"`
	Messages    []AIMessage `json:"messages"`
	MaxTokens   int         `json:"max_tokens"`
	Temperature float64     `json:"temperature"`
}

// AI响应结构
type AIResponse struct {
	Choices []struct {
		Message AIMessage `json:"message"`
	} `json:"choices"`
	Error *struct {
		Message string `json:"message"`
	} `json:"error,omitempty"`
}

// 斗地主AI决策结构
type DoudizhuDecision struct {
	Action   string   `json:"action"`    // "call_landlord", "pass", "play_cards", "fold"
	Cards    []string `json:"cards"`     // 要出的牌
	Multiple int      `json:"multiple"`  // 倍数（叫地主时）
	Message  string   `json:"message"`   // AI说话内容
}

// 创建新的AI服务
func NewAIService(apiKey, apiUrl, model string) *AIService {
	return &AIService{
		APIKey:    apiKey,
		APIUrl:    apiUrl,
		Model:     model,
		MaxTokens: 1000,
	}
}

// 生成斗地主游戏提示词
func (ai *AIService) GenerateGamePrompt(playerName, personality, style string, gameState map[string]interface{}) string {
	prompt := fmt.Sprintf(`你是一个斗地主AI玩家，名字叫%s，性格特点：%s，游戏风格：%s。

游戏规则：
1. 你正在玩斗地主游戏，需要根据当前游戏状态做出决策
2. 可能的动作包括：叫地主(call_landlord)、不叫(pass)、出牌(play_cards)、不出(fold)
3. 出牌时需要遵循斗地主规则：大牌压小牌，同花色或者特殊牌型
4. 需要根据自己的性格和风格来决策和说话

当前游戏状态：
%s

请分析当前局面，做出决策，并以JSON格式回复：
{
    "action": "动作类型",
    "cards": ["要出的牌"],
    "multiple": 倍数,
    "message": "你想说的话"
}

请保持角色的一致性，根据你的性格特点来表达。`, playerName, personality, style, formatGameState(gameState))

	return prompt
}

// 格式化游戏状态为可读文本
func formatGameState(gameState map[string]interface{}) string {
	stateJSON, _ := json.MarshalIndent(gameState, "", "  ")
	return string(stateJSON)
}

// 调用AI API获取决策
func (ai *AIService) GetGameDecision(prompt string) (*DoudizhuDecision, error) {
	messages := []AIMessage{
		{Role: "system", Content: "你是一个专业的斗地主AI玩家，请根据游戏状态做出合理的决策。"},
		{Role: "user", Content: prompt},
	}

	request := AIRequest{
		Model:       ai.Model,
		Messages:    messages,
		MaxTokens:   ai.MaxTokens,
		Temperature: 0.7,
	}

	response, err := ai.callAPI(request)
	if err != nil {
		return nil, fmt.Errorf("AI API调用失败: %v", err)
	}

	if response.Error != nil {
		return nil, fmt.Errorf("AI API错误: %s", response.Error.Message)
	}

	if len(response.Choices) == 0 {
		return nil, fmt.Errorf("AI没有返回决策")
	}

	// 解析AI的JSON响应
	var decision DoudizhuDecision
	content := response.Choices[0].Message.Content
	if err := json.Unmarshal([]byte(content), &decision); err != nil {
		// 如果JSON解析失败，返回默认决策
		return &DoudizhuDecision{
			Action:  "pass",
			Cards:   []string{},
			Message: "让我想想...",
		}, nil
	}

	return &decision, nil
}

// 生成聊天回复
func (ai *AIService) GenerateChatResponse(playerName, personality, chatHistory, userMessage string) (string, error) {
	prompt := fmt.Sprintf(`你是斗地主游戏中的AI玩家%s，性格特点：%s。

聊天历史：
%s

玩家刚刚说："%s"

请以你的性格特点回复（简短自然，符合游戏氛围）：`, playerName, personality, chatHistory, userMessage)

	messages := []AIMessage{
		{Role: "system", Content: "你是一个斗地主游戏中的AI玩家，请保持角色设定，自然地参与聊天。"},
		{Role: "user", Content: prompt},
	}

	request := AIRequest{
		Model:       ai.Model,
		Messages:    messages,
		MaxTokens:   100,
		Temperature: 0.8,
	}

	response, err := ai.callAPI(request)
	if err != nil {
		return "嗯嗯，好的", nil // 返回默认回复
	}

	if response.Error != nil {
		return "哈哈，有意思", nil
	}

	if len(response.Choices) == 0 {
		return "让我想想...", nil
	}

	return response.Choices[0].Message.Content, nil
}

// 调用AI API的通用方法
func (ai *AIService) callAPI(request AIRequest) (*AIResponse, error) {
	if ai.APIKey == "" || ai.APIUrl == "" {
		return nil, fmt.Errorf("AI服务未配置")
	}

	jsonData, err := json.Marshal(request)
	if err != nil {
		return nil, err
	}

	req, err := http.NewRequest("POST", ai.APIUrl, bytes.NewBuffer(jsonData))
	if err != nil {
		return nil, err
	}

	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Authorization", "Bearer "+ai.APIKey)

	client := &http.Client{
		Timeout: 30 * time.Second,
	}

	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, err
	}

	var response AIResponse
	if err := json.Unmarshal(body, &response); err != nil {
		return nil, err
	}

	return &response, nil
}