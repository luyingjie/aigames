package database

import (
	"encoding/json"
	"fmt"
	"log"
	"time"

	"ai-game/internal/models"
	bolt "go.etcd.io/bbolt"
)

type Database struct {
	db *bolt.DB
}

var (
	UserBucket       = []byte("users")
	RoomBucket       = []byte("rooms")
	TableBucket      = []byte("tables")
	AIPlayerBucket   = []byte("ai_players")
	SessionBucket    = []byte("game_sessions")
	RecordBucket     = []byte("game_records")
	ChatBucket       = []byte("chat_messages")
)

func NewDatabase(dbPath string) (*Database, error) {
	db, err := bolt.Open(dbPath, 0600, &bolt.Options{Timeout: 1 * time.Second})
	if err != nil {
		return nil, fmt.Errorf("failed to open database: %v", err)
	}

	database := &Database{db: db}
	if err := database.initBuckets(); err != nil {
		db.Close()
		return nil, fmt.Errorf("failed to initialize buckets: %v", err)
	}

	log.Println("Database connected successfully")
	return database, nil
}

func (d *Database) Close() error {
	return d.db.Close()
}

func (d *Database) initBuckets() error {
	return d.db.Update(func(tx *bolt.Tx) error {
		buckets := [][]byte{
			UserBucket, RoomBucket, TableBucket, AIPlayerBucket,
			SessionBucket, RecordBucket, ChatBucket,
		}
		
		for _, bucket := range buckets {
			if _, err := tx.CreateBucketIfNotExists(bucket); err != nil {
				return fmt.Errorf("failed to create bucket %s: %v", bucket, err)
			}
		}
		return nil
	})
}

func (d *Database) CreateUser(user *models.User) error {
	return d.db.Update(func(tx *bolt.Tx) error {
		bucket := tx.Bucket(UserBucket)
		
		if bucket.Get([]byte(user.Username)) != nil {
			return fmt.Errorf("username already exists")
		}
		
		if bucket.Get([]byte("email_"+user.Email)) != nil {
			return fmt.Errorf("email already exists")
		}

		user.CreatedAt = time.Now()
		user.UpdatedAt = time.Now()
		
		data, err := json.Marshal(user)
		if err != nil {
			return err
		}
		
		if err := bucket.Put([]byte(user.ID), data); err != nil {
			return err
		}
		
		if err := bucket.Put([]byte("username_"+user.Username), []byte(user.ID)); err != nil {
			return err
		}
		
		return bucket.Put([]byte("email_"+user.Email), []byte(user.ID))
	})
}

func (d *Database) GetUserByUsername(username string) (*models.User, error) {
	var user models.User
	err := d.db.View(func(tx *bolt.Tx) error {
		bucket := tx.Bucket(UserBucket)
		
		userIDBytes := bucket.Get([]byte("username_" + username))
		if userIDBytes == nil {
			return fmt.Errorf("user not found")
		}
		
		userData := bucket.Get(userIDBytes)
		if userData == nil {
			return fmt.Errorf("user data not found")
		}
		
		return json.Unmarshal(userData, &user)
	})
	
	if err != nil {
		return nil, err
	}
	return &user, nil
}

func (d *Database) GetUserByID(userID string) (*models.User, error) {
	var user models.User
	err := d.db.View(func(tx *bolt.Tx) error {
		bucket := tx.Bucket(UserBucket)
		userData := bucket.Get([]byte(userID))
		if userData == nil {
			return fmt.Errorf("user not found")
		}
		return json.Unmarshal(userData, &user)
	})
	
	if err != nil {
		return nil, err
	}
	return &user, nil
}

func (d *Database) UpdateUser(user *models.User) error {
	return d.db.Update(func(tx *bolt.Tx) error {
		bucket := tx.Bucket(UserBucket)
		
		user.UpdatedAt = time.Now()
		data, err := json.Marshal(user)
		if err != nil {
			return err
		}
		
		return bucket.Put([]byte(user.ID), data)
	})
}

func (d *Database) CreateRoom(room *models.Room) error {
	return d.db.Update(func(tx *bolt.Tx) error {
		bucket := tx.Bucket(RoomBucket)
		
		room.CreatedAt = time.Now()
		data, err := json.Marshal(room)
		if err != nil {
			return err
		}
		
		return bucket.Put([]byte(room.ID), data)
	})
}

func (d *Database) GetAllRooms() ([]*models.Room, error) {
	var rooms []*models.Room
	
	err := d.db.View(func(tx *bolt.Tx) error {
		bucket := tx.Bucket(RoomBucket)
		return bucket.ForEach(func(k, v []byte) error {
			var room models.Room
			if err := json.Unmarshal(v, &room); err != nil {
				return err
			}
			rooms = append(rooms, &room)
			return nil
		})
	})
	
	return rooms, err
}

func (d *Database) CreateAIPlayer(ai *models.AIPlayer) error {
	return d.db.Update(func(tx *bolt.Tx) error {
		bucket := tx.Bucket(AIPlayerBucket)
		
		ai.CreatedAt = time.Now()
		data, err := json.Marshal(ai)
		if err != nil {
			return err
		}
		
		return bucket.Put([]byte(ai.ID), data)
	})
}

func (d *Database) GetAllAIPlayers() ([]*models.AIPlayer, error) {
	var players []*models.AIPlayer
	
	err := d.db.View(func(tx *bolt.Tx) error {
		bucket := tx.Bucket(AIPlayerBucket)
		return bucket.ForEach(func(k, v []byte) error {
			var player models.AIPlayer
			if err := json.Unmarshal(v, &player); err != nil {
				return err
			}
			if player.Status == 1 {
				players = append(players, &player)
			}
			return nil
		})
	})
	
	return players, err
}

func (d *Database) CreateTable(table *models.Table) error {
	return d.db.Update(func(tx *bolt.Tx) error {
		bucket := tx.Bucket(TableBucket)
		
		table.CreatedAt = time.Now()
		data, err := json.Marshal(table)
		if err != nil {
			return err
		}
		
		return bucket.Put([]byte(table.ID), data)
	})
}

func (d *Database) GetTablesByRoom(roomID string) ([]*models.Table, error) {
	var tables []*models.Table
	
	err := d.db.View(func(tx *bolt.Tx) error {
		bucket := tx.Bucket(TableBucket)
		return bucket.ForEach(func(k, v []byte) error {
			var table models.Table
			if err := json.Unmarshal(v, &table); err != nil {
				return err
			}
			if table.RoomID == roomID && table.Status == 1 {
				tables = append(tables, &table)
			}
			return nil
		})
	})
	
	return tables, err
}

func (d *Database) GetTableByID(tableID string) (*models.Table, error) {
	var table models.Table
	err := d.db.View(func(tx *bolt.Tx) error {
		bucket := tx.Bucket(TableBucket)
		data := bucket.Get([]byte(tableID))
		if data == nil {
			return fmt.Errorf("table not found")
		}
		return json.Unmarshal(data, &table)
	})
	
	if err != nil {
		return nil, err
	}
	return &table, nil
}

func (d *Database) UpdateTable(table *models.Table) error {
	return d.db.Update(func(tx *bolt.Tx) error {
		bucket := tx.Bucket(TableBucket)
		
		data, err := json.Marshal(table)
		if err != nil {
			return err
		}
		
		return bucket.Put([]byte(table.ID), data)
	})
}

func (d *Database) GetAIPlayerByID(playerID string) (*models.AIPlayer, error) {
	var player models.AIPlayer
	err := d.db.View(func(tx *bolt.Tx) error {
		bucket := tx.Bucket(AIPlayerBucket)
		data := bucket.Get([]byte(playerID))
		if data == nil {
			return fmt.Errorf("AI player not found")
		}
		return json.Unmarshal(data, &player)
	})
	
	if err != nil {
		return nil, err
	}
	return &player, nil
}

func (d *Database) UpdateAIPlayer(player *models.AIPlayer) error {
	return d.db.Update(func(tx *bolt.Tx) error {
		bucket := tx.Bucket(AIPlayerBucket)
		
		data, err := json.Marshal(player)
		if err != nil {
			return err
		}
		
		return bucket.Put([]byte(player.ID), data)
	})
}