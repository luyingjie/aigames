package utils

import (
	"crypto/rand"
	"encoding/hex"
	"fmt"
	"time"
)

func GenerateID() string {
	timestamp := time.Now().Unix()
	
	bytes := make([]byte, 4)
	if _, err := rand.Read(bytes); err != nil {
		return fmt.Sprintf("%d", timestamp)
	}
	
	return fmt.Sprintf("%d%s", timestamp, hex.EncodeToString(bytes))
}