package config

import (
	"os"
	"strconv"
)

type Config struct {
	Port       string
	DBPath     string
	JWTSecret  string
	AIAPIKey   string
	AIAPIUrl   string
}

func LoadConfig() *Config {
	return &Config{
		Port:      getEnv("PORT", "8080"),
		DBPath:    getEnv("DB_PATH", "./data/game.db"),
		JWTSecret: getEnv("JWT_SECRET", "ai-game-secret-key-2023"),
		AIAPIKey:  getEnv("AI_API_KEY", ""),
		AIAPIUrl:  getEnv("AI_API_URL", ""),
	}
}

func getEnv(key, defaultValue string) string {
	if value := os.Getenv(key); value != "" {
		return value
	}
	return defaultValue
}

func getEnvAsInt(key string, defaultValue int) int {
	if value := os.Getenv(key); value != "" {
		if intValue, err := strconv.Atoi(value); err == nil {
			return intValue
		}
	}
	return defaultValue
}