package main

import (
	"log"
	"os"

	"ai-game/internal/database"
	"ai-game/internal/handlers"
	"ai-game/internal/middleware"
	"ai-game/pkg/config"

	"github.com/gin-gonic/gin"
)

func main() {
	cfg := config.LoadConfig()

	if err := os.MkdirAll("./data", 0755); err != nil {
		log.Fatalf("Failed to create data directory: %v", err)
	}

	db, err := database.NewDatabase(cfg.DBPath)
	if err != nil {
		log.Fatalf("Failed to connect to database: %v", err)
	}
	defer db.Close()

	r := gin.Default()
	
	r.Use(middleware.CORSMiddleware())

	authHandler := handlers.NewAuthHandler(db)
	gameHandler := handlers.NewGameHandler(db)
	aiHandler := handlers.NewAIHandler(db)

	api := r.Group("/api/v1")
	{
		auth := api.Group("/auth")
		{
			auth.POST("/register", authHandler.Register)
			auth.POST("/login", authHandler.Login)
			auth.GET("/profile", middleware.AuthMiddleware(), authHandler.Profile)
		}

		protected := api.Group("/")
		protected.Use(middleware.AuthMiddleware())
		{
			protected.GET("/user", authHandler.Profile)
			
			protected.GET("/rooms", gameHandler.GetRooms)
			protected.POST("/rooms", gameHandler.CreateRoom)
			
			protected.GET("/rooms/:roomId/tables", gameHandler.GetTables)
			protected.POST("/rooms/:roomId/tables", gameHandler.CreateTable)
			protected.POST("/tables/:tableId/join", gameHandler.JoinTable)
			protected.DELETE("/tables/:tableId/leave", gameHandler.LeaveTable)
			
			protected.GET("/ai-players", aiHandler.GetAIPlayers)
			protected.POST("/ai-players", aiHandler.CreateAIPlayer)
			protected.GET("/ai-players/:playerId", aiHandler.GetAIPlayer)
			protected.PUT("/ai-players/:playerId", aiHandler.UpdateAIPlayer)
			protected.DELETE("/ai-players/:playerId", aiHandler.DeleteAIPlayer)
		}
	}

	r.GET("/health", func(c *gin.Context) {
		c.JSON(200, gin.H{"status": "ok"})
	})

	log.Printf("Server starting on port %s", cfg.Port)
	if err := r.Run(":" + cfg.Port); err != nil {
		log.Fatalf("Failed to start server: %v", err)
	}
}