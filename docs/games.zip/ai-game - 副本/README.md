# AI斗地主游戏

## 项目介绍
这是一个基于AI的斗地主游戏平台，玩家可以注册登录后进入游戏大厅，选择桌子与其他玩家或AI对战。

## 技术栈
- 后端：Golang + Gin框架
- 前端：Vue3 + TypeScript + Vite
- 数据库：bbolt（嵌入式键值数据库）
- WebSocket：实时游戏通信
- AI：集成大模型API实现AI玩家

## 项目结构
```
ai-game/
├── backend/                   # 后端Go代码
│   ├── cmd/server/           # 服务器启动入口
│   ├── internal/             # 内部模块
│   │   ├── auth/            # 用户认证
│   │   ├── game/            # 游戏核心逻辑
│   │   ├── models/          # 数据模型
│   │   ├── database/        # 数据库操作
│   │   ├── ai/              # AI代理
│   │   ├── api/             # API路由
│   │   ├── handlers/        # HTTP处理器
│   │   ├── middleware/      # 中间件
│   │   └── websocket/       # WebSocket处理
│   └── pkg/                 # 公共包
│       ├── utils/           # 工具函数
│       └── config/          # 配置管理
├── frontend/                # 前端Vue代码
│   ├── src/
│   │   ├── components/      # Vue组件
│   │   │   ├── game/       # 游戏相关组件
│   │   │   ├── lobby/      # 大厅组件
│   │   │   ├── auth/       # 登录注册组件
│   │   │   └── admin/      # AI管理组件
│   │   ├── views/          # 页面视图
│   │   ├── router/         # 路由配置
│   │   ├── api/            # API调用
│   │   ├── store/          # 状态管理
│   │   ├── assets/         # 静态资源
│   │   └── styles/         # 样式文件
│   └── public/             # 公共静态文件
└── docs/                   # 项目文档
```

## 功能模块
1. 用户注册/登录系统
2. 游戏大厅/桌子管理
3. AI Agent配置管理
4. 斗地主游戏核心
5. 分数结算系统
6. 聊天功能（支持AI角色扮演）
7. RESTful API + WebSocket
8. 管理后台界面

## 开发计划
- [x] 项目结构设计
- [ ] 后端基础框架搭建
- [ ] 数据库集成
- [ ] 用户认证系统
- [ ] 游戏核心逻辑
- [ ] AI Agent集成
- [ ] 前端界面开发
- [ ] WebSocket实时通信
- [ ] 系统测试部署
